Source Data S18
Coordinate-only refit of the endpoint-geometry representation
British Journal of Pharmacology 2026-BJP-1747-RPR

WHAT THIS PACKAGE ANSWERS
-------------------------
The endpoint-geometry representation as fitted contains 11 non-coordinate acquisition inputs
(resolution, deposition year, experimental method, ligand type, fusion-protein annotation and ICL2
completeness indicators), which carry 7.3% of the mean absolute coefficient mass. This package tests
whether the archive-wide transfer result and the within-receptor result depend on those inputs, by
refitting the same specification on receptor coordinates alone.

PROVENANCE OF THE INPUTS
------------------------
Nothing here is newly measured. Every input is taken from the archived bundle:
  - per-structure geometric measurements and acquisition metadata: Source Data S1
    (results/microswitches/measurements/microswitch_measurements.csv)
  - fold assignments under receptor-grouped and 50%/40%/30% identity-cluster validation, and the
    archived out-of-fold predictions used as the comparison baseline: Source Data S11
    (results/microswitches/sequence_interface_audit_v1/)
  - sequence-cluster assignments: Source Data S11 (audit/sequence_cluster_assignments.tsv)

MODEL SPECIFICATION
-------------------
The transfer-audit specification was reimplemented independently: nested L2 logistic regression
(lbfgs), training-fold tuning of C over 11 logarithmically spaced values from 1e-3 to 1e2 by grouped
inner cross-validation on negative log loss, median imputation and standardisation of numeric inputs
and most-frequent imputation with one-hot encoding of categoricals, all fitted inside training folds
only. Outer folds are the archived fold assignments, reused unchanged.

Two inputs of the archived 107 are not present in the archived per-structure measurement table: the
activation-consensus score and its completeness count. They were omitted from the reimplementation
and from every model derived from it, leaving 105 archived inputs.

MODELS
------
  full          105 archived inputs, as fitted in the archive
  coord         acquisition inputs removed (resolution, deposition year, experimental method,
                ligand type, fusion-protein annotation, ICL2-partial indicator)
  coord_strict  coord, additionally removing the three completeness counts
  acq_only      acquisition inputs only

VALIDATION OF THE REIMPLEMENTATION (results/validation_and_multiplicity.json)
----------------------------------------------------------------------------
Run on the ARCHIVED predictions, the within-receptor harness in this package reproduces the archived
statistics exactly: margin +0.05113, accuracy 0.5972, one-sided P = 0.0105 and P = 0.0015 against the
archived values in Source Data S17 (P = 0.0094 and P = 0.0011; permutation seeds differ). Refitted
archive-wide macro ROC AUC reproduces the archived value to within 0.007 at every validation level
with five valid folds, and to within 0.027 at 30%, where only two unequal folds exist.

HEADLINE RESULT (results/archive_wide_auc_table.tsv)
----------------------------------------------------
Macro ROC AUC, receptor-grouped / 50% / 40% / 30%:
  archived endpoint geometry     0.776 / 0.731 / 0.683 / 0.517
  reimplementation, all inputs   0.783 / 0.737 / 0.680 / 0.494
  coordinate-only                0.781 / 0.741 / 0.678 / 0.490
  strict coordinate-only         0.775 / 0.737 / 0.678 / 0.493
  acquisition inputs only        0.568 / 0.489 / 0.533 / 0.515

Paired full-sequence-minus-coordinate-only difference, receptor-clustered bootstrap over 2,000
resamples: +0.009 (-0.035, +0.055) receptor-grouped; -0.102 (-0.168, -0.034) at 50%; -0.066 (-0.132,
-0.000) at 40%; +0.049 (-0.026, +0.124) at 30%.

WITHIN-RECEPTOR TEST ON THE COORDINATE-ONLY REFIT
-------------------------------------------------
(results/within_receptor_and_bootstrap.json; 34 receptors, 72 units; one-sided empirical P from 2,000
within-receptor label permutations preserving each receptor's observed class composition)
  receptor-grouped  margin +0.038 (P = 0.006), accuracy 55.6% (P = 0.018)
  50% identity      margin +0.012 (P = 0.011), accuracy 50.0% (P = 0.26)
  40% identity      margin -0.004 (P = 0.099)
  30% identity      margin -0.020 (P = 0.78)

The 50% margin attenuates from +0.061 (archived, all inputs) to +0.012. The direction and the
identity-threshold profile are preserved; the magnitude at 50% is not.

Substituted into the same nine-representation ladder used in Table S28, the coordinate-only values
give Benjamini-Hochberg q = 0.045 for the margin and q = 0.094 for accuracy.

CONSTRUCT STRATA (results/construct_strata_coordinate_only.json)
----------------------------------------------------------------
Coordinate-only margin under receptor-grouped validation:
  all eligible                   34 receptors, 72 units, +0.038, P = 0.006
  resolution matched to 0.3 A    19 receptors, 40 units, +0.063, P = 0.016
  single publication reference   16 receptors, 32 units, +0.073, P = 0.051
  Gi/o and Gq/11                 18 receptors, 36 units, +0.061, P = 0.040
  Gi/o and Gs                     6 receptors, 12 units, +0.101, P = 0.11
  Gq/11 and Gs                    6 receptors, 12 units, +0.062, P = 0.13
  all three classes               4 receptors, 12 units, -0.118, P = 0.27

The single-publication stratum here is defined by a single deposited publication reference across a
receptor's captured-class endpoints, and is broader than the eight-receptor stratum of Table S32,
which additionally required complete reference metadata.

ADVERSARIAL SENSITIVITY (results/tipping_point.json)
----------------------------------------------------
Because the identity of the stabilising antibody fragment is not annotated, the within-receptor
test was subjected to an adversarial deletion ladder: receptors are deleted in order of their
contribution to the margin, on the assumption that the most favourable ones are entirely
construct-driven, and the permutation test is recomputed at each step.

  coordinate-only refit   0 deleted  34 rec  +0.038  P = 0.003
                          1 deleted  33 rec  +0.026  P = 0.015
                          2 deleted  32 rec  +0.017  P = 0.016
                          3 deleted  31 rec  +0.011  P = 0.029
                          4 deleted  30 rec  +0.004  P = 0.048
                          5 deleted  29 rec  -0.001  P = 0.075

  archived primary model  0 deleted  34 rec  +0.051  P = 0.005 (accuracy 59.7%, P = 0.002)
                          3 deleted  31 rec  +0.015  P = 0.042 (accuracy 57.6%, P = 0.005)
                          4 deleted  30 rec  +0.008  P = 0.084 (accuracy 56.3%, P = 0.015)

A construct explanation of the within-receptor result would therefore have to apply to at least
five of the 34 receptors and remove their margin entirely. The effect is distributed rather than
carried by one or two receptors, but it is not large, and this bound is stated rather than
implied.

STABILISER ANNOTATION: RUN, NOT DEFERRED (results/stabiliser_*.{tsv,json})
---------------------------------------------------------------------------
Polymer entity descriptions were read from the deposited mmCIF records of all 72 within-receptor
units (_entity.type == polymer, _entity.pdbx_description) and classified by pattern match into
scFv16, Nb35, Nb6B9, other nanobody, other Fab/scFv, mini-G, G chimera, GRK, fusion tag and
membrane scaffold. The extracted descriptions are in results/polymer_entity_descriptions_72_units.json
and the classifier as run is scripts/06b_entity_classifier_as_run.py.

Entity counts across the 72 units: scFv16 45, Nb35 16, other nanobody 10, other Fab/scFv 5, no
antibody/nanobody/Fab entity declared 8; mini-G or G chimera 9, fusion tag 10.

A receptor is stabiliser-matched when its captured-class endpoints carry an identical stabiliser
annotation. Eight receptors qualify, and ALL EIGHT are Gi/o + Gq/11 pairs sharing scFv16: C3aR,
FFA2, KISS1R, MRGPRD, MRGPRX1, PAR1, PrRP, US28. That is the configuration the construct argument
in the manuscript predicts.

Within-receptor margin by stratum (one-sided permutation P, 2,000 permutations):
  stratum                              rec  units  coordinate-only      archived primary
  all eligible                          34     72  +0.038 (P = 0.006)   +0.051 (P = 0.012)
  matched stabiliser                     8     16  +0.127 (P = 0.005)   +0.183 (P = 0.008)
  matched stabiliser AND engineering     6     12  +0.138 (P = 0.031)   +0.200 (P = 0.045)
  mismatched stabiliser                 26     56  +0.012 (P = 0.047)   +0.013 (P = 0.075)

The effect is LARGEST where stabilisation chemistry is held constant, which is the opposite of
what a stabiliser-driven artefact predicts.

Limits, stated rather than implied: the matched stratum has 8 receptors and 16 units; its accuracy
statistic is at the permutation expectation (56.3%, P = 0.50 coordinate-only; 75.0%, P = 0.063
archived), so the margin and not the accuracy carries it; and eight structures declare no antibody,
nanobody or Fab entity, so for two of the 34 receptors "matched" means matched in the absence of
one. Thermostabilising point mutations are still not annotated, and the pattern classifier depends
on depositor-supplied entity descriptions.

STABILISER ANNOTATION SCRIPT FOR RE-RUNNING (scripts/06_stabiliser_annotation_from_mmcif.py)
----------------------------------------------------------------------
The deposited coordinate files are not part of Source Data, so this general script is supplied
for re-running the annotation from scratch against the local archive (data/structures/{PDB_ID}.cif, the layout shown
by the entity audit in Source Data S6) or with --fetch to download the 72 entries from RCSB. It
extracts antibody-fragment, nanobody and engineered-transducer identity from the mmCIF polymer
entity records, then re-runs the within-receptor test on the receptors whose captured-class
endpoints share the same stabilisation chemistry. It prints the sentence to paste into Results 3.2
for either outcome, including the unfavourable one.

FILES
-----
  scripts/01_build_unit_frame.py              joins S1 measurements to S11 units, folds and clusters
  scripts/02_fit_models.py                    fits the four models under the four validation schemes
  scripts/03_within_receptor_and_bootstrap.py within-receptor permutation test and paired bootstrap
  scripts/04_construct_strata.py              construct and class-pair strata
  scripts/05_validate_against_archive.py      runs the harness on the archived predictions
  scripts/06_stabiliser_annotation_from_mmcif.py  mmCIF entity extraction and stabiliser-matched
                                              re-analysis; supplied ready to run, not run here
  scripts/06b_entity_classifier_as_run.py     the classifier exactly as run for the table above
  scripts/07_adversarial_sensitivity.py       the deletion ladder above
  scripts/08_stabiliser_stratified_test.py    the stabiliser-stratified within-receptor test
  predictions/out_of_fold_predictions_refit.tsv  per-unit out-of-fold probabilities, all models
  predictions/unit_metadata_and_folds.tsv        the 207 units with acquisition metadata and folds
  results/archive_wide_auc_table.tsv             the AUC table above
  results/within_receptor_and_bootstrap.json     within-receptor and bootstrap results
  results/construct_strata_coordinate_only.json  strata results
  results/validation_and_multiplicity.json       reimplementation validation and BH q values
  results/tipping_point.json                     the adversarial deletion ladder
  results/polymer_entity_descriptions_72_units.json  extracted mmCIF polymer entity descriptions
  results/stabiliser_annotation_72_units.tsv     per-unit stabiliser and engineering annotation
  results/stabiliser_stratified.json             matched / mismatched within-receptor test
  results/stabiliser_strict.json                 matched stabiliser AND engineering stratum

LIMITS OF THIS ANALYSIS
-----------------------
This is an independent reimplementation, not an execution of the original pipeline, and two archived
inputs could not be reconstructed from the archived measurement table. It removes measured
acquisition context; it cannot remove construct variation that the deposited annotation does not
encode, in particular thermostabilising point mutations, which no entity description records. Antibody,
nanobody, chimera and fusion identity ARE now annotated and stratified, as described above.
