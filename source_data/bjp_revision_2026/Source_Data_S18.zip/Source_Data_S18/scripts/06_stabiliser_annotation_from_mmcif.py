#!/usr/bin/env python3
"""
06_stabiliser_annotation_from_mmcif.py

Extracts antibody-fragment, nanobody and engineered-transducer identity from the deposited
mmCIF polymer entity records of the 72 within-receptor units, then re-runs the within-receptor
test stratified by whether a receptor's captured-class endpoints share the same stabilisation
chemistry.

WHY THIS SCRIPT EXISTS
----------------------
The manuscript states that Gq/11 complexes are routinely chimeric constructs engineered so that
the same antibody fragment used for Gi/o complexes will bind, and that this expectation was not
verified. Antibody and nanobody identities are separate polymer entities in the deposited
records, so the verification is a parsing job, not a new experiment. This is the analysis a
referee is most likely to request next.

IT IS NOT RUN IN THE SUPPLIED BUNDLE because the deposited coordinate files are not part of
Source Data. Run it where the archive lives: the entity audit in Source Data S6 shows the
expected layout, data/structures/{PDB_ID}.cif, parsed with biotite.

USAGE
-----
    python 06_stabiliser_annotation_from_mmcif.py \
        --cif-dir data/structures \
        --units predictions/unit_metadata_and_folds.tsv \
        --predictions predictions/out_of_fold_predictions_refit.tsv \
        --out results/

Runtime is a few minutes for 72 entries. No network access is required if the CIFs are local;
pass --fetch to download missing entries from RCSB instead.
"""

import argparse, json, os, re, sys
import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------------
# Entity classification
# ----------------------------------------------------------------------------------
# Patterns are matched case-insensitively against the mmCIF entity description
# (_entity.pdbx_description), which is the same field used by the entity audit in Source Data S6.

PATTERNS = [
    ("scFv16",            r"\bscfv\s*-?\s*16\b|single[- ]chain\s+variable.*16"),
    ("Nb35",              r"\bnb\s*-?\s*35\b|nanobody\s*-?\s*35"),
    ("Nb6B9",             r"\bnb\s*-?\s*6b9\b"),
    ("other nanobody",    r"\bnanobody\b|\bvhh\b|camelid|single[- ]domain antibody"),
    ("Fab/scFv (other)",  r"\bfab\b|\bscfv\b|antibody fragment|fragment antigen|heavy chain variable|light chain variable|\bigg\b"),
    ("mini-G",            r"\bmini[- ]?g[siqo0-9]*\b|minig[siqo]"),
    ("G chimera",         r"chimera|chimeric|\bgi/q\b|\bgq/i\b|g\s*alpha\s*q.*chimer|dominant[- ]negative"),
    ("BRIL/T4L fusion",   r"\bbril\b|apocytochrome|soluble cytochrome b562|\bt4\s*lysozyme\b|\blysozyme\b|\bflavodoxin\b|\brubredoxin\b|pgs\b|glycogen synthase"),
    ("Nanodisc/scaffold", r"membrane scaffold protein|\bmsp\d|saposin|nanodisc"),
]

STABILISER_CLASSES = ["scFv16", "Nb35", "Nb6B9", "other nanobody", "Fab/scFv (other)"]


def classify(description: str):
    d = (description or "").lower()
    hits = [name for name, pat in PATTERNS if re.search(pat, d)]
    return hits


# ----------------------------------------------------------------------------------
# mmCIF entity reading
# ----------------------------------------------------------------------------------

def entity_descriptions(cif_path: str):
    """Return the list of polymer entity descriptions in a deposited mmCIF file.

    Tries biotite first (the parser used by the Source Data S6 entity audit), then gemmi,
    then a minimal text fallback so the script still runs in a bare environment.
    """
    try:
        import biotite.structure.io.pdbx as pdbx
        f = pdbx.CIFFile.read(cif_path)
        block = f.block
        ent = block["entity"]
        types = ent["type"].as_array()
        desc = ent["pdbx_description"].as_array()
        return [str(d) for t, d in zip(types, desc) if str(t).lower() == "polymer"]
    except Exception:
        pass
    try:
        import gemmi
        doc = gemmi.cif.read(cif_path)
        block = doc.sole_block()
        out = []
        for t, d in zip(block.find_values("_entity.type"), block.find_values("_entity.pdbx_description")):
            if gemmi.cif.as_string(t).lower() == "polymer":
                out.append(gemmi.cif.as_string(d))
        return out
    except Exception:
        pass
    # text fallback: read the _entity loop directly
    text = open(cif_path, "r", errors="ignore").read()
    return re.findall(r"^\s*\d+\s+polymer\s+\S+\s+(?:'([^']*)'|\"([^\"]*)\")", text, flags=re.M | re.I) or []


def fetch_cif(pdb_id: str, cif_dir: str):
    import urllib.request
    dest = os.path.join(cif_dir, f"{pdb_id}.cif")
    if not os.path.exists(dest):
        url = f"https://files.rcsb.org/download/{pdb_id}.cif"
        urllib.request.urlretrieve(url, dest)
    return dest


# ----------------------------------------------------------------------------------
# Within-receptor test (identical harness to 03_within_receptor_and_bootstrap.py)
# ----------------------------------------------------------------------------------

CL = ["Gi/o", "Gq/11", "Gs"]


def within(P, frame, nperm=2000, seed=11):
    r = np.random.default_rng(seed)
    G = []
    for _, g in frame.groupby("receptor_name"):
        cls = sorted(g.transducer_family.unique())
        G.append((P.loc[g.index, cls].values,
                  np.array([cls.index(t) for t in g.transducer_family])))

    def stat(labs):
        m, a = [], []
        for (M, _), lab in zip(G, labs):
            for i, t in enumerate(lab):
                row = M[i]
                m.append(row[t] - np.max(np.delete(row, t)))
                a.append(float(np.argmax(row) == t))
        return np.mean(m), np.mean(a)

    obs = stat([g[1] for g in G])
    perm = np.array([stat([r.permutation(g[1]) for g in G]) for _ in range(nperm)])
    return dict(margin=float(obs[0]), accuracy=float(obs[1]),
                P_margin=float(((perm[:, 0] >= obs[0]).sum() + 1) / (nperm + 1)),
                P_accuracy=float(((perm[:, 1] >= obs[1]).sum() + 1) / (nperm + 1)),
                n_receptors=len(G), n_units=int(len(frame)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cif-dir", required=True)
    ap.add_argument("--units", default="predictions/unit_metadata_and_folds.tsv")
    ap.add_argument("--predictions", default="predictions/out_of_fold_predictions_refit.tsv")
    ap.add_argument("--model", default="coord", choices=["coord", "full", "coord_strict", "acq_only"])
    ap.add_argument("--validation", default="receptor")
    ap.add_argument("--fetch", action="store_true", help="download missing CIFs from RCSB")
    ap.add_argument("--out", default="results/")
    args = ap.parse_args()

    units = pd.read_csv(args.units, sep="\t").set_index("analysis_row_id")
    multi = units.groupby("receptor_name").transducer_family.nunique()
    sub = units[units.receptor_name.isin(multi[multi >= 2].index)]

    pred = pd.read_csv(args.predictions, sep="\t")
    P = pred[(pred.model == args.model) & (pred.validation == args.validation)].set_index("analysis_row_id")[CL]

    rows = []
    for rid, u in sub.iterrows():
        pdb = str(u.pdb_id).upper()
        path = os.path.join(args.cif_dir, f"{pdb}.cif")
        if not os.path.exists(path) and args.fetch:
            path = fetch_cif(pdb, args.cif_dir)
        if not os.path.exists(path):
            print(f"MISSING {pdb}", file=sys.stderr)
            rows.append(dict(analysis_row_id=rid, pdb_id=pdb, receptor_name=u.receptor_name,
                             transducer_family=u.transducer_family, entities="", stabilisers="",
                             engineered="", status="cif_not_found"))
            continue
        descs = entity_descriptions(path)
        hits = sorted({h for d in descs for h in classify(d if isinstance(d, str) else "".join(d))})
        rows.append(dict(analysis_row_id=rid, pdb_id=pdb, receptor_name=u.receptor_name,
                         transducer_family=u.transducer_family,
                         entities=" | ".join(str(d) for d in descs),
                         stabilisers=",".join(h for h in hits if h in STABILISER_CLASSES),
                         engineered=",".join(h for h in hits if h not in STABILISER_CLASSES),
                         status="ok"))
    ann = pd.DataFrame(rows).set_index("analysis_row_id")
    os.makedirs(args.out, exist_ok=True)
    ann.to_csv(os.path.join(args.out, "stabiliser_annotation_72_units.tsv"), sep="\t")

    ok = ann[ann.status == "ok"]
    matched, mismatched = [], []
    for r, g in ok.groupby("receptor_name"):
        sets = {frozenset(s.split(",")) - {""} for s in g.stabilisers}
        (matched if len(sets) == 1 else mismatched).append(r)

    res = {"n_annotated_units": int(len(ok)),
           "receptors_matched_stabiliser": sorted(matched),
           "receptors_mismatched_stabiliser": sorted(mismatched)}

    for label, recs in [("all", ok.receptor_name.unique().tolist()),
                        ("matched_stabiliser", matched),
                        ("mismatched_stabiliser", mismatched)]:
        fr = sub[sub.receptor_name.isin(recs)]
        if fr.receptor_name.nunique() >= 3 and fr.transducer_family.nunique() >= 2:
            res[label] = within(P, fr)
        else:
            res[label] = {"skipped": "fewer than 3 receptors"}

    json.dump(res, open(os.path.join(args.out, "stabiliser_stratified_within_receptor.json"), "w"), indent=1)
    print(json.dumps(res, indent=1))

    print("""
HOW TO REPORT THE RESULT
------------------------
If the margin in the matched-stabiliser stratum is positive and of similar size to the whole set,
replace the sentence in Results 3.2 that begins "That expectation was not verified here" with:

  "That expectation was verified: across the N receptors whose captured-class endpoints share the
   same antibody fragment or nanobody, the within-receptor margin was +X.XXX (P = 0.0XX), so the
   effect is present where stabilisation chemistry is held constant."

If the matched stratum is null while the mismatched stratum carries the effect, report that
directly and downgrade the within-receptor test to a result the construct annotation does not
support. Do not report only the favourable stratum.
""")


if __name__ == "__main__":
    main()
