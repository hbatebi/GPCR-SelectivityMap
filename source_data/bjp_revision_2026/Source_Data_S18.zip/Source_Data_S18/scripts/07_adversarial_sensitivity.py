import pandas as pd, numpy as np, json
exec(open('fast.py').read().split("val=sys.argv[1]")[0])
def per_receptor(P,frame):
    out={}
    for r,g in frame.groupby('receptor_name'):
        cls=sorted(g.transducer_family.unique()); M=P.loc[g.index,cls].values
        lab=[cls.index(t) for t in g.transducer_family]
        ms=[M[i][t]-np.max(np.delete(M[i],t)) for i,t in enumerate(lab)]
        out[r]=float(np.mean(ms))
    return pd.Series(out).sort_values(ascending=False)
def ladder(P,label):
    res=[]
    order=per_receptor(P,sub).index.tolist()
    for k in range(0,len(order)):
        keep=[r for r in order[k:]]
        fr=sub[sub.receptor_name.isin(keep)]
        if fr.transducer_family.nunique()<2 or len(keep)<5: break
        w=within(P,fr,nperm=2000,seed=100+k)
        res.append(dict(removed=k,receptors=len(keep),units=int(len(fr)),margin=w['margin'],P_margin=w['P_margin'],acc=w['acc'],P_acc=w['P_acc']))
        if w['P_margin']>=0.05 and k>0: break
    return res
C=pd.read_pickle('P_coord_receptor.pkl')
A=arch('endpoint_geometry','receptor')
out={'coordinate_only':ladder(C,'coord'),'archived_all_inputs':ladder(A,'arch')}
json.dump(out,open('tipping_point.json','w'),indent=1)
for k,v in out.items():
    print(k); [print(' ',r) for r in v]
