import pandas as pd, numpy as np, json, sys
from sklearn.metrics import roc_auc_score
rng=np.random.default_rng(7)
df=pd.read_pickle('frame.pkl'); CL=['Gi/o','Gq/11','Gs']; y=df.transducer_family
SD='/home/claude/sdall/'
pred=pd.read_csv(SD+'Source_Data_S11/results/microswitches/sequence_interface_audit_v1/predictions/out_of_fold_predictions.tsv',sep='\t')
VAL={'receptor':'receptor_grouped_5fold','seq50':'sequence_cluster_50_grouped_5fold','seq40':'sequence_cluster_40_grouped_5fold','seq30':'sequence_cluster_30_grouped_5fold'}
def arch(exp,val):
    a=pred[(pred.experiment==exp)&(pred.validation==VAL[val])].set_index('analysis_row_id').reindex(df.index)
    a=a[['probability_Gi/o','probability_Gq/11','probability_Gs']]; a.columns=CL; return a
multi=df.groupby('receptor_name').transducer_family.nunique(); recs=multi[multi>=2].index
sub=df[df.receptor_name.isin(recs)]
def within(P,frame=None,nperm=2000,seed=11):
    r=np.random.default_rng(seed); frame=sub if frame is None else frame
    G=[]
    for _,g in frame.groupby('receptor_name'):
        cls=sorted(g.transducer_family.unique())
        G.append((P.loc[g.index,cls].values, np.array([cls.index(t) for t in g.transducer_family]), len(cls)))
    def stat(labs):
        m=[];a=[]
        for (M,_,k),lab in zip(G,labs):
            for i,t in enumerate(lab):
                row=M[i]; alt=np.max(np.delete(row,t)); m.append(row[t]-alt); a.append(float(np.argmax(row)==t))
        return np.mean(m),np.mean(a)
    obs=stat([g[1] for g in G])
    perm=np.array([stat([r.permutation(g[1]) for g in G]) for _ in range(nperm)])
    return dict(margin=float(obs[0]),margin_perm=float(perm[:,0].mean()),P_margin=float(((perm[:,0]>=obs[0]).sum()+1)/(nperm+1)),
                acc=float(obs[1]),acc_perm=float(perm[:,1].mean()),P_acc=float(((perm[:,1]>=obs[1]).sum()+1)/(nperm+1)),
                n_rec=len(G),n_units=int(len(frame)))
def boot(P,Q,n=2000,seed=3):
    r=np.random.default_rng(seed); rec=df.receptor_name.values; recs=np.unique(rec)
    pos={x:np.where(rec==x)[0] for x in recs}
    yv=pd.Categorical(y,categories=CL).codes; Pv=P[CL].values; Qv=Q[CL].values
    out=[]
    for _ in range(n):
        s=r.choice(recs,len(recs),replace=True); idx=np.concatenate([pos[x] for x in s])
        yy=yv[idx]
        if len(set(yy))<3: continue
        try: out.append(roc_auc_score(yy,Qv[idx],multi_class='ovr',average='macro')-roc_auc_score(yy,Pv[idx],multi_class='ovr',average='macro'))
        except Exception: pass
    o=np.array(out); return float(o.mean()),[float(np.percentile(o,2.5)),float(np.percentile(o,97.5))]
val=sys.argv[1]
C=pd.read_pickle(f'P_coord_{val}.pkl'); Sq=arch('full_sequence',val)
res={'val':val,'coord_auc':float(roc_auc_score(y,C[CL].values,multi_class='ovr',average='macro',labels=CL)),
     'seq_auc':float(roc_auc_score(y,Sq[CL].values,multi_class='ovr',average='macro',labels=CL))}
d,ci=boot(C,Sq); res['seq_minus_coord']=d; res['ci']=ci
res['within']=within(C)
json.dump(res,open(f'fast_{val}.json','w'),indent=1); print(json.dumps(res))
