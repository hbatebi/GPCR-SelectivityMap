import pandas as pd, numpy as np, warnings
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore')
df=pd.read_pickle('frame.pkl'); folds=pd.read_pickle('folds.pkl'); arch=pd.read_pickle('arch.pkl'); S=pd.read_pickle('spec.pkl')
S['NUM']=[n for n in S['NUM'] if n in df.columns]
CLASSES=['Gi/o','Gq/11','Gs']
VALS={'receptor':('receptor_grouped_5fold','receptor_name'),'seq50':('sequence_cluster_50_grouped_5fold','sequence_cluster_50'),
      'seq40':('sequence_cluster_40_grouped_5fold','sequence_cluster_40'),'seq30':('sequence_cluster_30_grouped_5fold','sequence_cluster_30')}
def featsets():
    N=S['NUM']; C=S['CAT']
    full=(N,C)
    coord=( [n for n in N if n not in S['ACQ_NUM']], [c for c in C if c not in S['ACQ_CAT']] )
    strict=( [n for n in coord[0] if n not in S['COUNT_NUM']], coord[1] )
    acq=(S['ACQ_NUM'], S['ACQ_CAT'])
    return dict(full=full,coord=coord,coord_strict=strict,acq_only=acq)
def pipe(num,cat):
    tr=[('n',Pipeline([('i',SimpleImputer(strategy='median')),('s',StandardScaler())]),num)]
    if cat: tr.append(('c',Pipeline([('i',SimpleImputer(strategy='most_frequent')),('o',OneHotEncoder(handle_unknown='ignore'))]),cat))
    return Pipeline([('pre',ColumnTransformer(tr)),('lr',LogisticRegression(penalty='l2',solver='lbfgs',max_iter=5000))])
def run(num,cat,val):
    vname,gcol=VALS[val]; f=folds[vname].reindex(df.index)
    y=df.transducer_family.values; P=pd.DataFrame(np.nan,index=df.index,columns=CLASSES)
    for k in sorted(f.dropna().unique()):
        te=(f==k).values; tr=~te
        if len(set(y[te]))<3 or len(set(y[tr]))<3: continue
        X=df[num+cat]
        grp=df[gcol].values[tr]
        if len(set(grp))<2: grp=df['receptor_name'].values[tr]
        g=GridSearchCV(pipe(num,cat),{'lr__C':np.logspace(-3,2,11)},cv=GroupKFold(min(5,len(set(grp)))),scoring='neg_log_loss',n_jobs=-1)
        g.fit(X[tr],y[tr],groups=grp)
        P.loc[te]=g.predict_proba(X[te])
    return P
def macro_auc(P):
    ok=P.notna().all(1); y=df.transducer_family[ok]
    return roc_auc_score(y,P[ok][CLASSES].values,multi_class='ovr',average='macro',labels=CLASSES), ok.sum()
if __name__=='__main__':
    import sys
    out={}
    for fs,(num,cat) in featsets().items():
        for val in VALS:
            P=run(num,cat,val); P.to_pickle(f'P_{fs}_{val}.pkl')
            a,n=macro_auc(P)
            extra=''
            if fs=='full':
                A=arch.loc[VALS[val][0]].reindex(P.index); A.columns=CLASSES; ok=P.notna().all(1)
                aa=roc_auc_score(df.transducer_family[ok],A[ok].values,multi_class='ovr',average='macro')
                r=np.corrcoef(P[ok].values.ravel(),A[ok].values.ravel())[0,1]
                extra=f' archived={aa:.3f} r_prob={r:.3f}'
            print(fs,val,f'{a:.3f} n={n}{extra}',flush=True)
