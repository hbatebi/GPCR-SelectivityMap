import pandas as pd, numpy as np, json
exec(open('fast.py').read().split("val=sys.argv[1]")[0].replace("import pandas as pd, numpy as np, json, sys","import pandas as pd, numpy as np, json, sys"))
C=pd.read_pickle('P_coord_receptor.pkl')
m=pd.read_csv('/home/claude/sdall/Source_Data_S1/results/microswitches/measurements/microswitch_measurements.csv',low_memory=False)
res={}
res['all']=within(C)
# resolution-matched
g=sub.groupby('receptor_name').resolution.agg(lambda s:s.max()-s.min())
keep=g[g<=0.3].index; res['resolution_matched']=within(C,sub[sub.receptor_name.isin(keep)])
# single publication
pub=sub.groupby('receptor_name').publication_reference.nunique()
keep=pub[pub==1].index
if len(keep): res['single_publication']=within(C,sub[sub.receptor_name.isin(keep)])
# class-pair strata
pairs=sub.groupby('receptor_name').transducer_family.apply(lambda s: '+'.join(sorted(set(s))))
for p in pairs.unique():
    keep=pairs[pairs==p].index
    if len(keep)>=3: res['pair_'+p.replace('/','')]=within(C,sub[sub.receptor_name.isin(keep)])
json.dump(res,open('strata_coord.json','w'),indent=1); print(json.dumps(res,indent=1))
