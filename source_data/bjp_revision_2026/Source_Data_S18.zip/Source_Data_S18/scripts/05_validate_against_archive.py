import pandas as pd,numpy as np,json
exec(open('fast.py').read().split("val=sys.argv[1]")[0])
for val in ['receptor','seq50']:
    A=arch('endpoint_geometry',val)
    print(val, json.dumps(within(A)))
