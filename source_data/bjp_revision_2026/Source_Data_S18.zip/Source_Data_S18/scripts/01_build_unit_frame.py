import pandas as pd, numpy as np
SD='/home/claude/sdall/'
m=pd.read_csv(SD+'Source_Data_S1/results/microswitches/measurements/microswitch_measurements.csv',low_memory=False)
p=pd.read_csv(SD+'Source_Data_S11/results/microswitches/sequence_interface_audit_v1/predictions/out_of_fold_predictions.tsv',sep='\t')
p=p[p.experiment=='endpoint_geometry']
units=p[p.validation=='receptor_grouped_5fold'][['analysis_row_id','pdb_id','chain_id','receptor_name','transducer_family']].reset_index(drop=True)
folds=p.pivot_table(index='analysis_row_id',columns='validation',values='outer_fold',aggfunc='first')
arch=p.set_index(['validation','analysis_row_id'])[['probability_Gi/o','probability_Gq/11','probability_Gs']]
df=units.merge(m,on=['pdb_id','receptor_name'],how='left',suffixes=('','_m'))
cl=pd.read_csv(SD+'Source_Data_S11/results/microswitches/sequence_interface_audit_v1/audit/sequence_cluster_assignments.tsv',sep='\t')
df=df.merge(cl,on='receptor_name',how='left')
df['icl2_model_category']=np.where(df.icl2_recomputed_category=='folded','active_like','inactive_like')
coef=pd.read_csv(SD+'Source_Data_S11/results/microswitches/sequence_interface_audit_v1/coefficients/model_coefficients.tsv',sep='\t')
tf=coef[(coef.experiment=='endpoint_geometry')].transformed_feature.unique()
NUM=[t.split('__',1)[1] for t in tf if t.startswith('numeric__')]
CAT=['experimental_method','ligand_type','icl2_partial','fusion_protein','icl2_model_category']
NUM=[n for n in dict.fromkeys(NUM) if n!='activation_consensus_score']
ACQ_NUM=['resolution','year_of_deposition']; ACQ_CAT=['experimental_method','ligand_type','icl2_partial','fusion_protein']
COUNT_NUM=['icl2_n_modeled','specificity_geometry_feature_count','intracellular_cavity_feature_count','activation_consensus_feature_count']
for c in NUM:
    if c not in df: print('MISSING',c)
for c in CAT: df[c]=df[c].astype(str)
df=df.set_index('analysis_row_id')
df.to_pickle('frame.pkl'); folds.to_pickle('folds.pkl'); arch.to_pickle('arch.pkl')
pd.to_pickle(dict(NUM=NUM,CAT=CAT,ACQ_NUM=ACQ_NUM,ACQ_CAT=ACQ_CAT,COUNT_NUM=COUNT_NUM),'spec.pkl')
print(df.shape, len(NUM), df.transducer_family.value_counts().to_dict())
