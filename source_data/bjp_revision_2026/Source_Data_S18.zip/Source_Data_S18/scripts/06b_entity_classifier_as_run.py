import json,re,collections
ent=json.load(open('entities.json'))
PATS=[("scFv16", r"\bscfv\s*-?\s*16\b|single[- ]chain fragment variable\s*-?\s*16|single[- ]chain variable fragment\s*-?\s*16"),
      ("Nb35",   r"\bnb\s*-?\s*35\b|nanobody\s*-?\s*35"),
      ("Nb6B9",  r"\bnb\s*-?\s*6b9\b|nanobody\s*-?\s*6b9"),
      ("other nanobody", r"\bnanobody\b|\bvhh\b|camelid|single[- ]domain antibody"),
      ("Fab/scFv other", r"\bfab\b|\bscfv\b|single[- ]chain (?:fragment variable|variable fragment)|antibody|immunoglobulin|heavy chain variable|light chain variable"),
      ("mini-G", r"\bmini[- ]?g"),
      ("G chimera", r"chimer|fusion protein of guanine|dominant[- ]negative|g\(i\)[^,]*g\(q\)|g\(q\)[^,]*g\(i\)|gi/gq|gq/gi"),
      ("GRK/kinase", r"receptor kinase|\bgrk\b"),
      ("fusion tag", r"\bbril\b|cytochrome b562|lysozyme|flavodoxin|rubredoxin|glycogen synthase|luciferin|nanoluc|\bgfp\b"),
      ("scaffold", r"scaffold protein|\bmsp\d|saposin|nanodisc")]
STAB={"scFv16","Nb35","Nb6B9","other nanobody","Fab/scFv other"}
def classify(ds):
    hits=set()
    for d in ds:
        dl=d.lower()
        for n,p in PATS:
            if re.search(p,dl): hits.add(n)
    if hits & {"scFv16","Nb35","Nb6B9"}: hits.discard("Fab/scFv other")
    return hits
ann={p:sorted(classify(d)) for p,d in ent.items()}
json.dump(ann,open('annot.json','w'),indent=1)
c=collections.Counter(x for v in ann.values() for x in v); print(c)
none=[k for k,v in ann.items() if not (STAB & set(v))]
print('no stabiliser:',len(none),none)
