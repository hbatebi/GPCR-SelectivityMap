import pandas as pd, numpy as np, json
exec(open('fast.py').read().split("val=sys.argv[1]")[0])
ann=json.load(open('annot.json'))
STAB={"scFv16","Nb35","Nb6B9","other nanobody","Fab/scFv other"}
rows=[]
for rid,u in sub.iterrows():
    h=set(ann.get(str(u.pdb_id).upper(),[]))
    rows.append(dict(analysis_row_id=rid,pdb_id=u.pdb_id,receptor_name=u.receptor_name,
        transducer_family=u.transducer_family,stabiliser=','.join(sorted(h&STAB)) or 'none',
        engineering=','.join(sorted(h-STAB)) or 'none'))
A=pd.DataFrame(rows).set_index('analysis_row_id')
A.to_csv('stabiliser_annotation_72_units.tsv',sep='\t')
matched=[];mismatched=[]
for r,g in A.groupby('receptor_name'):
    s={frozenset(x.split(',')) for x in g.stabiliser}
    (matched if len(s)==1 else mismatched).append(r)
print('matched',len(matched),'mismatched',len(mismatched))
C=pd.read_pickle('P_coord_receptor.pkl'); AR=arch('endpoint_geometry','receptor')
out={'matched_receptors':sorted(matched),'mismatched_receptors':sorted(mismatched),
     'stabiliser_counts':A.stabiliser.value_counts().to_dict(),
     'engineering_counts':A.engineering.value_counts().to_dict()}
for name,P in [('coordinate_only',C),('archived_primary',AR)]:
    out[name]={}
    for lab,recs in [('all',A.receptor_name.unique().tolist()),('matched_stabiliser',matched),('mismatched_stabiliser',mismatched)]:
        fr=sub[sub.receptor_name.isin(recs)]
        out[name][lab]=within(P,fr,nperm=2000,seed=5) if fr.receptor_name.nunique()>=3 and fr.transducer_family.nunique()>=2 else {'skipped':len(recs)}
json.dump(out,open('stabiliser_stratified.json','w'),indent=1)
print(json.dumps(out,indent=1)[:2500])
