import pandas as pd, numpy as np
from itertools import combinations
CLS=['Gi/o','Gq/11','Gs']; PC={c:'probability_'+c for c in CLS}
d=pd.read_csv('s11/results/microswitches/sequence_interface_audit_v1/predictions/out_of_fold_predictions.tsv',sep='\t')
ca=pd.read_csv('s15/bound_construct_annotations.tsv',sep='\t')

def prep(validation='receptor_grouped_5fold',exp='endpoint_geometry'):
    b=d[(d.validation==validation)&(d.experiment==exp)].copy()
    obs=b.groupby('receptor_name').transducer_family.nunique()
    elig=sorted(obs[obs>=2].index)
    g=b[b.receptor_name.isin(elig)].copy()
    allowed={r:sorted(b.loc[b.receptor_name.eq(r),'transducer_family'].unique()) for r in elig}
    mar=[];corr=[]
    for _,r in g.iterrows():
        al=allowed[r.receptor_name]; p={c:r[PC[c]] for c in al}
        pred=max(p,key=p.get); corr.append(pred==r.transducer_family)
        mar.append(p[r.transducer_family]-max(v for k,v in p.items() if k!=r.transducer_family))
    g['margin']=mar; g['correct']=corr
    g=g.merge(ca[['pdb_id','resolution','year_of_deposition','fusion_protein','icl2_ligand',
                  'publication_reference','experimental_method','species','ligand_type']],on='pdb_id',how='left')
    g['classset']=g.receptor_name.map(lambda r:'+'.join(sorted(allowed[r])))
    return g,allowed

def perm_p(g,allowed,col='margin',nperm=10000,seed=20260926):
    rng=np.random.default_rng(seed)
    n=len(g); idx=np.arange(n)
    lab=g.transducer_family.to_numpy()
    # precompute per-unit value for each possible label
    vals=np.full((n,3),np.nan)
    for i,(_,r) in enumerate(g.iterrows()):
        al=allowed[r.receptor_name]; p={c:r[PC[c]] for c in al}
        for ci,c in enumerate(CLS):
            if c in al: vals[i,ci]=p[c]-max(v for k,v in p.items() if k!=c)
    li=np.array([CLS.index(x) for x in lab])
    obs=vals[idx,li].mean()
    groups=[np.where(g.receptor_name.to_numpy()==r)[0] for r in pd.unique(g.receptor_name)]
    null=np.empty(nperm)
    for b in range(nperm):
        y=li.copy()
        for gi in groups:
            v=y[gi].copy(); rng.shuffle(v); y[gi]=v
        null[b]=vals[idx,y].mean()
    return obs,null.mean(),(1+np.sum(null>=obs))/(nperm+1)

g,allowed=prep()
print(f"ALL 72 units: margin {g.margin.mean():+.4f}  accuracy {g.correct.mean():.4f}")
print("\n--- design-controlled covariates (constant within every eligible receptor) ---")
for c in ['experimental_method','species','ligand_type']:
    v=g.groupby('receptor_name')[c].nunique()
    print(f"  {c:20s} varies within receptor in {int((v>1).sum())}/34 receptors")

print("\n--- A. stratification by class pair (stabiliser proxy) ---")
for cs,sub in g.groupby('classset'):
    recs=sub.receptor_name.nunique()
    if recs>=3:
        o,nm,p=perm_p(sub,allowed,nperm=5000)
        print(f"  {cs:20s} receptors {recs:2d} units {len(sub):2d}  margin {o:+.4f} (perm {nm:+.4f}, P={p:.4f})")
    else:
        print(f"  {cs:20s} receptors {recs:2d} units {len(sub):2d}  margin {sub.margin.mean():+.4f} (n too small)")

print("\n--- B. same-publication subset (same lab, same paper, same construct strategy) ---")
same=[]
for r,sub in g.groupby('receptor_name'):
    if sub.publication_reference_y.notna().all() and sub.publication_reference_y.nunique()==1 and sub.transducer_family.nunique()>=2:
        same.append(r)
sp=g[g.receptor_name.isin(same)]
if len(same)>=3:
    o,nm,p=perm_p(sp,allowed,nperm=10000)
    print(f"  receptors {len(same)} units {len(sp)}  margin {o:+.4f} (perm {nm:+.4f}, P={p:.4f})")
print("  receptors:",', '.join(same))

print("\n--- C. covariate adjustment (within-receptor centred) ---")
X=g[['resolution','year_of_deposition']].astype(float).copy()
X['fusion']=g.fusion_protein.astype(str).isin(['True','1','1.0']).astype(float)
X['icl2']=g.icl2_ligand.astype(str).isin(['True','1','1.0']).astype(float)
y=g.margin.to_numpy().astype(float)
# centre everything within receptor, then regress margin on covariates and test residual margin
def wc(a,keys):
    a=pd.Series(a,index=g.index)
    return (a-a.groupby(keys).transform('mean')).to_numpy()
keys=g.receptor_name
Xc=np.column_stack([wc(X[c].to_numpy(),keys) for c in X.columns])
yc=wc(y,keys)
beta,*_=np.linalg.lstsq(np.column_stack([Xc,np.ones(len(yc))]),yc,rcond=None)
resid=y-np.column_stack([Xc,np.ones(len(yc))])@beta+beta[-1]
g2=g.copy(); g2['margin_adj']=resid
r2=1-np.var(yc-np.column_stack([Xc,np.ones(len(yc))])@beta)/np.var(yc)
print(f"  within-receptor covariates explain R^2 = {r2:.4f} of the margin variance")
print(f"  coefficients: resolution {beta[0]:+.4f}  year {beta[1]:+.5f}  fusion {beta[2]:+.4f}  ICL2-ligand {beta[3]:+.4f}")
print(f"  adjusted mean margin {resid.mean():+.4f} (unadjusted {y.mean():+.4f})")

print("\n--- D. resolution-matched subset (|delta resolution| <= 0.3 A within receptor) ---")
keep=[]
for r,sub in g.groupby('receptor_name'):
    if sub.resolution.max()-sub.resolution.min()<=0.3 and sub.transducer_family.nunique()>=2:
        keep.append(r)
rm=g[g.receptor_name.isin(keep)]
if len(keep)>=3:
    o,nm,p=perm_p(rm,allowed,nperm=10000)
    print(f"  receptors {len(keep)} units {len(rm)}  margin {o:+.4f} (perm {nm:+.4f}, P={p:.4f})")
