Source Data S17 — construct stratification, multiplicity correction and coefficient stability

Addresses the second-round points on construct confounding in the within-receptor test,
multiple comparisons across representations, and coefficient stability.

No model was refitted. All analyses reuse frozen out-of-fold predictions and fold coefficients
already archived in Source Data S3 and S11, joined to the construct annotation in Source Data S15.

CONSTRUCT STRATIFICATION (construct_stratification_results.txt, r2_1_construct.py)
  Constant within every one of the 34 eligible receptors: experimental method, species, ICL2
  completeness. Ligand type varies within one receptor only.
  Class-pair strata (margin, within-receptor permutation P):
    Gi/o + Gq/11      18 receptors, 36 units   +0.085  P = 0.038
    Gq/11 + Gs         6 receptors, 12 units   +0.101  P = 0.060
    Gi/o + Gs          6 receptors, 12 units   +0.089  P = 0.21
    three-class        4 receptors, 12 units   -0.138  P = 0.31
  Resolution-matched (<= 0.3 A within receptor): 19 receptors, 40 units, +0.074, P = 0.033
  Single-publication endpoints: 8 receptors, 16 units, +0.097, P = 0.17
  Within-receptor covariate adjustment (resolution, year, fusion, ICL2-associated ligand):
    R^2 = 0.021 of within-receptor margin variance; adjusted mean margin unchanged at +0.051.
  LIMIT: antibody-fragment and nanobody identity (for example Nb35, scFv16) are separate chains,
  not receptor fusions or ICL2 ligands, and are not curated in the deposited metadata used here.
  They could not be annotated. The Gi/o + Gq/11 stratum is the informative control because Gq/11
  complexes are routinely chimeric constructs engineered so that the antibody fragment used for
  Gi/o complexes will bind, so stabilisation chemistry is closely matched within that stratum.

MULTIPLICITY (within_receptor_multiplicity.tsv, within_receptor_S11_multiplicity.tsv)
  Benjamini-Hochberg and Bonferroni across the nine representations, computed separately for the
  two executions of the primary specification.
  Second execution: accuracy P = 0.0011, q = 0.0099, Bonferroni = 0.0099; margin P = 0.0094,
  q = 0.045, Bonferroni = 0.085.
  First execution: margin P = 0.008, q = 0.072; accuracy P = 0.041, q = 0.37.

COEFFICIENT STABILITY (coefficient_fold_stability.tsv)
  Fold-level stability of the primary coordinate model. The model is dense: all 107 features are
  retained in all five folds, so selection frequency is uninformative. Median sign consistency
  across folds and class contrasts is 0.60, which is modest. The Table S29 attribution is therefore
  descriptive only and individual coefficients should not be interpreted as feature effects.
