import pandas as pd, numpy as np
from pathlib import Path

SRC='s11/results/microswitches/sequence_interface_audit_v1/predictions/out_of_fold_predictions.tsv'
d=pd.read_csv(SRC,sep='\t')
CLS=['Gi/o','Gq/11','Gs']; PC={c:'probability_'+c for c in CLS}

base=d[(d.validation=='receptor_grouped_5fold')&(d.experiment=='endpoint_geometry')]
obs=base.groupby('receptor_name').transducer_family.nunique()
elig=sorted(obs[obs>=2].index)
allowed={r:sorted(base.loc[base.receptor_name.eq(r),'transducer_family'].unique()) for r in elig}

def evaluate(g, nperm=10000, seed=20260926):
    g=g[g.receptor_name.isin(elig)].sort_values(['receptor_name','pdb_id','chain_id']).reset_index(drop=True)
    n=len(g)
    corr=np.zeros((n,3),bool); marg=np.zeros((n,3))
    lab_idx=np.zeros(n,int)
    recs=g.receptor_name.to_numpy()
    for i,row in g.iterrows():
        al=allowed[row.receptor_name]
        probs={c:row[PC[c]] for c in al}
        pred=max(probs,key=probs.get)
        for ci,c in enumerate(CLS):
            if c in al:
                corr[i,ci]= (pred==c)
                marg[i,ci]= probs[c]-max(v for k,v in probs.items() if k!=c)
        lab_idx[i]=CLS.index(row.transducer_family)
    obs_acc=corr[np.arange(n),lab_idx].mean()
    obs_mar=marg[np.arange(n),lab_idx].mean()
    groups=[np.where(recs==r)[0] for r in pd.unique(recs)]
    rng=np.random.default_rng(seed)
    pa=np.empty(nperm); pm=np.empty(nperm)
    for b in range(nperm):
        y=lab_idx.copy()
        for idx in groups:
            v=y[idx].copy(); rng.shuffle(v); y[idx]=v
        pa[b]=corr[np.arange(n),y].mean()
        pm[b]=marg[np.arange(n),y].mean()
    return dict(n_units=n,n_receptors=len(elig),
        accuracy=obs_acc, margin=obs_mar,
        perm_acc_mean=pa.mean(), perm_acc_q975=np.quantile(pa,.975),
        perm_mar_mean=pm.mean(), perm_mar_q975=np.quantile(pm,.975),
        p_acc=(1+np.sum(pa>=obs_acc))/(nperm+1),
        p_mar=(1+np.sum(pm>=obs_mar))/(nperm+1))

VALS=[('receptor_grouped_5fold','receptor-grouped'),
      ('sequence_cluster_50_grouped_5fold','50% identity clusters'),
      ('sequence_cluster_40_grouped_5fold','40% identity clusters'),
      ('sequence_cluster_30_grouped_5fold','30% identity clusters')]
EXPS=['endpoint_geometry','full_sequence','sequence_plus_geometry','interface_sequence','global_identity_knn']

rows=[]
for v,vlab in VALS:
    for e in EXPS:
        g=d[(d.validation==v)&(d.experiment==e)]
        if len(g)==0: continue
        r=evaluate(g)
        r.update(validation=vlab, model=e); rows.append(r)
        print(f"{vlab:22s} {e:24s} acc {r['accuracy']:.4f} (perm {r['perm_acc_mean']:.4f}, P={r['p_acc']:.4f})  "
              f"margin {r['margin']:+.4f} (perm {r['perm_mar_mean']:+.4f}, P={r['p_mar']:.4f})")
out=pd.DataFrame(rows)[['validation','model','n_units','n_receptors','accuracy','perm_acc_mean','perm_acc_q975','p_acc','margin','perm_mar_mean','perm_mar_q975','p_mar']]
out.to_csv('/home/claude/within_receptor_identity_cluster.tsv',sep='\t',index=False)
print('\nwritten')
