import pandas as pd, numpy as np, json
from sklearn.model_selection import GroupKFold, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, balanced_accuracy_score
from pathlib import Path
root=Path('/mnt/data/bjp_work')
P=root/'source_data/Source_Data_S3/results/receptor_only_dynamic_selectivity/v1_full/predictions/out_of_fold_predictions.tsv'
M=root/'source_data/Source_Data_S1/results/microswitches/measurements/microswitch_measurements.csv'
C=root/'source_data/Source_Data_S11/results/microswitches/sequence_interface_audit_v1/audit/sequence_cluster_assignments.tsv'
A=root/'source_data/Source_Data_S3/results/receptor_only_dynamic_selectivity/v1_full/fold_manifests/fold_convergence_and_leakage_audit.tsv'
pred=pd.read_csv(P,sep='\t'); units=pred[pred.experiment=='existing_geometry'][['pdb_id','chain_id','receptor_name','transducer_family']].drop_duplicates()
meas=pd.read_csv(M); cl=pd.read_csv(C,sep='\t'); d=units.merge(meas,on=['pdb_id','receptor_name'],how='left',suffixes=('','_m')).merge(cl,on='receptor_name',how='left')
aud=pd.read_csv(A,sep='\t'); row=aud[aud.experiment=='existing_geometry'].iloc[0]
num=[x for x in str(row.selected_numeric_features).split(';') if x in d.columns]
cat=[x for x in str(row.selected_categorical_features).split(';') if x in d.columns]
# metadata-only explicitly separated from structural geometry
meta_num=[x for x in ['resolution'] if x in d.columns]
meta_cat=[x for x in ['experimental_method','species','ligand_type','fusion_protein','stabilising_mutations_status','nanobody_or_antibody','engineered_g_protein','engineered_construct'] if x in d.columns]
# missingness-only from geometry feature availability + coverage counts available directly
geom_raw=[x for x in num if x not in ['resolution','year_of_deposition']]
for x in geom_raw: d['missing__'+x]=d[x].isna().astype(int)
miss_num=['missing__'+x for x in geom_raw]
for x in ['n_modeled','n_total','icl2_helix_fraction','mapping_identity','mapping_receptor_coverage','mapping_observed_coverage']:
 if x in d.columns: miss_num.append(x)
miss_cat=[x for x in ['partial','gpcrdb_numbering_status','metadata_error'] if x in d.columns]
classes=['Gi/o','Gq/11','Gs']; y=d.transducer_family.to_numpy()

def run(name,nums,cats,thr,attribute=False):
 groups=d[f'sequence_cluster_{thr}'].to_numpy(); outer=GroupKFold(n_splits=5); prob=np.full((len(d),3),np.nan); attrs=[]
 for k,(tr,te) in enumerate(outer.split(d,y,groups)):
  pre=ColumnTransformer([('num',Pipeline([('imp',SimpleImputer(strategy='median',add_indicator=True)),('sc',StandardScaler())]),nums),('cat',Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('oh',OneHotEncoder(handle_unknown='ignore'))]),cats)])
  lr=LogisticRegression(solver='lbfgs',max_iter=5000,class_weight='balanced')
  pipe=Pipeline([('pre',pre),('lr',lr)])
  inner=GroupKFold(n_splits=3)
  grid=GridSearchCV(pipe,{'lr__C':[0.03,0.1,0.3,1,3]},scoring='roc_auc_ovr',cv=inner,n_jobs=-1,error_score=np.nan)
  grid.fit(d.iloc[tr],y[tr],groups=groups[tr]); pp=grid.predict_proba(d.iloc[te]);
  for j,c in enumerate(grid.classes_): prob[te,classes.index(c)]=pp[:,j]
  if attribute:
   best=grid.best_estimator_; names=best.named_steps['pre'].get_feature_names_out(); coef=best.named_steps['lr'].coef_
   for ci,c in enumerate(best.named_steps['lr'].classes_):
    for fn,v in zip(names,coef[ci]): attrs.append([k,c,fn,float(v),abs(float(v))])
 auc=roc_auc_score(y,prob,labels=classes,multi_class='ovr',average='macro'); bal=balanced_accuracy_score(y,np.array(classes)[np.nanargmax(prob,axis=1)])
 return [name,thr,len(d),d.receptor_name.nunique(),len(np.unique(groups)),auc,bal],attrs,prob
rows=[]; allattrs=[]; outpred=[]
for thr in [50,40]:
 for name,nums,cats in [('missingness_only',miss_num,miss_cat),('metadata_only',meta_num,meta_cat)]:
  r,a,p=run(name,nums,cats,thr); rows.append(r)
  z=d[['pdb_id','receptor_name','transducer_family']].copy(); z['model']=name; z['identity_threshold_pct']=thr
  for j,c in enumerate(classes): z['probability_'+c]=p[:,j]
  outpred.append(z)
# geometry at 50 for attribution
geom_num=[x for x in num if x not in ['resolution','year_of_deposition']]
r,a,p=run('geometry_primary',geom_num,cat,50,True); rows.append(r); allattrs.extend(a)
summary=pd.DataFrame(rows,columns=['model','identity_threshold_pct','n_units','n_receptors','n_clusters','macro_roc_auc','balanced_accuracy'])
summary.to_csv(root/'identity_transfer_controls.tsv',sep='\t',index=False); pd.concat(outpred).to_csv(root/'identity_transfer_control_predictions.tsv',sep='\t',index=False)
at=pd.DataFrame(allattrs,columns=['fold','class','feature','coefficient','abs_coefficient']); at.to_csv(root/'geometry_50pct_fold_coefficients.tsv',sep='\t',index=False)
agg=at.groupby('feature').abs_coefficient.agg(['mean','median','max']).sort_values('mean',ascending=False).reset_index(); agg.to_csv(root/'geometry_50pct_feature_attribution.tsv',sep='\t',index=False)
print(summary.to_string(index=False)); print('\nTOP ATTR\n',agg.head(25).to_string(index=False))
