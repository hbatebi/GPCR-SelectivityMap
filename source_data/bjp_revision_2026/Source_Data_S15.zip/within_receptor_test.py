import pandas as pd, numpy as np
from pathlib import Path
from scipy.stats import binomtest
p=Path('/mnt/data/bjp_work/source_data/Source_Data_S3/results/receptor_only_dynamic_selectivity/v1_full/predictions/out_of_fold_predictions.tsv')
d=pd.read_csv(p,sep='\t')
classes=['Gi/o','Gq/11','Gs']; pc={c:'probability_'+c for c in classes}
# eligible receptors with >=2 observed classes in base dataset
base=d[d.experiment=='existing_geometry'].copy()
obs=base.groupby('receptor_name').transducer_family.nunique()
elig=obs[obs>=2].index
print('eligible receptors',len(elig), 'units',len(base[base.receptor_name.isin(elig)]), 'class counts',base[base.receptor_name.isin(elig)].transducer_family.value_counts().to_dict())
rng=np.random.default_rng(20260926)
rows=[]
for exp,g0 in d.groupby('experiment'):
 g=g0[g0.receptor_name.isin(elig)].copy()
 correct=[]; margins=[]
 for _,r in g.iterrows():
  allowed=sorted(base.loc[base.receptor_name.eq(r.receptor_name),'transducer_family'].unique())
  probs={c:r[pc[c]] for c in allowed}
  pred=max(probs,key=probs.get)
  correct.append(pred==r.transducer_family)
  truep=probs[r.transducer_family]
  other=max(v for k,v in probs.items() if k!=r.transducer_family)
  margins.append(truep-other)
 acc=np.mean(correct); mm=np.mean(margins)
 # permutation labels within receptor, preserving receptor-specific observed labels exactly
 perms=[]; mperms=[]
 for b in range(10000):
  gp=g.copy(); labels=[]
  for rec,idx in gp.groupby('receptor_name').groups.items():
   vals=gp.loc[idx,'transducer_family'].to_numpy().copy(); rng.shuffle(vals); labels.extend(zip(idx,vals))
  lab=dict(labels); cc=[]; mm2=[]
  for idx,r in gp.iterrows():
   y=lab[idx]; allowed=sorted(base.loc[base.receptor_name.eq(r.receptor_name),'transducer_family'].unique())
   probs={c:r[pc[c]] for c in allowed}; pred=max(probs,key=probs.get)
   cc.append(pred==y); mm2.append(probs[y]-max(v for k,v in probs.items() if k!=y))
  perms.append(np.mean(cc)); mperms.append(np.mean(mm2))
 pacc=(1+np.sum(np.array(perms)>=acc))/(len(perms)+1)
 pmar=(1+np.sum(np.array(mperms)>=mm))/(len(mperms)+1)
 rows.append([exp,len(g),len(elig),acc,mm,np.mean(perms),np.quantile(perms,.025),np.quantile(perms,.975),pacc,np.mean(mperms),np.quantile(mperms,.025),np.quantile(mperms,.975),pmar])
out=pd.DataFrame(rows,columns=['model','n_units','n_receptors','within_receptor_accuracy','mean_true_minus_best_other','perm_mean_accuracy','perm_acc_q025','perm_acc_q975','perm_p_accuracy','perm_mean_margin','perm_margin_q025','perm_margin_q975','perm_p_margin']).sort_values('within_receptor_accuracy',ascending=False)
out.to_csv('/mnt/data/bjp_work/within_receptor_multiclass_test.tsv',sep='\t',index=False)
print(out.to_string(index=False))
