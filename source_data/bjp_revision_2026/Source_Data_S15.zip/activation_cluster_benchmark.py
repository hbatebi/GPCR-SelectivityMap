import pandas as pd, numpy as np
from sklearn.model_selection import GroupKFold, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, balanced_accuracy_score
from sklearn.utils import resample
M='/mnt/data/bjp_work/source_data/Source_Data_S1/results/microswitches/measurements/microswitch_measurements.csv'
C='/mnt/data/bjp_work/source_data/Source_Data_S11/results/microswitches/sequence_interface_audit_v1/audit/sequence_cluster_assignments.tsv'
d=pd.read_csv(M); cl=pd.read_csv(C,sep='\t')
d=d.merge(cl,on='receptor_name',how='inner')
features=['tm6_r350_634_distance','tm3_tm7_distance','pif_550_644_min_distance','y753_displacement']
d=d[d.activation_state.isin(['active','inactive'])].copy(); d['y']=(d.activation_state=='active').astype(int)
print('n',len(d),'receptors',d.receptor_name.nunique(),'active',d.y.sum(),'inactive',(1-d.y).sum())
rows=[]; preds=[]
for thr in [50,40]:
 groupcol=f'sequence_cluster_{thr}'
 X=d[features]; y=d.y.to_numpy(); groups=d[groupcol].to_numpy()
 outer=GroupKFold(n_splits=5); oof=np.full(len(d),np.nan); fold=np.full(len(d),-1)
 for k,(tr,te) in enumerate(outer.split(X,y,groups)):
  pipe=Pipeline([('imp',SimpleImputer(strategy='median',add_indicator=True)),('sc',StandardScaler()),('lr',LogisticRegression(penalty='elasticnet',solver='saga',max_iter=5000,class_weight='balanced',random_state=20260926))])
  inner=GroupKFold(n_splits=min(3,len(np.unique(groups[tr]))))
  grid=GridSearchCV(pipe,{'lr__C':[0.05,0.2,1,5],'lr__l1_ratio':[0,0.25,0.5]},scoring='roc_auc',cv=inner,n_jobs=-1)
  grid.fit(X.iloc[tr],y[tr],groups=groups[tr]); oof[te]=grid.predict_proba(X.iloc[te])[:,1]; fold[te]=k
 auc=roc_auc_score(y,oof); bal=balanced_accuracy_score(y,oof>=0.5)
 # receptor cluster bootstrap CI (resample clusters)
 rng=np.random.default_rng(20260926+thr); u=np.unique(groups); vals=[]
 for b in range(2000):
  ug=rng.choice(u,len(u),replace=True); idx=np.concatenate([np.where(groups==g)[0] for g in ug])
  if len(np.unique(y[idx]))==2: vals.append(roc_auc_score(y[idx],oof[idx]))
 lo,hi=np.quantile(vals,[.025,.975])
 rows.append([thr,len(d),d.receptor_name.nunique(),len(u),auc,lo,hi,bal])
 z=d[['pdb_id','chain_id','receptor_name','activation_state',groupcol]].copy(); z['outer_fold']=fold; z['probability_active']=oof; z['y_true']=y; z['identity_threshold']=thr; preds.append(z)
out=pd.DataFrame(rows,columns=['identity_threshold_pct','n_structures','n_receptors','n_clusters','roc_auc','cluster_bootstrap_ci_low','cluster_bootstrap_ci_high','balanced_accuracy'])
out.to_csv('/mnt/data/bjp_work/activation_identity_cluster_benchmark.tsv',sep='\t',index=False); pd.concat(preds).to_csv('/mnt/data/bjp_work/activation_identity_cluster_predictions.tsv',sep='\t',index=False)
print(out.to_string(index=False))
