Source Data S15 — focused Reviewer-2 follow-up analyses (2026-09-26)

This package contains post-v0.4.0 sensitivity analyses requested during final revision:
1) activation benchmark under 50% and 40% sequence-identity cluster splits using the prespecified four-feature activation geometry;
2) within-receptor multiclass test using existing out-of-fold captured-class probabilities;
3) 50%/40% identity-cluster missingness-only and year-excluded metadata-only controls;
4) foldwise coefficient attribution for the existing endpoint-geometry model at 50% identity (derived from Source Data S11 coefficients);
5) permutation null for the deformation-vector cosine diagnostic;
6) archive-wide construct/context annotation for the 207 bound units; and
7) the 28 mapped structural units whose captured family is not supported in the frozen Hauser et al. (2022) common coupling map.

These analyses do not replace the frozen v0.4.0 outputs. They are a transparent final-revision supplement. Absence of a coupling in the Hauser map is not interpreted as evidence of biological non-coupling.
