Source Data S10

Static-extension model predictions, paired differences, permutations and transfer to receptor-only coordinate reference sets.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
