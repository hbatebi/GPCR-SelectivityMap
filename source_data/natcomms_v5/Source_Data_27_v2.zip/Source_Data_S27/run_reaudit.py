#!/usr/bin/env python3
"""Re-audit GPCR functional claims from clean OOF scores and published Masuho workbook.
Receptor-clustered uncertainty; no tuning to held-out labels; direct labels versus Gq/G15 family sensitivity.
Run: python run_reaudit.py --workbook mmc2.xlsx --sd25 S25/Source_Data_S25 --sd26 S26/Source_Data_S26 --sd22 S22/out --out OUT
"""
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import rankdata
from artifact_tool import Blob, SpreadsheetFile

ap=argparse.ArgumentParser()
for a in ('workbook','sd25','sd26','sd22','out'):ap.add_argument('--'+a,required=True)
p=ap.parse_args(); out=Path(p.out);out.mkdir(parents=True,exist_ok=True)
F=['Gi/o','Gq/11','Gs']; C=['p_Gi_o','p_Gq_11','p_Gs']; FC={'receptor':'receptor_grouped_5fold','seq50':'sequence_cluster_50_grouped_5fold','seq40':'sequence_cluster_40_grouped_5fold','seq30':'sequence_cluster_30_grouped_5fold'}
U=pd.read_csv(Path(p.sd26)/'clean_model_predictions_by_unit.tsv',sep='\t')
T=pd.read_csv(Path(p.sd22)/'receptor_traits.tsv',sep='\t'); rec_order=T.receptor.tolist(); recidx={r:i for i,r in enumerate(rec_order)}
ident=np.load(Path(p.sd22)/'identity_matrix.npy');assert ident.shape==(len(T),len(T))
mapt=pd.read_csv(Path(p.sd25)/'S20_gene_to_receptor_mapping.tsv',sep='\t')
print('map columns',mapt.columns.tolist())
# Read raw data with workbook library, preserving number-vs-text distinction.
wb=SpreadsheetFile.import_xlsx(Blob.load(str(p.workbook)))
raw=wb.worksheets.get_item('Raw Data').get_range('A4:W136').values
raw_rows=[];bad=[]
for rownum,row in enumerate(raw,4):
 gene=str(row[1]).strip() if row[1] is not None else ''
 if not gene: continue
 vals={}
 for k,ix in [('Gi/o',13),('Gq/11',15),('G15',17),('Gs',19)]:
  value=row[ix]
  if value is None or str(value).strip()=='':
   vals[k]=np.nan;bad.append(dict(row=rownum,gene=gene,family=k,value='blank'))
  else:
   try: vals[k]=float(value)
   except (ValueError,TypeError):vals[k]=np.nan;bad.append(dict(row=rownum,gene=gene,family=k,value=str(value)))
 raw_rows.append(dict(gene=gene,isoform=str(row[0]),**vals))
rawf=pd.DataFrame(raw_rows)
allcnt=rawf[['Gi/o','Gq/11','G15','Gs']].describe().to_dict()
print('raw rawcount',len(rawf),'missing-nonnumeric',len(bad), 'HTR7 rows',rawf[rawf.gene=='HTR7'].to_dict('records'))
# First isoform per gene as S25, joined to structural receptor entry IDs
rawf=rawf.drop_duplicates('gene',keep='first')
E=rawf.merge(mapt[['hgnc_gene_symbol','receptor_entry_name']],left_on='gene',right_on='hgnc_gene_symbol',how='inner').set_index('receptor_entry_name')
E['Gq_or_15']=E[['Gq/11','G15']].max(axis=1)
print('mapped',len(E),'matrix receptor overlaps',len(set(E.index)&set(rec_order)))
# Report missing and zero separately; a blank cannot become negative.
missing=E[list(F)+['G15']].isna().sum().to_dict()
if not E[['Gi/o','Gq/11','G15','Gs']].isna().sum().sum()==0:print('WARNING missing assays in cohort',missing)


def auc(y,s):
 y=np.asarray(y,bool);s=np.asarray(s,float); sel=np.isfinite(s)
 y=y[sel];s=s[sel];n1=y.sum();n0=len(y)-n1
 if not n1 or not n0:return np.nan
 return float((rankdata(s)[y].sum()-n1*(n1+1)/2)/(n1*n0))
def family_auc(y,s,f):
 return np.array([auc(y[f==j],s[f==j]) for j in range(3)])
def macro(y,s,f):
 return np.nanmean(family_auc(y,s,f))
def bootci(y,s,f,rec,nb=2000,seed=1907):
 rng=np.random.default_rng(seed);uniq=np.unique(rec);block={r:np.flatnonzero(rec==r) for r in uniq};vals=[]
 for _ in range(nb):
  ii=np.concatenate([block[r] for r in rng.choice(uniq,size=len(uniq),replace=True)])
  vals.append(macro(y[ii],s[ii],f[ii]))
 return np.nanquantile(vals,[0.025,0.975])
def diffci(y,s,t,f,rec,nb=2000,seed=1907):
 rng=np.random.default_rng(seed);uniq=np.unique(rec);block={r:np.flatnonzero(rec==r) for r in uniq};vals=[]
 for _ in range(nb):
  ii=np.concatenate([block[r] for r in rng.choice(uniq,size=len(uniq),replace=True)])
  vals.append(macro(y[ii],s[ii],f[ii])-macro(y[ii],t[ii],f[ii]))
 return np.nanquantile(vals,[0.025,0.975])

# Include all 94 units for direct and alternative G15-based label robustness.
labels=[];famrows=[];compare=[];grids=[]
for v in FC:
 d=U[(U.validation==v)&U.receptor_name.isin(E.index)].copy().reset_index(drop=True)
 assert len(d)==94 and d.receptor_name.nunique()==77,(v,len(d),d.receptor_name.nunique())
 for i,rr in d.iterrows():
  for j,f in enumerate(F):
   if f==rr.captured_family:continue
   rate=E.loc[rr.receptor_name,f];alt=E.loc[rr.receptor_name,'Gq_or_15'] if f=='Gq/11' else rate
   labels.append(dict(validation=v,analysis_row_id=rr.analysis_row_id,receptor=rr.receptor_name,captured_family=rr.captured_family,family=f,score=float(rr[C[j]]),rate_qonly=rate,rate_gq15=alt,det_qonly=(rate>0) if pd.notna(rate) else np.nan,det_gq15=(alt>0) if pd.notna(alt) else np.nan))
L=pd.DataFrame(labels);L.to_csv(out/'label_definition_pairs.tsv',sep='\t',index=False)
for v,d in L.groupby('validation',sort=False):
 f=d.family.map({x:i for i,x in enumerate(F)}).to_numpy(int);score=d.score.to_numpy(float);rec=d.receptor.to_numpy()
 for definition,key in [('Gaq_only','det_qonly'),('Gaq_or_Ga15','det_gq15')]:
  dd=d[pd.notna(d[key])];ff=dd.family.map({x:i for i,x in enumerate(F)}).to_numpy(int);ss=dd.score.to_numpy(float);rr=dd.receptor.to_numpy(); yy=dd[key].to_numpy(bool)
  per=family_auc(yy,ss,ff);m=macro(yy,ss,ff);lo,hi=bootci(yy,ss,ff,rr)
  compare.append(dict(validation=v,definition=definition,n_pairs=len(dd),n_receptors=dd.receptor.nunique(),macro_auc=m,ci_low=lo,ci_high=hi))
  for j,fam in enumerate(F):
   sel=(ff==j);famrows.append(dict(validation=v,definition=definition,family=fam,n=int(sel.sum()),positives=int(yy[sel].sum()),negative=int((~yy[sel]).sum()),auc=per[j]))
 pdn=d[(d.det_qonly.notna()) & (d.det_gq15.notna())]
 grids.append(dict(validation=v,n_label_changes=int((pdn.det_qonly!=pdn.det_gq15).sum()),n_rows=len(pdn)))
pd.DataFrame(compare).to_csv(out/'label_sensitivity_auc.tsv',sep='\t',index=False,float_format='%.6f')
pd.DataFrame(famrows).to_csv(out/'family_counts_and_auc.tsv',sep='\t',index=False,float_format='%.6f')
pd.DataFrame(grids).to_csv(out/'label_differences.tsv',sep='\t',index=False)
pd.DataFrame(bad).to_csv(out/'non_numeric_assay_cells.tsv',sep='\t',index=False)

# Matched sequence-neighbour benchmark on 63 receptors with identity positions.
# The functional label is derived consistently from the same primary Gaq workbook, not the alternate S22 max(Gaq,Ga15).
# Candidate NN pool is limited to recipients of a structural evaluation unit in the functional panel.
# This keeps crossvalidation receptor-level and avoids using extra test-panel receptors as if trained.
nnrows=[];nn_summary=[];pairs=[]
for v,fc in FC.items():
 d=U[(U.validation==v)&U.receptor_name.isin(E.index)&U.receptor_name.isin(recidx)].copy().reset_index(drop=True)
 cohort=set(d.receptor_name.unique())
 assert d.receptor_name.nunique()==63
 folds=d.groupby('receptor_name')[fc].first().to_dict()
 for i,rr in d.iterrows():
  # train receptors: within the exact 63-receptor overlapping evaluation cohort, outside query fold;
  # do not query target on test, even if multiple structural units from the same receptor.
  q=rr.receptor_name
  donors=[r for r in cohort if r!=q and folds[r]!=folds[q]]
  sim=np.array([ident[recidx[q],recidx[z]] for z in donors]);ordr=np.argsort(-sim)
  donors=np.array(donors)[ordr];sim=sim[ordr]
  for j,f in enumerate(F):
   if f==rr.captured_family:continue
   rate=E.loc[q,f]; yy=bool(rate>0)
   act=np.array([(E.loc[z,f]>0) for z in donors],float)
   def topk(k,power):
    v=sim[:k]**power
    return float(np.dot(v,act[:k])/v.sum()) if v.sum()>0 else float(act[:k].mean())
   a=dict(validation=v,receptor=q,unit=rr.analysis_row_id,family=f,fold=folds[q],label=yy,geometry=rr[C[j]],n_donors=len(donors),max_donor_identity=sim[0],NN1=act[0],NN5=topk(5,1),NN5p8=topk(5,8),NNallp8=topk(len(donors),8))
   pairs.append(a)
N=pd.DataFrame(pairs);N.to_csv(out/'functional_sequence_baseline_pairs.tsv',sep='\t',index=False,float_format='%.7f')
for v,d in N.groupby('validation',sort=False):
 y=d.label.to_numpy(bool);f=d.family.map({x:i for i,x in enumerate(F)}).to_numpy(int);r=d.receptor.to_numpy();s=d.geometry.to_numpy(float)
 for model in ['geometry','NN1','NN5','NN5p8','NNallp8']:
  t=d[model].to_numpy(float);m=macro(y,t,f);lo,hi=bootci(y,t,f,r,seed=9903)
  ci_diff=(np.nan,np.nan) if model=='geometry' else diffci(y,s,t,f,r,seed=9903)
  nn_summary.append(dict(validation=v,model=model,auc=m,ci_low=lo,ci_high=hi,geometry_minus_baseline=m if model=='geometry' else macro(y,s,f)-m,delta_lo=ci_diff[0],delta_hi=ci_diff[1],n_receptors=d.receptor.nunique(),n_pairs=len(d)))
pd.DataFrame(nn_summary).to_csv(out/'functional_sequence_baselines.tsv',sep='\t',index=False,float_format='%.6f')
# Diagnoses
print('\nLABEL_AUC\n',pd.DataFrame(compare).to_string(index=False,float_format=lambda x:f'{x:.3f}'))
print('\nFAMILY_COUNTS\n',pd.DataFrame(famrows).query('validation == "receptor"').to_string(index=False))
print('\nSEQUENCE_BASELINES\n',pd.DataFrame(nn_summary).pivot(index='validation',columns='model',values='auc').to_string(float_format=lambda x:f'{x:.3f}'))
meta=dict(original_file=str(p.workbook),cohort=77,structural_units=94,receptor_subset_NN=63,n_boot=2000,seed=1907,sequence_baseline_description='Sequence identity only, fixed 1-NN / 5-NN and weighted sensitivities, training donors restricted to other receptors in 63-receptor cohort and outside the same held-out fold; functional labels from Masuho Gaq-only or separately max(Gaq,Ga15); not strictly like-for-like due supervised donor kinetics versus captured-class structural training.',limitations=['Same experiment for model evaluation and NN donor labels, not independent second laboratory','No normalization for assay threshold or ligand context','External predicted-complex validation not performed.'])
(out/'analysis_manifest.json').write_text(json.dumps(meta,indent=2))
