from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
from PIL import Image
B=Path(__file__).resolve().parent
L=pd.read_csv(B/'label_sensitivity_auc.tsv',sep='\t'); N=pd.read_csv(B/'functional_sequence_baselines.tsv',sep='\t')
CONC=[(.837,.72,.93,43),(.84,.68,.96,25),(.731,.538,.885,26)]
VAL=['receptor','seq50','seq40','seq30']; X=np.arange(4)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'savefig.pad_inches':0.07})
fig=plt.figure(figsize=(7.08,4.65));gs=fig.add_gridspec(2,2,height_ratios=[1,1.05],hspace=.57,wspace=.40)
a=fig.add_subplot(gs[0,0]);b=fig.add_subplot(gs[0,1]);c=fig.add_subplot(gs[1,:]);
a.bar(np.arange(3),[v[0] for v in CONC],color=['#268b85','#8c65b6','#d48f3d'],width=.6)
a.errorbar(np.arange(3),[v[0] for v in CONC],yerr=[[v[0]-v[1] for v in CONC],[v[2]-v[0] for v in CONC]],fmt='none',ecolor='#273540',capsize=3,lw=1.1)
a.set_xticks(np.arange(3),['Gi/o','Gq/11','Gs']);a.set_ylim(0,1.08);a.set_ylabel('Fraction captured family is fastest')
for i,v in enumerate(CONC):a.text(i,v[0]+.12,f'n = {v[3]}',ha='center',fontsize=7)
a.set_title('A   Captured family vs measured fastest',loc='left',pad=7)
for definition,lab,color,marker in [('Gaq_only','Gαq-only','#167c89','o'),('Gaq_or_Ga15','Gαq or Gα15','#b76b35','s')]:
 d=L[L.definition==definition].set_index('validation').loc[VAL]
 y=d.macro_auc.to_numpy(); lo=d.ci_low.to_numpy();hi=d.ci_high.to_numpy()
 b.errorbar(X,y,yerr=[y-lo,hi-y],marker=marker,color=color,label=lab,linewidth=1.6,capsize=2.5,markersize=4)
b.axhline(.5,color='#8c929a',lw=.9,ls=':');b.set_ylim(.25,.90);b.set_xticks(X,['Receptor\ngrouped','50%','40%','30%']);b.set_ylabel('Family-mean ROC AUC');b.set_title('B   Non-captured activation: 77 receptors',loc='left',pad=7);b.legend(frameon=False,loc='lower left',fontsize=7)

for name,lab,color,marker in [('geometry','Clean geometry','#167c89','o'),('NN5','Sequence 5-NN','#77679d','D')]:
 d=N[N.model==name].set_index('validation').loc[VAL]; y=d.auc.to_numpy();lo=d.ci_low.to_numpy();hi=d.ci_high.to_numpy()
 c.errorbar(X,y,yerr=[y-lo,hi-y],marker=marker,color=color,label=lab,lw=1.8,capsize=3,markersize=4.5)
c.axhline(.5,color='#8c929a',lw=.9,ls=':');c.set_ylim(.23,1.0);c.set_xticks(X,['Receptor-grouped','50%','40%','30%']);c.set_ylabel('Family-mean ROC AUC');c.set_title('C   Matched non-captured activation: 63 receptors',loc='left',pad=7);c.legend(frameon=False,loc='upper right',ncol=2)

for ax in (a,b,c):
 ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.16)
fig.text(.5,.01,'Panel B: measured activation > 0, label-definition sensitivity. Panel C: sequence baseline uses training-receptor kinetic labels;\nCIs are receptor-clustered; 30% split has only two usable folds. No panel predicts absolute rates.',ha='center',va='bottom',fontsize=6.5,color='#434d58')
fig.subplots_adjust(left=.105,right=.985,top=.93,bottom=.105)
out=B/'figure2_reproduction';out.mkdir(exist_ok=True,parents=True)
fig.savefig(out/'Figure_2.tif',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
fig.savefig(out/'Figure_2.png',dpi=300)
print(out/'Figure_2.tif',Image.open(out/'Figure_2.tif').size)
