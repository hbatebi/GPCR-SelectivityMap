# Source Data 27 | Editorial-revision scientific checks (4 November 2026)

This is a **post hoc robustness audit**, not new experimental data. All model probabilities were frozen before these analyses; no test-fold retraining was performed here. These checks were prompted by a skeptical editorial assessment.

## Main files
- `run_reaudit.py`: read the Masuho et al. 2023 published `mmc2.xlsx` workbook (not redistributed); count assay numeric/non-numeric entries; compare a Gαq-only family definition against Gαq-or-Gα15; evaluate clean structural scores against held-out sequence-neighbour controls on matched receptors; 2,000 receptor-cluster bootstrap resamples.
- `label_sensitivity_auc.tsv`, `family_counts_and_auc.tsv`, `label_definition_pairs.tsv`: transparently report both primary and secondary activation labels and their effects.
- `functional_sequence_baselines.tsv` and `functional_sequence_baseline_pairs.tsv`: the 63-receptor matched comparison of structure and sequence-nearest-neighbour methods. The 1NN and 5NN baselines use experimentally measured activation labels for other receptors outside the query's held-out fold and therefore have **different supervision** from the captured-class geometry model. Comparisons are informative but cannot establish independent geometric information. We do not select a sequence parameterization by held-out test performance; the prespecified NN5 is the primary descriptive comparator and the others sensitivity tests. Paired intervals are receptor-clustered.
- `tedman_surface_expression.tsv` and `expression_audit.py`: external plasma-membrane expression sensitivity for 75 receptors using canonical values derived from Tedman et al., *Nature Communications* (2026), via Howard et al. public `basal_vs_tedman_pme.csv` (link below). This is a different HEK293T setting and not a matched Masuho experiment.
- `expression_results.txt`, `expression_stratified_auc.tsv`: exploratory confound checks. The lower tertile has no Gs positives, so the macro AUC there is missing its Gs component and is not directly comparable with other tertiles.
- `reproduce_clean_functional_from_frozen_pairs.py`: independent computation of clean AUC and receptor-clustered intervals from the frozen row-level labels and scores in Source Data 25, without `artifact_tool` or the external workbook. It **does not reverify Masuho workbook parsing**.

## Data provenance and citations
- Masuho et al., *Cell Reports* (2023), Supplementary Table S1 (`mmc2.xlsx`), external workbook to be downloaded from the publisher.
- Tedman et al., “Efficient experimental characterization of the GPCRome via deep receptor scanning,” *Nature Communications* (2026), DOI https://doi.org/10.1038/s41467-026-76564-7; canonical surface-expression values in https://github.com/matthewkarlhoward/2026_GPCRome_basal_cAMP/blob/main/data/processed/basal_vs_tedman_pme.csv. Data derived from Tedman et al., CC BY 4.0; only the 75 overlap values are copied here for analysis.
- Source Data 22: aligned 64-position identity matrix (69 receptors) and original phylogenetic traits, whose Gq/11 rate is **max(Gαq,Gα15)**, not Gαq alone. The original 2023 Masuho workbook measures both, hence this is a valid but different functional operationalization, not a data-transcription correction.
- Source Data 25/26: annotation-free frozen coordinates and cross-platform analysis.

## Critical interpretation
1. **Structural class inference (captured family):** clean geometry exceeds the tested 64-position sequence representation at 50% and 40% separation with paired confidence intervals excluding zero (Source Data 24). This is a distinct prediction target.
2. **Functional detection:** the 0.705 AUC holds for the **Gαq-only** family definition, but the Gαq-or-Gα15 definition yields AUC 0.620. It is therefore assay-definition sensitive. Gs contributes only 6 positive non-captured pairs under the primary labels.
3. **Functional sequence comparison:** sequence nearest-neighbour methods can exceed geometry with close homologues available. At 50% the 63-receptor geometry score is higher than the fixed NN5 baseline, but paired CIs include zero; at 40% the advantage is small and not significant. Do not assert that the functional geometric advantage is established.
4. **30% identity:** few usable folds; do not infer a biological universal threshold or 'loss of information'.
5. **Expression:** no significant overall Spearman association is observed with uncaptured-family detection fraction (n=75), but indirect HEK293T measurements cannot rule out a platform-specific expression confound.
6. **External assays:** missing readouts mean unreported, not true negative. These datasets do not replicate the Masuho kinetic detection endpoint.

## Reproduce
```
python reproduce_clean_functional_from_frozen_pairs.py ../Source_Data_S25/clean_functional_validation_non_captured_pairs.tsv
python run_reaudit.py --workbook /path/to/mmc2.xlsx --sd25 ../Source_Data_S25 --sd26 ../Source_Data_S26 --sd22 ../Source_Data_22/out --out .
python expression_audit.py
```
Recommended pinned dependencies: python >= 3.10; numpy >=1.24; pandas >=2.0; scipy >=1.10; artifact_tool (only for original Excel workbook ingest). No external workbook is required for the frozen-pair AUC reproduction.

## Integrity/limits
No out-of-archive test on GPCRs with no deposited complex was performed in this revision. The GproteinDb AF2-Multimer models are a future independent test only if receptors, features, folds and model inputs can be frozen without leakage. This archive does not establish the mechanism or timing of transducer selection.

## Standalone subset bundled here
A frozen snapshot of `clean_functional_validation_non_captured_pairs.tsv` and `S20_gene_to_receptor_mapping.tsv` is included. Run:
```
python reproduce_clean_functional_from_frozen_pairs.py clean_functional_validation_non_captured_pairs.tsv
python expression_audit.py
python reproduce_Figure_2.py
```
`run_reaudit.py` is the separate full-workbook verification, requiring a legally downloaded `mmc2.xlsx` and Source Data 22 identity matrix plus the original source score tables. It should not be described as standalone from this archive.
