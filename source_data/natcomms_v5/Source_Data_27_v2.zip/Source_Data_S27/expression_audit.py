#!/usr/bin/env python3
"""External-expression sensitivity based on Tedman 2026 processed canonical PME in Howard et al. public GitHub data. Not Masuho's experimental cell-surface measurements."""
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import spearmanr, rankdata, mannwhitneyu
B=Path(__file__).resolve().parent
E=pd.read_csv(B/'tedman_surface_expression.tsv',sep='\t')
L=pd.read_csv(B/'label_definition_pairs.tsv',sep='\t')
M=pd.read_csv(B/'S20_gene_to_receptor_mapping.tsv',sep='\t')
E=E.merge(M[['hgnc_gene_symbol','receptor_entry_name']],left_on='symbol',right_on='hgnc_gene_symbol')
L=L.merge(E[['receptor_entry_name','tedman_pme']],left_on='receptor',right_on='receptor_entry_name',how='left')
D=L[L.validation=='receptor'].copy()
D['log10_surface']=np.log10(D.tedman_pme)
R=D.groupby('receptor',as_index=False).agg(tedman_pme=('tedman_pme','first'),n_detected_noncaptured=('det_qonly','first'),noncap_detected=('det_qonly','sum'),n_units=('analysis_row_id','nunique'))
# Prefer unique receptors and reconstruct their THREE-family kinetic labels from a pair table only where possible.
# Assay presence across noncaptured families varies with captured class and #complex; rate content of captured family must come from workbook.
R['noncap_fraction']=D.groupby('receptor').det_qonly.mean().values
R=R[pd.notna(R.tedman_pme)]
sp=spearmanr(np.log10(R.tedman_pme),R.noncap_fraction)
# Each family on full independent rows; tertile-specific AUC, no confidence intervals when too few positives.
D=D[pd.notna(D.tedman_pme)].copy(); D['expression_tertile']=pd.qcut(D.tedman_pme.rank(method='dense'),3,labels=['low','middle','high'])
def auc(y,s):
 y=np.asarray(y,bool);s=np.asarray(s,float);n1=y.sum();n0=len(y)-n1
 return (rankdata(s)[y].sum()-n1*(n1+1)/2)/(n1*n0) if n1 and n0 else np.nan
rows=[]
for tert,grp in D.groupby('expression_tertile',observed=True):
 a=[];n=[]
 for fam,g in grp.groupby('family'):
  a.append(auc(g.det_qonly,g.score));n.append((fam,len(g),int(g.det_qonly.sum())))
 rows.append(dict(tertile=str(tert),n_receptors=grp.receptor.nunique(),n_pairs=len(grp),n_positive=int(grp.det_qonly.sum()),macro_auc=float(np.nanmean(a)),per_family=str(n),median_surface=float(grp.tedman_pme.median())))
pd.DataFrame(rows).to_csv(B/'expression_stratified_auc.tsv',sep='\t',index=False)
R.to_csv(B/'expression_receptor_summary.tsv',sep='\t',index=False)
print('n',len(R),'rho',sp.statistic,'p',sp.pvalue); print(pd.DataFrame(rows).to_string(index=False));
for gene in ['CNR1','SUCNR1','TACR1','HCRTR2']:
 e=E[E.symbol==gene];print(gene,e[['tedman_pme']].to_dict('records'))
(B/'expression_results.txt').write_text(f'External expression Spearman rho {sp.statistic:.5f}; p {sp.pvalue:.5f}; {len(R)} receptors. Measured in HEK293T cells with constructs distinct from Masuho; indirect proxy, not a matched cell-surface expression control.\nSource: Tedman et al. Nature Communications 2026 https://doi.org/10.1038/s41467-026-76564-7, processed canonical values from https://github.com/matthewkarlhoward/2026_GPCRome_basal_cAMP/blob/main/data/processed/basal_vs_tedman_pme.csv\n')
