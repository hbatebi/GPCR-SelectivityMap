#!/usr/bin/env python3
"""Reproduce clean functional AUC and receptor-block 95% CI from shipped Source Data 25 pairs.
Requires only numpy, pandas, scipy. The published mmc2.xlsx source is NOT needed for this
second-stage verification because frozen, gene-mapped assay labels are included in S25.
It does NOT independently verify transcription from the original Masuho workbook.
"""
import argparse
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import rankdata
ap=argparse.ArgumentParser();ap.add_argument('pair_table',type=Path);ap.add_argument('--boot',type=int,default=2000);a=ap.parse_args()
d=pd.read_csv(a.pair_table,sep='\t');F=['Gi/o','Gq/11','Gs']
def auc(y,s):
 y=np.asarray(y,bool);s=np.asarray(s,float);n1=y.sum();n0=len(y)-n1
 return float((rankdata(s)[y].sum()-n1*(n1+1)/2)/(n1*n0)) if n1 and n0 else np.nan
def macro(df):
 return float(np.nanmean([auc(z.detectable_activation,z.predicted_class_probability) for fam,z in df.groupby('test_family')]))
for v,grp in d.groupby('validation',sort=False):
 recs=grp.receptor_name.unique(); blocks={r:grp[grp.receptor_name.eq(r)] for r in recs}; rng=np.random.default_rng(20261104); out=[]
 for k in range(a.boot):
  draw=pd.concat([blocks[r] for r in rng.choice(recs,len(recs),replace=True)],ignore_index=True)
  out.append(macro(draw))
 ci=np.nanquantile(out,[0.025,0.975])
 print(f'{v}\tunits={grp.analysis_row_id.nunique()}\treceptors={len(recs)}\tauc={macro(grp):.5f}\tCI={ci[0]:.4f}-{ci[1]:.4f}')
