Source Data S11

Sequence-interface audit, sequence-cluster assignments, identity neighbours, matched noninterface controls, coefficient localisation, paired differences, convergence audits and label provenance.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
