#!/usr/bin/env python3
import itertools
import numpy as np
import pandas as pd

df = pd.read_csv("paired_per_receptor_deltas.csv")
x = df["paired_difference"].to_numpy(float)
obs = float(np.mean(x))
null = np.array([np.mean(x*np.array(s)) for s in itertools.product([-1,1], repeat=len(x))])
p = float(np.mean(np.abs(null) >= abs(obs)-1e-12))
print(f"n={len(x)}; positive={(x>0).sum()}; mean={obs:.6f}; exact_two_sided_sign_flip_p={p:.8f}")
