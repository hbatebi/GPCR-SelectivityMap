Source Data S13

Receptor-level paired classification margins and exact sign-flip analysis reconstructed directly from the original transducer-imprint out-of-fold prediction file. This reproduces 11/12 positive receptors, mean paired difference 0.389 and exact two-sided sign-flip P=0.0302734375.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
