import os
import pandas as pd,numpy as np,json
exec(open(os.path.join(os.path.dirname(__file__),'03_within_receptor_and_bootstrap.py')).read().split("val=sys.argv[1]")[0])
for val in ['receptor','seq50']:
    A=arch('endpoint_geometry',val)
    print(val, json.dumps(within(A)))
