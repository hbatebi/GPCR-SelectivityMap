# Result: phylogenetic lability of transducer preference

Run 2026-10-31 against the plan in analysis_plan.md. Seed 20261031, 1,000 permutations.
Sample: 69 receptors with both a Masuho activation profile and an aligned structure.
Alignment: 64 GPCRdb generic positions, majority residue per receptor. NJ tree, midpoint rooted.

## Q1 Continuous phylogenetic signal: STRONG

| family | Pagel lambda | LRT p | Blomberg K | K null median | K p |
|---|---|---|---|---|---|
| Gi/o | 0.857 | 2.9e-05 | 0.791 | 0.382 | 0.001 |
| Gq/11 | 0.939 | 5.7e-08 | 0.959 | 0.384 | 0.001 |
| Gs | 1.000 | 3.0e-14 | 1.414 | 0.387 | 0.001 |

## Q2 Categorical signal: CLUSTERED

18 parsimony changes observed, null median 28, 5th percentile 25, p = 0.001.

## Q3 Decisive contrast: FAILS the prespecified criterion

Chance agreement from the marginal distribution is 0.389.

| identity bin | pairs | agreement | bootstrap 95% CI | verdict |
|---|---|---|---|---|
| 80-100% | 39 | 0.846 | 0.667-1.000 | above chance |
| 70-80% | 37 | 0.892 | 0.667-1.000 | above chance |
| 60-70% | 229 | 0.384 | 0.275-0.508 | at chance |
| 50-60% | 728 | 0.323 | 0.265-0.397 | at chance |
| 40-50% | 749 | 0.422 | 0.356-0.500 | at chance |
| 30-40% | 330 | 0.436 | 0.345-0.525 | at chance |
| <30% | 234 | 0.184 | 0.104-0.298 | below chance |

Profile correlation falls in step: rho +0.89 above 80%, +0.21 at 60-80%, +0.14 at 40-60%, +0.04 below 40%.

The plan required agreement above the marginal expectation in the 30-40% and <30% bins.
It is at chance in the first and below chance in the second. The criterion is not met.

## Q4 Origins

18 transitions under parsimony: 10 into Gq/11, 5 into Gs, 3 into Gi/o.

## Controls

- GPCRdb ligand class: within-group agreement 0.395 against chance 0.389 (8 groups).
- GPCRdb family slug: within-group agreement 0.409 against chance 0.389 (14 groups).
  Family membership does not predict preference.
- Excluding the 24 receptors that activate only one family: same shape, 0.739 above 80%
  identity, at or below chance everywhere beyond.
- The argmax is not brittle. Median ratio of fastest to second-fastest rate is 58.6,
  and only 4% of receptors have a ratio below 2.

## Reading

Transducer preference is inherited among immediate paralogues and is effectively
unpredictable above that level, including from GPCRdb family membership. Its horizon is
close to the horizon over which the manuscript's structural signal transfers.

By the prespecified rule, this does not support the convergence framing: at the distances
where the structure fails to transfer, the preference is largely not shared either, so
"the same preference reached by different structural means" is not the general case.

What it does establish is that preference is phylogenetically structured, which is the
direct justification for homology-aware validation, and that the two horizons coincide.

## Caveats

- 64 conserved generic positions is a coarse phylogeny, and identities computed over
  conserved positions are inflated relative to full-sequence identity, so the bins here
  are not on the same scale as the manuscript's sequence-identity clustering thresholds.
- 69 receptors, of which 24 activate only one family measurably.
- Parsimony counts are a minimum, not an estimate of the true number of transitions.
