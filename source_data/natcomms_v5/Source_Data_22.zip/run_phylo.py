"""Phylogenetic lability of transducer preference.

Usage: python -I run_phylo.py <mmc2.xlsx> <structure_metadata_enriched.csv> <outdir>

Implements the prespecified plan in analysis_plan.md. No network, no biopython:
neighbour-joining, Pagel's lambda, Blomberg's K and Fitch parsimony are built here.
"""
import sys, json, itertools
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from scipy.stats import chi2, spearmanr

XL, META, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
SEED, NPERM = 20261031, 1000
rng = np.random.default_rng(SEED)
FAM = ['Gi/o', 'Gq/11', 'Gs']

GENE2ENTRY = {
 'ADRB1':'adrb1','ADRB2':'adrb2','ADRB3':'adrb3','ADRA1A':'ada1a','ADRA1B':'ada1b','ADRA1D':'ada1d',
 'ADRA2A':'ada2a','ADRA2B':'ada2b','ADRA2C':'ada2c','CHRM1':'acm1','CHRM2':'acm2','CHRM3':'acm3',
 'CHRM4':'acm4','CHRM5':'acm5','DRD1':'drd1','DRD2':'drd2','DRD3':'drd3','DRD4':'drd4','DRD5':'drd5',
 'HTR1A':'5ht1a','HTR1B':'5ht1b','HTR1D':'5ht1d','HTR1E':'5ht1e','HTR1F':'5ht1f','HTR2A':'5ht2a',
 'HTR2B':'5ht2b','HTR2C':'5ht2c','HTR4':'5ht4r','HTR5A':'5ht5a','HTR6':'5ht6r','HTR7':'5ht7r',
 'HRH1':'hrh1','HRH2':'hrh2','HRH3':'hrh3','HRH4':'hrh4','ADORA1':'aa1r','ADORA2A':'aa2ar',
 'ADORA2B':'aa2br','ADORA3':'aa3r','OPRM1':'oprm','OPRD1':'oprd','OPRK1':'oprk','OPRL1':'oprx',
 'CCKAR':'cckar','CCKBR':'gastr','AGTR1':'agtr1','AGTR2':'agtr2','EDNRA':'ednra','EDNRB':'ednrb',
 'NTSR1':'ntr1','NTSR2':'ntr2','TACR1':'nk1r','TACR2':'nk2r','TACR3':'nk3r','GALR1':'galr1',
 'GALR2':'galr2','GALR3':'galr3','NPY1R':'npy1r','NPY2R':'npy2r','NPY4R':'npy4r','NPY5R':'npy5r',
 'GHSR':'ghsr','MLNR':'mtlr','NMUR1':'nmur1','NMUR2':'nmur2','PRLHR':'prlhr','NPFFR1':'npff1',
 'SSTR1':'ssr1','SSTR2':'ssr2','SSTR3':'ssr3','SSTR4':'ssr4','SSTR5':'ssr5','KISS1R':'kissr',
 'CXCR4':'cxcr4','PTGER1':'pe2r1','PTGER2':'pe2r2','PTGER3':'pe2r3','PTGER4':'pe2r4','PTGDR':'pd2r',
 'PTGDR2':'pd2r2','TBXA2R':'ta2r','CNR1':'cnr1','GPBAR1':'gpbar','SUCNR1':'sucr1','OXGR1':'oxgr1',
 'GPR52':'gpr52'}

# ---------------------------------------------------------------- trait
raw = pd.read_excel(XL, sheet_name='Raw Data', header=None, skiprows=3).iloc[:, :23]
raw.columns = ['name', 'gene', 'cls'] + \
    [f'amp_{g}_{s}' for g in ['io','q','15','s','1213'] for s in ['m','e']] + \
    [f'rate_{g}_{s}' for g in ['io','q','15','s','1213'] for s in ['m','e']]
raw = raw[raw.gene.isin(GENE2ENTRY)].drop_duplicates('gene', keep='first').copy()
raw['receptor_name'] = raw.gene.map(GENE2ENTRY) + '_human'
for c in [c for c in raw.columns if c.startswith('rate_')]:
    raw[c] = pd.to_numeric(raw[c], errors='coerce').fillna(0.0)
rates = pd.DataFrame({'Gi/o': raw.rate_io_m.values,
                      'Gq/11': np.maximum(raw.rate_q_m, raw.rate_15_m).values,
                      'Gs': raw.rate_s_m.values}, index=raw.receptor_name.values)

# ---------------------------------------------------------------- alignment
meta = pd.read_csv(META, low_memory=False)
aa_cols = [c for c in meta.columns if c.endswith('_expected_aa')]
meta = meta[meta.class_a == True]
seqs = {}
for rec, grp in meta.groupby('receptor_name'):
    row = []
    for c in aa_cols:
        v = grp[c].dropna().astype(str)
        v = v[v.str.len() == 1]
        row.append(v.mode().iloc[0] if len(v) else '-')
    seqs[rec] = np.array(row)
POS = len(aa_cols)
seqs = {r: s for r, s in seqs.items() if (s != '-').sum() >= 0.8 * POS}

recs = sorted(set(seqs) & set(rates.index))
S = np.array([seqs[r] for r in recs])
R = rates.loc[recs]
n = len(recs)

# pairwise identity over jointly present positions
present = S != '-'
ident = np.zeros((n, n))
for i in range(n):
    both = present[i] & present
    same = (S[i] == S) & both
    ident[i] = same.sum(1) / np.maximum(both.sum(1), 1)
np.fill_diagonal(ident, 1.0)
D = 1.0 - ident

# ---------------------------------------------------------------- NJ tree
def neighbour_joining(D, labels):
    """Saitou & Nei. Returns (parent, children, blen, root) over node ids."""
    m = D.shape[0]
    nodes = list(range(m))
    nxt = m
    ch, bl = {}, {}
    Dc = D.astype(float).copy()
    while len(nodes) > 2:
        k = len(nodes)
        tot = Dc.sum(1)
        Q = (k - 2) * Dc - tot[:, None] - tot[None, :]
        np.fill_diagonal(Q, np.inf)
        i, j = np.unravel_index(np.argmin(Q), Q.shape)
        if i > j: i, j = j, i
        di = 0.5 * Dc[i, j] + (tot[i] - tot[j]) / (2 * (k - 2))
        dj = Dc[i, j] - di
        ch[nxt] = (nodes[i], nodes[j])
        bl[nodes[i]], bl[nodes[j]] = max(di, 0.0), max(dj, 0.0)
        newrow = 0.5 * (Dc[i] + Dc[j] - Dc[i, j])
        keep = [x for x in range(k) if x not in (i, j)]
        Dn = np.zeros((k - 1, k - 1))
        Dn[:k-2, :k-2] = Dc[np.ix_(keep, keep)]
        Dn[k-2, :k-2] = Dn[:k-2, k-2] = newrow[keep]
        Dc = Dn
        nodes = [nodes[x] for x in keep] + [nxt]
        nxt += 1
    a, b = nodes
    ch[nxt] = (a, b)
    bl[a], bl[b] = max(Dc[0, 1], 0.0) / 2, max(Dc[0, 1], 0.0) / 2
    bl[nxt] = 0.0
    return ch, bl, nxt

ch, bl, root = neighbour_joining(D, recs)

def descendants(node):
    if node not in ch: return [node]
    out = []
    for c in ch[node]: out += descendants(c)
    return out

# root-to-node depth, and VCV = shared path length from root
depth = {}
def setdepth(node, d):
    depth[node] = d
    for c in ch.get(node, ()): setdepth(c, d + bl[c])
setdepth(root, 0.0)

V = np.zeros((n, n))
# shared ancestry: for each internal node, all descendant tip pairs share depth[node]
for node in ch:
    tips = [t for t in descendants(node) if t < n]
    d = depth[node]
    for a, b in itertools.combinations_with_replacement(tips, 2):
        V[a, b] = V[b, a] = max(V[a, b], d)
for t in range(n):
    V[t, t] = depth[t]
V += 1e-9 * np.eye(n)

# ---------------------------------------------------------------- Pagel lambda, Blomberg K
def ll_lambda(lam, x, V):
    Vl = V * lam + np.diag(np.diag(V) * (1 - lam))
    try: Vi = np.linalg.inv(Vl)
    except np.linalg.LinAlgError: return 1e9
    one = np.ones((len(x), 1)); xv = x.reshape(-1, 1)
    mu = ((one.T @ Vi @ xv) / (one.T @ Vi @ one)).item()
    r = xv - mu
    s2 = (r.T @ Vi @ r).item() / len(x)
    if s2 <= 0: return 1e9
    sign, logdet = np.linalg.slogdet(Vl)
    return 0.5 * (len(x) * np.log(2 * np.pi * s2) + logdet + len(x))

def pagel(x, V):
    f = lambda l: ll_lambda(l, x, V)
    r = minimize_scalar(f, bounds=(0.0, 1.0), method='bounded')
    lam, l1 = float(r.x), -float(r.fun)
    l0 = -f(0.0)
    p = float(chi2.sf(max(2 * (l1 - l0), 0.0), 1))
    return lam, p

def blomberg(x, V):
    n_ = len(x); Vi = np.linalg.inv(V); one = np.ones((n_, 1)); xv = x.reshape(-1, 1)
    mu = ((one.T @ Vi @ xv) / (one.T @ Vi @ one)).item()
    r = xv - mu
    mse = (r.T @ Vi @ r).item() / (n_ - 1)
    mse0 = float(((x - mu) ** 2).sum()) / (n_ - 1)
    expect = (np.trace(V) - n_ / (one.T @ Vi @ one).item()) / (n_ - 1)
    return (mse0 / mse) / expect if mse > 0 and expect > 0 else np.nan

logr = {}
for f_ in FAM:
    v = R[f_].values.astype(float)
    pos = v[v > 0]
    v = np.where(v > 0, v, (pos.min() / 2 if len(pos) else 1e-6))
    logr[f_] = np.log10(v)

q1 = []
for f_ in FAM:
    x = logr[f_]
    lam, p_lam = pagel(x, V)
    k = blomberg(x, V)
    null = np.array([blomberg(x[rng.permutation(n)], V) for _ in range(NPERM)])
    q1.append(dict(family=f_, n=n, pagel_lambda=lam, lambda_p=p_lam, blomberg_K=k,
                   K_null_median=float(np.nanmedian(null)),
                   K_p=float((np.nansum(null >= k) + 1) / (NPERM + 1))))
pd.DataFrame(q1).to_csv(f'{OUT}/Q1_continuous_signal.tsv', sep='\t', index=False)

# ---------------------------------------------------------------- Fitch parsimony
pref = R.values.argmax(1)

def fitch(states):
    sets, cost = {}, [0]
    def up(node):
        if node < n:
            sets[node] = {states[node]}; return sets[node]
        a, b = (up(c) for c in ch[node])
        inter = a & b
        if inter: sets[node] = inter
        else: sets[node] = a | b; cost[0] += 1
        return sets[node]
    up(root)
    return cost[0], sets

obs_changes, _ = fitch(pref)
null_changes = np.array([fitch(pref[rng.permutation(n)])[0] for _ in range(NPERM)])
q2 = dict(n=n, states=len(set(pref)), observed_changes=int(obs_changes),
          min_possible=len(set(pref)) - 1,
          null_median=float(np.median(null_changes)),
          null_p5=float(np.percentile(null_changes, 5)),
          p_clustered=float((np.sum(null_changes <= obs_changes) + 1) / (NPERM + 1)))
json.dump(q2, open(f'{OUT}/Q2_parsimony.json', 'w'), indent=1)

# ---------------------------------------------------------------- Q3 binned agreement
iu = np.triu_indices(n, 1)
pid = ident[iu] * 100
agree = (pref[iu[0]] == pref[iu[1]]).astype(float)
prof = np.array([spearmanr(R.values[a], R.values[b]).statistic
                 for a, b in zip(*iu)])
marg = np.bincount(pref, minlength=3) / n
exp_agree = float((marg ** 2).sum())

BINS = [('>=50%', 50, 101), ('40-50%', 40, 50), ('30-40%', 30, 40), ('<30%', -1, 30)]
rows = []
for name, lo, hi in BINS:
    m = (pid >= lo) & (pid < hi)
    if m.sum() < 5:
        rows.append(dict(bin=name, n_pairs=int(m.sum()))); continue
    a = agree[m]
    # receptor-clustered bootstrap: resample receptors, keep pairs with both drawn
    boots = []
    for _ in range(NPERM):
        idx = rng.integers(0, n, n)
        keep = np.isin(iu[0], idx) & np.isin(iu[1], idx) & m
        if keep.sum() >= 5: boots.append(agree[keep].mean())
    rows.append(dict(bin=name, n_pairs=int(m.sum()), mean_identity=float(pid[m].mean()),
                     agreement=float(a.mean()),
                     ci_lo=float(np.percentile(boots, 2.5)), ci_hi=float(np.percentile(boots, 97.5)),
                     expected_agreement=exp_agree,
                     mean_profile_rho=float(np.nanmean(prof[m]))))
pd.DataFrame(rows).to_csv(f'{OUT}/Q3_binned_agreement.tsv', sep='\t', index=False)

# ---------------------------------------------------------------- Q4 origins
_, sets = fitch(pref)
state_of = {}
def down(node, parent_state):
    s = sets[node]
    st = parent_state if parent_state in s else sorted(s)[0]
    state_of[node] = st
    for c in ch.get(node, ()): down(c, st)
down(root, sorted(sets[root])[0])
origins = {FAM[k]: 0 for k in range(3)}
for node, kids in ch.items():
    for c in kids:
        if state_of[c] != state_of[node]:
            origins[FAM[state_of[c]]] += 1
json.dump(dict(origins_into_family=origins, total_transitions=int(obs_changes)),
          open(f'{OUT}/Q4_origins.json', 'w'), indent=1)

# ---------------------------------------------------------------- outputs
pd.DataFrame({'receptor': recs, 'preferred': [FAM[k] for k in pref],
              **{f'rate_{f_}': R[f_].values for f_ in FAM}}
             ).to_csv(f'{OUT}/receptor_traits.tsv', sep='\t', index=False)
np.save(f'{OUT}/identity_matrix.npy', ident)
json.dump(dict(seed=SEED, nperm=NPERM, n_receptors=n, n_alignment_positions=POS,
               expected_agreement=exp_agree,
               preferred_counts={FAM[k]: int((pref == k).sum()) for k in range(3)}),
          open(f'{OUT}/run_info.json', 'w'), indent=1)
print(f'n={n} receptors, {POS} alignment positions')
print(pd.DataFrame(q1).to_string(index=False))
print(json.dumps(q2, indent=1))
print(pd.DataFrame(rows).to_string(index=False))
print(json.dumps(origins, indent=1))
