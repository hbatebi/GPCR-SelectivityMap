# Prespecified analysis plan: phylogenetic lability of transducer preference

Written 2026-10-31, before any result of this analysis was computed.
Seed 20261031. 1,000 permutations throughout.

## Question

The manuscript shows that structural information distinguishing captured
transducer classes does not transfer between receptors separated by more than
roughly 40% sequence identity. That is consistent with two histories: one
structural solution inherited from a common ancestor and since obscured, or
equivalent solutions reached repeatedly in separate lineages. The two are
distinguished by whether transducer preference itself is phylogenetically
clustered. If preference is shared across evolutionary distances at which the
structural solution does not transfer, repeated arrival is the better supported
reading. If preference is strongly clustered on the same horizon as the
structure, it is not, and the convergence language is removed from the paper.

## Data

Trait. Masuho et al. 2023 (Cell Rep 42:113173), supplementary mmc2.xlsx, sheet
"Raw Data": mean activation rate for GaoA, Gaq and Gas, taken to represent
Gi/o, Gq/11 and Gs. Gene symbols mapped to UniProt entry-name stems with the
GENE2ENTRY dictionary already used in the kinetic analysis. Derived traits:
  T1 continuous log10 rate per family, zeros replaced by half the smallest
     positive rate observed for that family;
  T2 categorical preferred family, the family with the highest mean rate.

Phylogeny. Structure-based alignment over the GPCRdb generic positions carried
in results/microswitches/metadata/structure_metadata_enriched.csv as
gpcrdb_*_expected_aa. One row per structure, collapsed to one sequence per
receptor by majority vote at each position. Receptors retained when at least
80% of generic positions are present. Pairwise identity computed over positions
present in both receptors; distance = 1 - identity; tree by neighbour-joining
(Saitou and Nei), midpoint rooted, negative branch lengths set to zero.

Sample. Receptors with both a kinetic profile and an aligned sequence.

## Endpoints and decision rules

Q1 Continuous signal. Pagel's lambda by maximum likelihood on the
   variance-covariance matrix, with a likelihood-ratio test against lambda = 0,
   and Blomberg's K with a tip-permutation null, computed separately for each
   family's log rate. Clustered if lambda is significantly above 0 and K is
   above the 95th percentile of its null.

Q2 Categorical signal. Minimum number of state changes for T2 by Fitch
   parsimony on the tree, against the distribution under 1,000 tip-label
   permutations. Three states require at least two changes. Clustered if the
   observed count falls below the 5th percentile of the null.

Q3 Decisive contrast. All receptor pairs binned by sequence identity at the
   thresholds used in the manuscript: >=50%, 40-50%, 30-40%, <30%. Per bin,
   the proportion of pairs sharing a preferred family, with a receptor-clustered
   bootstrap 95% confidence interval, against the proportion expected from the
   marginal distribution of preferred families; and the mean Spearman
   correlation between the two receptors' three-family rate profiles, against a
   tip-permutation null. Preference is shared beyond the structural horizon if,
   in the 30-40% and <30% bins, agreement exceeds the marginal expectation with
   the bootstrap interval excluding it, in strata where the manuscript's
   structural classifier is at chance.

Q4 Origins. Number of independent transitions into each preferred family under
   Fitch parsimony with ancestral states resolved by the accelerated
   transformation convention, reported with the permutation null from Q2.

## Controls

- The alignment covers about 70 positions, so the tree is coarse. Every test is
  repeated with GPCRdb's own receptor_family and receptor_ligand_class slugs as
  an independent grouping, and both are reported.
- Receptors for which only one family is measurably activated could inflate
  agreement in Q3; the analysis is repeated excluding them.
- Rates span orders of magnitude, hence the log transform in T1.
- Preferred family is defined on measured rates and is independent of which
  transducer happens to have been crystallised with the receptor, so Q3 is not
  circular with the structural census.

## Stated in advance

A result in which preference is strongly clustered, with the same horizon as
the structural signal, does not support repeated arrival. In that case the
convergence reading is dropped from the abstract, discussion and cover letter,
and the finding stands as the bounded transfer result alone.
