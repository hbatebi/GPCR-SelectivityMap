"""Reproduce Masuho functional validation from annotation-free GPCR probabilities.
Inputs: user-uploaded clean OOF probabilities, Masuho 2023 Table S1 mmc2.xlsx,
Source Data S20 gene mapping & 94 frozen matched structural units.
Follows S20: first HTR7 row, Gq/11=Gaq, undetected rates=0, Gi/o=GaoA, Gs=Gas,
2,000 receptor bootstrap draws and 2,000 whole-receptor-profile permutations.
Outputs are post hoc sensitivity checks of an already explored functional dataset,
not a prospective validation or an independently held-out functional experiment.
"""
from pathlib import Path
from io import BytesIO
import zipfile, json
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from artifact_tool import Blob, SpreadsheetFile
from sklearn.metrics import roc_auc_score

BASE=Path(__file__).resolve().parent; SEED=20261031; N_BOOT=2000; N_PERM=2000
RNG=np.random.default_rng(SEED)
FAMS=('Gi/o','Gq/11','Gs')
MAP={'receptor':'receptor_grouped_5fold', 'seq50':'sequence_cluster_50_grouped_5fold',
     'seq40':'sequence_cluster_40_grouped_5fold', 'seq30':'sequence_cluster_30_grouped_5fold'}
U=pd.read_csv(BASE/'clean_model_predictions_by_unit.tsv',sep='\t')
A=pd.read_csv(BASE/'clean_model_auc_with_ci.tsv',sep='\t')
assert len(U)==828 and U.groupby('validation').size().to_dict()==dict.fromkeys(MAP,207)
if (BASE/'S20_Q1_units.tsv').exists():
    old_units=pd.read_csv(BASE/'S20_Q1_units.tsv',sep='\t')
    mapping=pd.read_csv(BASE/'S20_gene_to_receptor_mapping.tsv',sep='\t')
    original=pd.read_csv(BASE/'S20_Q2b_noncaptured_kinetic.tsv',sep='\t')
else:
    # Compatibility with original full submission archive layout.
    with zipfile.ZipFile(BASE/'NatComms_submission_revised_2026-11-04.zip') as z:
        s=zipfile.ZipFile(BytesIO(z.read('NatComms_submission/5_Source_Data/Source_Data_20.zip')))
        old_units=pd.read_csv(BytesIO(s.read('Source_Data_S20/Q1_units.tsv')),sep='\t')
        mapping=pd.read_csv(BytesIO(s.read('Source_Data_S20/gene_to_receptor_mapping.tsv')),sep='\t')
        original=pd.read_csv(BytesIO(s.read('Source_Data_S20/Q2b_noncaptured_kinetic.tsv')),sep='\t')
wb=SpreadsheetFile.import_xlsx(Blob.load(str(BASE/'mmc2.xlsx')))
raw=wb.worksheets.get_item('Raw Data').get_range('A4:W136').values
rr=[]
for row in raw:
    g=str(row[1]).strip() if row[1] is not None else ''
    if not g: continue
    def val(i):
        try:return float(row[i]) if row[i] is not None else 0.0
        except (ValueError,TypeError):return 0.0
    rr.append(dict(gene=g,isoform=row[0],**{'Gi/o':val(13),'Gq/11':val(15),'Gs':val(19),'G15':val(17)}))
rawdata=pd.DataFrame(rr)
ht7=rawdata.loc[rawdata.gene=='HTR7']
E=rawdata.drop_duplicates('gene',keep='first').merge(mapping,
    left_on='gene',right_on='hgnc_gene_symbol',how='inner')
E=E.rename(columns={'receptor_entry_name':'receptor_name'}).set_index('receptor_name')
P=E[list(FAMS)]
D=U.loc[U.validation=='receptor'].merge(old_units[['pdb_id','receptor_name','transducer_family','captured_rate']],
    left_on=['pdb_id','receptor_name','captured_family'],
    right_on=['pdb_id','receptor_name','transducer_family'])
assert len(D)==94 and D.receptor_name.nunique()==77
assert max(abs(P.loc[r.receptor_name,r.captured_family]-r.captured_rate) for _,r in D.iterrows())<1e-8
for valkey in MAP:
    d=U.loc[U.validation==valkey]; y=d.captured_family.values; scores=d[['p_Gi_o','p_Gq_11','p_Gs']].values
    mauc=np.mean([roc_auc_score(y==c,scores[:,i]) for i,c in enumerate(FAMS)])
    assert abs(mauc-A.set_index('validation').loc[valkey,'macro_roc_auc'])<6e-4

def AUC_FAST(y,scores):
    """AUC from averaged ranks for binary labels; ties get mean ranks."""
    npos=int(y.sum()); nneg=len(y)-npos
    if npos==0 or nneg==0: return np.nan
    ranks=rankdata(scores)
    return float((ranks[y].sum()-npos*(npos+1)/2)/(npos*nneg))

def auc_by_family(rate,prob,classes):
    aucs=[]
    for j in range(3):
        sel=classes==j
        auc=AUC_FAST(rate[sel]>0,prob[sel])
        if np.isfinite(auc):aucs.append(auc)
    return float(np.mean(aucs)) if aucs else np.nan

def calc_spearman_per_unit(prob,rate):
    a=rankdata(prob,axis=1)-2
    b=rankdata(rate,axis=1)-2
    den=np.sqrt((a*a).sum(1)*(b*b).sum(1))
    return np.divide((a*b).sum(1),den,out=np.full(len(prob),np.nan),where=den>0)

output=[]; pairs=[]; family_breakdown=[]
for v in MAP:
    df=U.loc[U.validation==v].merge(D[['pdb_id','receptor_name','captured_family']],
        on=['pdb_id','receptor_name','captured_family']).reset_index(drop=True)
    assert len(df)==94 and df.receptor_name.nunique()==77
    recs=pd.unique(df.receptor_name); recidx={r:i for i,r in enumerate(recs)}
    urec=np.array([recidx[r] for r in df.receptor_name])
    probs=df[['p_Gi_o','p_Gq_11','p_Gs']].to_numpy(float)
    rates=P.loc[df.receptor_name,list(FAMS)].to_numpy(float)
    captured=np.array([FAMS.index(f) for f in df.captured_family])
    rho_byunit=calc_spearman_per_unit(probs,rates)
    mean_rho=float(np.nanmean(rho_byunit))
    # Family detection AUC of ALL 3 families, including captured (not the decisive test).
    full_auc=float(np.mean([AUC_FAST(rates[:,j]>0,probs[:,j]) for j in range(3)]))
    # Produce two rows per structural unit, excluding captured class exactly as S20 protocol.
    noncap=np.array([[(captured[i]+j)%3 for j in (1,2)] for i in range(len(df))])
    # Unlike S20's fam order, sort each pair by class index to match pairwise direction.
    noncap.sort(axis=1)
    fam=noncap.ravel(); unitidx=np.repeat(np.arange(len(df)),2)
    longrate=rates[unitidx,fam]; longprob=probs[unitidx,fam]
    longrec=urec[unitidx]
    auc=auc_by_family(longrate,longprob,fam)
    unequal=longrate[::2]!=longrate[1::2]
    iscorrect=((longprob[::2]>longprob[1::2])==(longrate[::2]>longrate[1::2]))
    acc=float(iscorrect[unequal].mean()); ncomp=int(unequal.sum())
    # per-receptor rows for bootstraps; complete receptor cluster resampled
    ixunits=[np.flatnonzero(urec==i) for i in range(len(recs))]
    ixlong=[np.flatnonzero(longrec==i) for i in range(len(recs))]
    boot=np.empty((N_BOOT,3))
    for b in range(N_BOOT):
        pick=RNG.integers(0,len(recs),size=len(recs))
        lu=np.concatenate([ixlong[k] for k in pick])
        iu=np.concatenate([ixunits[k] for k in pick])
        boot[b,0]=auc_by_family(longrate[lu],longprob[lu],fam[lu])
        boot[b,1]=float(np.nanmean(rho_byunit[iu]))
        # per-unit correct comparisons sampled by cluster
        boot[b,2]=float(iscorrect[iu][unequal[iu]].mean()) if unequal[iu].any() else np.nan
    # Null: permute whole kinetic receptor profiles among receptors; scores and captured family unchanged.
    original_profiles=P.loc[recs,list(FAMS)].to_numpy(float)
    # Speed up roc-AUC permutation: fixed score ranks per family
    rankidx=[rankdata(longprob[fam==j]) for j in range(3)]
    null=np.empty((N_PERM,3))
    for b in range(N_PERM):
        perm=RNG.permutation(len(recs))
        permrate=original_profiles[perm][urec]
        lrate=permrate[unitidx,fam]
        au=[]
        for j in range(3):
            y=(lrate[fam==j]>0)
            n1=int(y.sum()); n0=len(y)-n1
            if n1 and n0:
                au.append((rankidx[j][y].sum()-n1*(n1+1)/2)/(n1*n0))
        null[b,0]=np.mean(au) if au else np.nan
        null[b,1]=float(np.nanmean(calc_spearman_per_unit(probs,permrate)))
        pneq=lrate[::2]!=lrate[1::2]
        pcorr=((longprob[::2]>longprob[1::2])==(lrate[::2]>lrate[1::2]))
        null[b,2]=float(pcorr[pneq].mean()) if pneq.any() else np.nan
    stats=dict(validation=v,n_units=94,n_receptors=77,n_other_family_pairs=188,
       n_measured_activation=int((longrate>0).sum()),n_no_detectable_activation=int((longrate==0).sum()),
       noncaptured_auc=auc,
       auc_ci_low=float(np.nanpercentile(boot[:,0],2.5)),auc_ci_high=float(np.nanpercentile(boot[:,0],97.5)),
       auc_null_mean=float(np.nanmean(null[:,0])),auc_perm_p=float((1+np.nansum(null[:,0]>=auc))/(N_PERM+1)),
       spearman_full_profile=mean_rho,
       rho_ci_low=float(np.nanpercentile(boot[:,1],2.5)),rho_ci_high=float(np.nanpercentile(boot[:,1],97.5)),
       rho_null_mean=float(np.nanmean(null[:,1])),rho_perm_p=float((1+np.nansum(null[:,1]>=mean_rho))/(N_PERM+1)),
       full_profile_detection_auc=full_auc,
       noncaptured_pairwise_acc=acc,n_non_tied_pairs=ncomp,
       acc_ci_low=float(np.nanpercentile(boot[:,2],2.5)),acc_ci_high=float(np.nanpercentile(boot[:,2],97.5)),
       acc_perm_p=float((1+np.nansum(null[:,2]>=acc))/(N_PERM+1)))
    output.append(stats)
    for j in range(3):
        sel=fam==j
        family_breakdown.append(dict(validation=v,family=FAMS[j],n=int(sel.sum()),positives=int((longrate[sel]>0).sum()),
                  auc=AUC_FAST(longrate[sel]>0,longprob[sel])))
    pairs.append(pd.DataFrame({'validation':v,'analysis_row_id':df.analysis_row_id.iloc[unitidx].values,
       'receptor_name':df.receptor_name.iloc[unitidx].values,'captured_family':df.captured_family.iloc[unitidx].values,
       'test_family':[FAMS[k] for k in fam], 'predicted_class_probability':longprob,
       'measured_rate_s_minus_1':longrate,'detectable_activation':longrate>0}))
    print('RESULT',v,'AUC',round(auc,4),'CI',np.round([stats['auc_ci_low'],stats['auc_ci_high']],3),
           'p',stats['auc_perm_p'],'rho',round(mean_rho,3),'CI',np.round([stats['rho_ci_low'],stats['rho_ci_high']],3),
           'pair accuracy',round(acc,3),flush=True)

res=pd.DataFrame(output)
res.to_csv(BASE/'clean_functional_validation_summary.tsv',sep='\t',index=False,float_format='%.8f')
pd.concat(pairs,ignore_index=True).to_csv(BASE/'clean_functional_validation_non_captured_pairs.tsv',sep='\t',index=False,float_format='%.8f')
pd.DataFrame(family_breakdown).to_csv(BASE/'clean_functional_validation_family_auc.tsv',sep='\t',index=False,float_format='%.8f')
provenance={'model':'coord_strict: per-structure 105 clean features, removal of 11 acquisition features and 2 functional descriptors; note coordinate-only 89-feature independent refit is a distinct analysis',
  'data':'Masuho et al., Cell Reports 2023 mmc2.xlsx Raw Data',
  'matching':'exact receptor_name / structure PDB / captured-family matching to Source Data S20 94 units',
  'positive':'measured rate > 0 in s-1; numeric zero denotes no detectable onset in reported assay, not proof of biological non-coupling',
  'family_mapping':{'Gi/o':'GaoA','Gq/11':'Gaq','Gs':'Gas'},'HTR7_selection':'first occurrence 5-HT7A',
  'bootstrap':{'n':N_BOOT,'seed':SEED,'unit':'receptor clusters'},
  'permutation':{'n':N_PERM,'seed':SEED,'unit':'whole kinetic receptor profiles'},
  'inference':'retrospective post hoc functional validation, no model refitting, not external prospective test',
  'rows':{'n_structural_units':94,'n_receptors':77,'n_non_captured_pairs_per_validation':188},
  'code':'rerun_clean_functional_validation.py'}
(BASE/'clean_functional_validation_manifest.json').write_text(json.dumps(provenance,indent=2))
print('\n'+res.to_string(index=False))
print('\nHISTORICAL\n',original[original.model=='endpoint_geometry'][['validation','family_mean_auc','pairwise_acc']].to_string(index=False))
print('\nHTR7_CHOICES\n',ht7.to_string(index=False))
