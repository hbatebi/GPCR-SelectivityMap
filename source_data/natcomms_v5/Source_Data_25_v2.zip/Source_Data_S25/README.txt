Source Data 25 | Post hoc clean functional validation

Inputs included: clean model out-of-fold probability tables, Source Data 20 mapping and matched units, and the frozen historical comparison.
External input not redistributed: Masuho et al. Cell Reports (2023) Table S1 mmc2.xlsx, Raw Data sheet.
To reproduce, extract this archive, put mmc2.xlsx beside rerun_clean_functional_validation.py, install numpy/pandas/scipy/scikit-learn/artifact_tool, and execute python rerun_clean_functional_validation.py.
Code uses its containing directory as base and preserves seed 20261031, 2000 receptor-clustered bootstrap replicates and 2000 complete receptor-profile permutations.
First HTR7 isoform (5-HT7A) per source protocol; no model training or re-fitting.
Source Data 18 coord_strict scores exclude two functional annotation descriptors and acquisition covariates. This is not the separately refitted 89-feature Source Data 24 model.
Functional validation uses the same published panel previously examined in Source Data 20; this is a retrospective re-analysis rather than new prospective validation.
