"""Extract the strict coordinate-only ("clean") model predictions and bootstrap its AUCs.

Source: Source Data S18, predictions/out_of_fold_predictions_refit.tsv, model "coord_strict",
which is the representation with the 11 acquisition inputs and the two functional-annotation
inputs both removed. Verified to reproduce the strict_coordinate_only column of
results/archive_wide_auc_table.tsv at all four validation levels.

Conventions follow the manuscript: seed 20261031, 2,000 receptor-clustered bootstrap resamples.
"""
import os
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

SD = os.environ.get('SOURCE_DATA_S18', 'Source_Data_S18')
OUT = os.environ.get('OUT_DIR', 'results')
SEED, B = 20261031, 2000
CLASSES = ['Gi/o', 'Gq/11', 'Gs']
VALS = ['receptor', 'seq50', 'seq40', 'seq30']
rng = np.random.default_rng(SEED)

P = pd.read_csv(f'{SD}/predictions/out_of_fold_predictions_refit.tsv', sep='\t')
M = pd.read_csv(f'{SD}/predictions/unit_metadata_and_folds.tsv', sep='\t')
P = P[P.model == 'coord_strict']

keep = ['analysis_row_id', 'pdb_id', 'chain_id', 'receptor_name', 'transducer_family',
        'sequence_cluster_50', 'sequence_cluster_40', 'sequence_cluster_30',
        'receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold',
        'sequence_cluster_40_grouped_5fold', 'sequence_cluster_30_grouped_5fold']
d = P.merge(M[keep], on='analysis_row_id', how='left')
d = d.rename(columns={'transducer_family': 'captured_family',
                      'Gi/o': 'p_Gi_o', 'Gq/11': 'p_Gq_11', 'Gs': 'p_Gs'})
d['validation'] = pd.Categorical(d.validation, VALS, ordered=True)
d = d.sort_values(['validation', 'receptor_name', 'pdb_id'])

cols = ['validation', 'analysis_row_id', 'pdb_id', 'chain_id', 'receptor_name',
        'captured_family', 'p_Gi_o', 'p_Gq_11', 'p_Gs',
        'sequence_cluster_50', 'sequence_cluster_40', 'sequence_cluster_30',
        'receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold',
        'sequence_cluster_40_grouped_5fold', 'sequence_cluster_30_grouped_5fold']
unit = d[cols].copy()
unit.to_csv(f'{OUT}/clean_model_predictions_by_unit.tsv', sep='\t', index=False,
            float_format='%.6f')

# receptor-level: mean probability across that receptor's units
rec = (d.groupby(['validation', 'receptor_name'], observed=True)
         .agg(n_units=('analysis_row_id', 'size'),
              captured_families=('captured_family', lambda s: '|'.join(sorted(set(s)))),
              p_Gi_o=('p_Gi_o', 'mean'), p_Gq_11=('p_Gq_11', 'mean'), p_Gs=('p_Gs', 'mean'))
         .reset_index())
rec.to_csv(f'{OUT}/clean_model_predictions_by_receptor.tsv', sep='\t', index=False,
           float_format='%.6f')


def macro(y, Q, idx):
    a = []
    for j, c in enumerate(CLASSES):
        yy = (y[idx] == c).astype(int)
        if 0 < yy.sum() < len(yy):
            a.append(roc_auc_score(yy, Q[idx, j]))
    return float(np.mean(a)) if a else np.nan


rows = []
for v in VALS:
    g = d[d.validation == v]
    y = g.captured_family.to_numpy()
    Q = g[['p_Gi_o', 'p_Gq_11', 'p_Gs']].to_numpy()
    recs = g.receptor_name.to_numpy()
    uq = pd.unique(recs)
    ix = {r: np.where(recs == r)[0] for r in uq}
    obs = macro(y, Q, np.arange(len(y)))
    bs = [macro(y, Q, np.concatenate([ix[r] for r in rng.choice(uq, len(uq))]))
          for _ in range(B)]
    bs = np.array(bs, float)
    per = {}
    for j, c in enumerate(CLASSES):
        yy = (y == c).astype(int)
        per[c] = round(roc_auc_score(yy, Q[:, j]), 3)
    rows.append(dict(validation=v, n_units=len(y), n_receptors=len(uq),
                     macro_roc_auc=round(obs, 3),
                     ci_low=round(float(np.nanpercentile(bs, 2.5)), 3),
                     ci_high=round(float(np.nanpercentile(bs, 97.5)), 3),
                     **{f'auc_{c}': per[c] for c in CLASSES}))

res = pd.DataFrame(rows)
res.to_csv(f'{OUT}/clean_model_auc_with_ci.tsv', sep='\t', index=False)
print(res.to_string(index=False))
print()
print('units %d | receptors %d | rows written %d'
      % (unit.analysis_row_id.nunique(), unit.receptor_name.nunique(), len(unit)))
