#!/usr/bin/env python
"""Stage 2: when one receptor engages two G protein classes, which side adapts?

Prespecified before any result is inspected (31 Oct 2026).

  Hypothesis: the receptor's own conformation changes little between its captured classes,
  while the Galpha pose in a receptor-anchored frame changes in a direction that is
  CONSISTENT across receptors. If so, the transferable part of class discrimination sits on
  the Galpha side, which would explain both the absence of a universal receptor-side code and
  the evolutionary horizon reported in the manuscript.

  Primary statistic: mean pairwise cosine similarity between the Galpha alpha5 centroid
  displacement vectors of different receptors for the same ordered class pair.
  Null: 2,000 permutations in which the sign of each receptor's displacement vector is flipped
  at random (a vector set with no shared direction is sign-symmetric).

  Decision rule: if the observed mean cosine does not exceed the null, the hypothesis is
  rejected and the result is reported as negative.

  Controls: receptor TM-core RMSD between the two complexes after superposition (the receptor
  side), and stratification by Galpha construct parsed from the mmCIF entity descriptions.

Usage
-----
  python galpha_pose.py \
      --structures   /home/atuin/c108cb/c108cb11/gpcr-icl2-microswitches-complete/data/structures \
      --inventory    structure_inventory.csv \
      --generic-map  results/microswitches/measurements/generic_number_mapping.csv \
      --chains       results/microswitches/interface_complementarity_v1_full/extraction/contact_extraction_audit.tsv \
      --src          src \
      --out          results/galpha_pose

`--inventory` needs columns pdb_id, receptor_name, transducer_family (the 207-unit table).
"""
from __future__ import annotations
import argparse, json, os, sys, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# conserved transmembrane anchors used to put both complexes in one receptor frame
ANCHORS = [f"{h}.{p}" for h in range(1, 8) for p in (46, 50, 54)]
A5_RANGE = (360, 394)          # Galpha reference positions, alpha5 (Gs numbering)
A5_CORE = (375, 394)           # inserted C-terminal portion used for the centroid
MIN_ANCHORS = 12
SEED, NPERM = 20261031, 2000
CONSTRUCT_KEYS = {
    "mini_g": ["mini-g", "minig", "mini g"],
    "chimera": ["chimer", "/gi", "gsi", "gsq", "mgsqi", "mgsi"],
    "dominant_negative": ["dominant negative", "dominant-negative", "dngs", "dn-g"],
    "scfv16": ["scfv16", "scfv-16"],
    "nb35": ["nb35", "nanobody 35", "nb-35"],
}


def load_structure(path):
    import biotite.structure.io.pdbx as pdbx
    import biotite.structure as struc
    cif = pdbx.CIFFile.read(path)
    arr = pdbx.get_structure(cif, model=1)
    arr = arr[struc.filter_amino_acids(arr)]
    arr = arr[arr.element != "H"]
    desc = []
    try:
        blk = cif.block
        ent = blk["entity"]
        for v in np.atleast_1d(ent["pdbx_description"].as_array()):
            desc.append(str(v))
    except Exception:
        pass
    return arr, " | ".join(desc)


def construct_flags(desc):
    d = desc.lower()
    return {k: any(t in d for t in toks) for k, toks in CONSTRUCT_KEYS.items()}


def ca_by_generic(arr, chain, gmap_pdb):
    """{generic_number: CA coord} for the receptor chain."""
    import biotite.structure as struc
    sub = arr[(arr.chain_id == chain) & (arr.atom_name == "CA")]
    byres = {int(r): c for r, c in zip(sub.res_id, sub.coord)}
    out = {}
    for gn, rid in gmap_pdb.items():
        if rid in byres:
            out[gn] = byres[rid]
    return out


def a5_atoms(arr, chain, refmap):
    """CA coords of alpha5 by Galpha reference position."""
    sub = arr[(arr.chain_id == chain) & (arr.atom_name == "CA")]
    out = {}
    for rid, c in zip(sub.res_id, sub.coord):
        hit = refmap.get(int(rid))
        if hit is None:
            continue
        rp, _elem = hit
        if A5_RANGE[0] <= rp <= A5_RANGE[1]:
            out[rp] = c
    return out


def axis_of(coords):
    X = np.asarray(coords, float)
    X = X - X.mean(0)
    u, s, vt = np.linalg.svd(X, full_matrices=False)
    v = vt[0]
    return v / np.linalg.norm(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--structures", required=True)
    ap.add_argument("--inventory", required=True)
    ap.add_argument("--generic-map", required=True)
    ap.add_argument("--chains", required=True)
    ap.add_argument("--src", default="src")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    sys.path.insert(0, a.src)
    import biotite.structure as struc
    from gpcr_icl2.galpha_cgn import map_galpha_to_reference

    inv = pd.read_csv(a.inventory)[["pdb_id", "receptor_name", "transducer_family"]]
    multi = inv.groupby("receptor_name").transducer_family.nunique()
    inv = inv[inv.receptor_name.isin(multi[multi > 1].index)].reset_index(drop=True)
    ch = pd.read_csv(a.chains, sep="\t").set_index("pdb_id")
    gm = pd.read_csv(a.generic_map, dtype={"generic_number": str}, low_memory=False)
    gm = gm[gm.mapping_status == "mapped"]
    gm["generic_number"] = gm.generic_number.str.strip()

    recs, fails = {}, []
    for _, r in inv.iterrows():
        p = r.pdb_id
        try:
            if p not in ch.index:
                raise RuntimeError("no chain assignment")
            rc, gc = str(ch.at[p, "receptor_chain"]), str(ch.at[p, "galpha_chain"])
            if rc in ("nan", "") or gc in ("nan", ""):
                raise RuntimeError("missing chain")
            path = os.path.join(a.structures, f"{p}.cif")
            arr, desc = load_structure(path)
            g = gm[(gm.pdb_id == p) & (gm.chain_id == rc)]
            gmap_pdb = {str(x): int(y) for x, y in zip(g.generic_number, g.author_residue_number)
                        if pd.notna(y)}
            rec_ca = ca_by_generic(arr, rc, gmap_pdb)
            gchain = arr[arr.chain_id == gc]
            refmap = map_galpha_to_reference(gchain)
            a5 = a5_atoms(arr, gc, refmap)
            if len(a5) < 8:
                raise RuntimeError(f"alpha5 poorly resolved ({len(a5)})")
            recs[p] = dict(pdb=p, receptor=r.receptor_name, fam=r.transducer_family,
                           rec_ca=rec_ca, a5=a5, desc=desc, **construct_flags(desc))
        except Exception as e:
            fails.append(dict(pdb_id=p, receptor=r.receptor_name, error=str(e)))
            print(f"[skip] {p}: {e}", flush=True)

    pd.DataFrame(fails).to_csv(f"{a.out}/failures.tsv", sep="\t", index=False)
    print(f"loaded {len(recs)} of {len(inv)} units", flush=True)

    rows = []
    for receptor, grp in pd.DataFrame(
            [{k: v for k, v in d.items() if k in ("pdb", "receptor", "fam")} for d in recs.values()]
    ).groupby("receptor"):
        units = list(grp.itertuples())
        for i in range(len(units)):
            for j in range(len(units)):
                if i >= j or units[i].fam == units[j].fam:
                    continue
                A, B = recs[units[i].pdb], recs[units[j].pdb]
                # order the pair deterministically so displacement signs are comparable
                order = ["Gi/o", "Gq/11", "Gs"]
                if order.index(A["fam"]) > order.index(B["fam"]):
                    A, B = B, A
                shared = [k for k in ANCHORS if k in A["rec_ca"] and k in B["rec_ca"]]
                if len(shared) < MIN_ANCHORS:
                    continue
                fixed = np.array([A["rec_ca"][k] for k in shared])
                mobile = np.array([B["rec_ca"][k] for k in shared])
                _fit, transform = struc.superimpose(fixed, mobile)
                rmsd_anchor = float(struc.rmsd(fixed, transform.apply(mobile)))
                # whole receptor TM-core change, the receptor-side control
                both = [k for k in A["rec_ca"] if k in B["rec_ca"]]
                rec_rmsd = float(struc.rmsd(np.array([A["rec_ca"][k] for k in both]),
                                            transform.apply(np.array([B["rec_ca"][k] for k in both]))))
                shared_a5 = sorted(set(A["a5"]) & set(B["a5"]))
                core = [k for k in shared_a5 if A5_CORE[0] <= k <= A5_CORE[1]]
                if len(core) < 5:
                    continue
                cA = np.array([A["a5"][k] for k in core])
                cB = transform.apply(np.array([B["a5"][k] for k in core]))
                d_centroid = cB.mean(0) - cA.mean(0)
                tip = max(core)
                d_tip = transform.apply(B["a5"][tip][None, :])[0] - A["a5"][tip]
                ax = float(np.degrees(np.arccos(np.clip(
                    abs(float(np.dot(axis_of(cA), axis_of(cB)))), -1, 1))))
                rows.append(dict(
                    receptor=receptor, pair=f'{A["fam"]} vs {B["fam"]}',
                    pdb_a=A["pdb"], pdb_b=B["pdb"], n_anchor=len(shared),
                    anchor_rmsd=rmsd_anchor, receptor_core_rmsd=rec_rmsd,
                    n_a5_core=len(core),
                    a5_centroid_shift=float(np.linalg.norm(d_centroid)),
                    a5_tip_shift=float(np.linalg.norm(d_tip)),
                    a5_axis_angle_deg=ax,
                    dx=d_centroid[0], dy=d_centroid[1], dz=d_centroid[2],
                    construct_a=";".join(k for k in CONSTRUCT_KEYS if A[k]),
                    construct_b=";".join(k for k in CONSTRUCT_KEYS if B[k]),
                ))

    df = pd.DataFrame(rows)
    df.to_csv(f"{a.out}/per_receptor_pose.tsv", sep="\t", index=False)
    print(f"\n{len(df)} same-receptor cross-class comparisons\n", flush=True)
    if df.empty:
        print("nothing to test"); return

    rng = np.random.default_rng(SEED)
    out = []
    for pair, g in df.groupby("pair"):
        V = g[["dx", "dy", "dz"]].to_numpy(float)
        n = np.linalg.norm(V, axis=1, keepdims=True)
        V = V / np.where(n > 0, n, 1)
        if len(V) < 3:
            out.append(dict(pair=pair, n_receptors=len(V), mean_cosine=np.nan, p_one_sided=np.nan))
            continue
        C = V @ V.T
        iu = np.triu_indices(len(V), 1)
        obs = C[iu].mean()
        null = []
        for _ in range(NPERM):
            s = rng.choice([-1.0, 1.0], len(V))[:, None]
            W = V * s
            null.append((W @ W.T)[iu].mean())
        null = np.asarray(null)
        out.append(dict(pair=pair, n_receptors=len(V), mean_cosine=float(obs),
                        null_mean=float(null.mean()),
                        p_one_sided=float((1 + (null >= obs).sum()) / (1 + NPERM)),
                        median_a5_centroid_shift=float(g.a5_centroid_shift.median()),
                        median_a5_axis_angle=float(g.a5_axis_angle_deg.median()),
                        median_receptor_core_rmsd=float(g.receptor_core_rmsd.median())))
    res = pd.DataFrame(out)
    res.to_csv(f"{a.out}/direction_consistency.tsv", sep="\t", index=False)
    clean = df[(df.construct_a == "") & (df.construct_b == "")]
    clean.to_csv(f"{a.out}/per_receptor_pose_native_only.tsv", sep="\t", index=False)
    json.dump(dict(seed=SEED, permutations=NPERM, anchors=ANCHORS,
                   a5_range=A5_RANGE, a5_core=A5_CORE,
                   n_units_loaded=len(recs), n_comparisons=len(df),
                   n_comparisons_native_constructs=len(clean)),
              open(f"{a.out}/run_info.json", "w"), indent=1)
    pd.set_option("display.width", 200)
    print(res.round(3).to_string())
    print("\nreceptor-side control, median TM-core RMSD between the two complexes:",
          round(df.receptor_core_rmsd.median(), 2), "A")
    print("construct-free comparisons:", len(clean), "of", len(df))


if __name__ == "__main__":
    main()
