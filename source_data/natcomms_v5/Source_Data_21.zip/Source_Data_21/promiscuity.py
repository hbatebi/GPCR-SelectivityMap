"""Does intracellular cavity capacity predict how many G protein families a receptor activates?

Prespecified before any result is inspected (31 Oct 2026).

  Hypothesis: receptors that activate more G protein families have larger or more accommodating
  intracellular cavities. This is a claim about capacity, not about a class-specific code, so it
  is not addressed by any of the negative results obtained earlier today.

  Outcome: n_families, the number of Gi/o, Gq/11 and Gs activated above zero in the measured
  kinetics of Masuho et al. (2023); and promiscuity_entropy, the Shannon entropy of the
  rate profile normalised to sum to one (0 = exclusive, log3 = fully even).

  Predictors: the intracellular cavity block and the two cavity-width distances.

  MANDATORY COVARIATE: the captured G protein class. Gs-bound structures have wider cavities by
  construction, and Gs couplers are more promiscuous in the kinetic data, so any raw correlation
  is confounded. The primary estimate is the partial association after regressing out captured
  class. A secondary estimate is computed within captured class.

  Primary statistic: Spearman partial correlation between each descriptor and n_families,
  controlling for captured class, with receptor-clustered bootstrap intervals and
  Benjamini-Hochberg correction across descriptors.

  Decision rule: if no descriptor retains a BH-significant partial association, the hypothesis is
  rejected and reported as negative.

Usage: python -I promiscuity.py <measurements.csv> <inventory.csv> <mmc2.xlsx> <cluster.tsv> <outdir>
"""
import sys, os, json, warnings
warnings.filterwarnings('ignore')
import numpy as np, pandas as pd
from scipy import stats

MEAS, INV, XL, CLU, OUT = sys.argv[1:6]
os.makedirs(OUT, exist_ok=True)
SEED, B = 20261031, 2000
rng = np.random.default_rng(SEED)

GENE2ENTRY = {'HTR1A':'5ht1a','HTR1B':'5ht1b','HTR1D':'5ht1d','HTR1E':'5ht1e','HTR1F':'5ht1f','HTR2A':'5ht2a','HTR2B':'5ht2b','HTR2C':'5ht2c',
'HTR4':'5ht4r','HTR5A':'5ht5a','HTR6':'5ht6r','HTR7':'5ht7r','CHRM1':'acm1','CHRM2':'acm2','CHRM3':'acm3','CHRM4':'acm4','CHRM5':'acm5',
'ADRA1A':'ada1a','ADRA1B':'ada1b','ADRA1D':'ada1d','ADRA2A':'ada2a','ADRA2B':'ada2b','ADRA2C':'ada2c','ADRB1':'adrb1','ADRB2':'adrb2','ADRB3':'adrb3',
'DRD1':'drd1','DRD2':'drd2','DRD3':'drd3','DRD4':'drd4','DRD5':'drd5','HRH1':'hrh1','HRH2':'hrh2','HRH3':'hrh3','MTNR1A':'mtr1a','MTNR1B':'mtr1b',
'ADORA1':'aa1r','ADORA2A':'aa2ar','ADORA2B':'aa2br','ADORA3':'aa3r','GALR1':'galr1','GALR2':'galr2','GALR3':'galr3','OPRM1':'oprm','OPRD1':'oprd',
'OPRK1':'oprk','OPRL1':'oprx','EDNRA':'ednra','EDNRB':'ednrb','GRPR':'grpr','BRS3':'brs3','APLNR':'apj','AVPR1A':'v1ar','AVPR1B':'v1br','AVPR2':'v2r',
'BDKRB2':'bkrb2','MC1R':'mshr','MC3R':'mc3r','MC4R':'mc4r','MC5R':'mc5r','NPY1R':'npy1r','NPY2R':'npy2r','NPY4R':'npy4r','NPY5R':'npy5r',
'TACR1':'nk1r','TACR2':'nk2r','TACR3':'nk3r','NTSR1':'ntr1','HCRTR1':'ox1r','HCRTR2':'ox2r','OXTR':'oxyr','CCKAR':'cckar','CCKBR':'gasr',
'NPFFR1':'npff1','SSTR1':'ssr1','SSTR2':'ssr2','SSTR3':'ssr3','SSTR4':'ssr4','SSTR5':'ssr5','KISS1R':'kissr','CXCR4':'cxcr4','PTGER1':'pe2r1',
'PTGER2':'pe2r2','PTGER3':'pe2r3','PTGER4':'pe2r4','PTGDR':'pd2r','PTGDR2':'pd2r2','TBXA2R':'ta2r','CNR1':'cnr1','GPBAR1':'gpbar','SUCNR1':'sucr1',
'OXGR1':'oxgr1','GPR52':'gpr52'}
FAM = ['Gi/o', 'Gq/11', 'Gs']

raw = pd.read_excel(XL, sheet_name='Raw Data', header=None, skiprows=3).iloc[:, :23]
raw.columns = ['name','gene','cls'] + [f'amp_{g}_{s}' for g in ['io','q','15','s','1213'] for s in ['m','e']] + \
              [f'rate_{g}_{s}' for g in ['io','q','15','s','1213'] for s in ['m','e']]
raw = raw[raw.gene.isin(GENE2ENTRY)].drop_duplicates('gene', keep='first').copy()
raw['receptor_name'] = raw.gene.map(GENE2ENTRY) + '_human'
for c in [c for c in raw.columns if c.startswith('rate_')]:
    raw[c] = pd.to_numeric(raw[c], errors='coerce').fillna(0.0)
R = pd.DataFrame({'Gi/o': raw.rate_io_m.values, 'Gq/11': raw.rate_q_m.values, 'Gs': raw.rate_s_m.values},
                 index=raw.receptor_name.values)
n_fam = (R > 0).sum(1)
p = R.div(R.sum(1).replace(0, np.nan), axis=0)
ent = -(p * np.log(p.where(p > 0))).sum(1)

inv = pd.read_csv(INV)[['pdb_id', 'receptor_name', 'transducer_family']]
m = pd.read_csv(MEAS, low_memory=False)
cav = [c for c in m.columns if c.startswith('intracellular_cavity')
       and not any(k in c for k in ['centroid_x', 'centroid_y', 'centroid_z', 'n_voxels'])]
feats = cav + ['tm5_tm6_cavity_distance', 'tm6_tm7_cavity_distance', 'tm6_aligned_displacement', 'tm3_tm7_distance']
d = inv.merge(m[['pdb_id'] + feats].drop_duplicates('pdb_id'), on='pdb_id', how='left')
d = d[d.receptor_name.isin(R.index)].copy()
d['n_families'] = d.receptor_name.map(n_fam)
d['entropy'] = d.receptor_name.map(ent)
clu = pd.read_csv(CLU, sep='\t').set_index('receptor_name')
d['cluster40'] = d.receptor_name.map(clu.sequence_cluster_40.to_dict())
print(f'{len(d)} units, {d.receptor_name.nunique()} receptors', flush=True)
print('n_families distribution:', d.drop_duplicates("receptor_name").n_families.value_counts().sort_index().to_dict(), flush=True)

def resid(v, groups):
    """residualise v on group means (captured class)"""
    v = pd.Series(np.asarray(v, dtype=float))
    out = (v - v.groupby(pd.Series(groups).values).transform('mean')).to_numpy(dtype=float)
    return out

def safe_r(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 5 or np.std(x[ok]) == 0 or np.std(y[ok]) == 0:
        return np.nan
    return float(np.corrcoef(x[ok], y[ok])[0, 1])

rows = []
for f in feats:
    sub = d[['receptor_name', 'transducer_family', 'cluster40', f, 'n_families', 'entropy']].dropna()
    if len(sub) < 30:
        continue
    g = sub.transducer_family.values
    for outcome in ['n_families', 'entropy']:
        x = resid(stats.rankdata(sub[f].values), g)
        y = resid(stats.rankdata(sub[outcome].values), g)
        r = safe_r(x, y)
        if not np.isfinite(r):
            continue
        recs = sub.receptor_name.unique()
        ix = {q: np.where(sub.receptor_name.values == q)[0] for q in recs}
        bs = []
        for _ in range(B):
            sel = np.concatenate([ix[q] for q in rng.choice(recs, len(recs))])
            xx, yy = x[sel], y[sel]
            bs.append(safe_r(xx, yy))
        bs = np.array(bs, float)
        # receptor-level permutation of the outcome
        null = []
        base = sub.drop_duplicates('receptor_name').set_index('receptor_name')[outcome]
        for _ in range(B):
            perm = pd.Series(rng.permutation(base.values), index=base.index)
            yv = resid(stats.rankdata(sub.receptor_name.map(perm).values), g)
            nv = safe_r(x, yv)
            null.append(abs(nv) if np.isfinite(nv) else 0.0)
        null = np.array(null, float)
        rows.append(dict(descriptor=f, outcome=outcome, n_units=len(sub),
                         n_receptors=len(recs), partial_spearman=r,
                         ci_low=np.nanpercentile(bs, 2.5), ci_high=np.nanpercentile(bs, 97.5),
                         p_perm=(1 + (null >= abs(r)).sum()) / (1 + B)))

res = pd.DataFrame(rows)
for outcome, g in res.groupby('outcome'):
    res.loc[g.index, 'q_BH'] = stats.false_discovery_control(g.p_perm.values)
res = res.sort_values('p_perm')
res.to_csv(f'{OUT}/promiscuity_cavity.tsv', sep='\t', index=False)
json.dump(dict(seed=SEED, bootstraps=B, n_descriptors=len(feats)), open(f'{OUT}/run_info.json', 'w'), indent=1)
pd.set_option('display.width', 220)
print(res.head(16).round(3).to_string())
print('\nBH-significant (q<0.05):', int((res.q_BH < 0.05).sum()), 'of', len(res))
