"""Figure 5: no shared class-specific Galpha pose within receptors."""
import sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

SRC, OUT = sys.argv[1], sys.argv[2]
plt.rcParams.update({
    "font.family": "Liberation Sans", "font.size": 8.5, "axes.labelsize": 9, "axes.titlesize": 9.5,
    "xtick.labelsize": 8.5, "ytick.labelsize": 8.5, "legend.fontsize": 8.0,
    "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.9,
    "axes.edgecolor": "#212529", "xtick.color": "#212529", "ytick.color": "#212529",
    "axes.labelcolor": "#212529", "text.color": "#212529"})
GRID, MUTED = "#DFE3E8", "#495057"
PC = {"Gi/o vs Gq/11": "#1B998B", "Gi/o vs Gs": "#E8871E", "Gq/11 vs Gs": "#6F44A8"}
rng = np.random.default_rng(20261031)

d = pd.read_csv(f"{SRC}/per_receptor_pose.tsv", sep="\t")
cons = pd.read_csv(f"{SRC}/direction_consistency.tsv", sep="\t")
order = ["Gi/o vs Gq/11", "Gi/o vs Gs", "Gq/11 vs Gs"]

fig = plt.figure(figsize=(7.0, 2.95))
gs = fig.add_gridspec(1, 3, width_ratios=[1.05, 1.0, 0.95], left=0.085, right=0.985,
                      bottom=0.215, top=0.80, wspace=0.40)
def panel(ax, L): ax.text(-0.26, 1.26, L, transform=ax.transAxes, fontsize=11,
                          fontweight="bold", va="top")

# A: magnitude, receptor core vs alpha5
ax = fig.add_subplot(gs[0, 0]); panel(ax, "A")
for p in order:
    g = d[d.pair == p]
    ax.scatter(g.receptor_core_rmsd, g.a5_centroid_shift, s=22, color=PC[p], alpha=0.85,
               lw=0.4, edgecolor="white", label=p, zorder=3)
lim = [0, max(d.receptor_core_rmsd.max(), d.a5_centroid_shift.max()) * 1.08]
ax.plot(lim, lim, color=MUTED, ls=(0, (3, 3)), lw=0.9, zorder=1)
ax.set_xlim(0, 2.6); ax.set_ylim(0, 2.6)
off = d[(d.a5_centroid_shift > 2.6) | (d.receptor_core_rmsd > 2.6)]
if len(off):
    ax.annotate(f"{len(off)} off scale\n(US28, {off.a5_centroid_shift.max():.1f} Å)",
                xy=(2.5, 2.42), ha="right", va="top", fontsize=7.2, color=MUTED)
ax.set_xlabel("Receptor TM-core RMSD (Å)"); ax.set_ylabel("Gα α5 centroid shift (Å)")
ax.set_title("Movement between captured classes", pad=8)
ax.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)
ax.legend(frameon=False, loc="upper left", handletextpad=0.2, borderpad=0.1, labelspacing=0.2)

# B: directional consistency against the sign-flip null
ax = fig.add_subplot(gs[0, 1]); panel(ax, "B")
for i, p in enumerate(order):
    V = d[d.pair == p][["dx", "dy", "dz"]].to_numpy(float)
    V = V / np.linalg.norm(V, axis=1, keepdims=True)
    iu = np.triu_indices(len(V), 1)
    null = [( (V*s[:,None]) @ (V*s[:,None]).T )[iu].mean()
            for s in rng.choice([-1.0, 1.0], size=(2000, len(V)))]
    ax.violinplot([null], positions=[i], widths=0.7, showextrema=False)
    obs = cons[cons.pair == p].mean_cosine.iloc[0]
    ax.scatter([i], [obs], s=46, color=PC[p], zorder=4, lw=0.6, edgecolor="white")
for b in [c for c in ax.collections if hasattr(c,"set_facecolor")][:len(order)]:
    b.set_facecolor("#CED4DA"); b.set_alpha(0.85); b.set_edgecolor("none")
ax.axhline(0, color=MUTED, lw=0.8)
ax.set_xticks(range(3)); ax.set_xticklabels([o.replace(" vs ", "\nvs ") for o in order])
ax.set_ylabel("Mean pairwise cosine of\nα5 displacement vectors")
ax.set_title("Shared direction across receptors", pad=8)
ax.grid(True, axis="y", color=GRID, lw=0.7); ax.set_axisbelow(True)

# C: alpha5 axis angle
ax = fig.add_subplot(gs[0, 2]); panel(ax, "C")
for i, p in enumerate(order):
    v = d[d.pair == p].a5_axis_angle_deg.values
    ax.boxplot(v, positions=[i], widths=0.52, showfliers=False,
               medianprops=dict(color="#212529", lw=1.5),
               whiskerprops=dict(color=MUTED, lw=0.9), capprops=dict(color=MUTED, lw=0.9),
               boxprops=dict(facecolor="white", edgecolor=MUTED, lw=0.9), patch_artist=True)
    ax.scatter(i + rng.uniform(-0.15, 0.15, len(v)), v, s=18, color=PC[p], alpha=0.8,
               lw=0.35, edgecolor="white", zorder=3)
ax.set_xticks(range(3)); ax.set_xticklabels([o.replace(" vs ", "\nvs ") for o in order])
ax.set_ylabel("α5 axis angle between\ncaptured classes (°)")
ax.set_title("Reorientation magnitude", pad=8)
ax.grid(True, axis="y", color=GRID, lw=0.7); ax.set_axisbelow(True)

fig.savefig(f"{OUT}/Figure_5.tif", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
fig.savefig(f"{OUT}/Figure_5_preview.png", dpi=170)
print("written")
