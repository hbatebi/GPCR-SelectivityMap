Source Data S2

Activation predictions, receptor/state aggregation, cross-validation outputs and sparse activation-code feature selection.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
