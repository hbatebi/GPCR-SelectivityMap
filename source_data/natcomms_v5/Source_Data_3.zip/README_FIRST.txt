Source Data S3

Archive-wide receptor-transducer units, feature availability, five-fold receptor-grouped assignments, out-of-fold predictions and coefficients.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.

Primary 207-unit five-fold receptor-grouped split counts:
test: 31-36 receptors / 39-42 units; training: 133-138 receptors / 165-168 units.
