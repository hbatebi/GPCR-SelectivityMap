#!/usr/bin/env python3
"""Audits evolutionary robustness of frozen GPCR captured-class out-of-fold predictions.

IMPORTANT: S25 strict_coordinate_only is a different estimator from S24's independently
nested 89-descriptor geometry_strict. Never use S25 predictions to calculate an
S24 paired geometry-versus-sequence AUC difference.

--paired-oof can ingest directly exported matched S24 out-of-fold probabilities.
For paired files, expect columns validation, model, analysis_row_id, receptor_name,
captured_family, sequence_cluster_50, sequence_cluster_40, sequence_cluster_30,
outer_fold, p_Gi_o, p_Gq_11, p_Gs.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata

CLASSES = ('Gi/o', 'Gq/11', 'Gs')
PROBS = ('p_Gi_o','p_Gq_11','p_Gs')
VALIDATIONS=('receptor','seq50','seq40','seq30')
GROUPCOL={v: (f'sequence_cluster_{v[-2:]}' if v != 'receptor' else 'receptor_name') for v in VALIDATIONS}
FOLDCOL={'receptor':'receptor_grouped_5fold','seq50':'sequence_cluster_50_grouped_5fold','seq40':'sequence_cluster_40_grouped_5fold','seq30':'sequence_cluster_30_grouped_5fold'}

def auc_binary(y, score):
    n1=int(np.count_nonzero(y)); n0=len(y)-n1
    if n0 == 0 or n1 == 0: return np.nan
    ranks=rankdata(score, method='average')
    return (ranks[y].sum() - n1*(n1+1)/2.0)/(n0*n1)

def class_aucs(y,p):
    return [auc_binary(y==c,p[:,i]) for i,c in enumerate(CLASSES)]

def macro_auc(y,p, strict=True):
    vals=np.asarray(class_aucs(y,p))
    if strict and not np.isfinite(vals).all():return np.nan
    return float(np.nanmean(vals)) if np.isfinite(vals).any() else np.nan

def boot(y, p, group, B, rng, counterpart=None):
    gr=pd.Series(group).astype(str).to_numpy(); unique=np.unique(gr)
    members=[np.flatnonzero(gr==g) for g in unique]
    vals=np.full(B,np.nan)
    for b in range(B):
        picks=rng.integers(len(members),size=len(members))
        indices=np.concatenate([members[k] for k in picks])
        a=macro_auc(y[indices],p[indices])
        if counterpart is None: vals[b]=a
        else:
            c=macro_auc(y[indices],counterpart[indices])
            if np.isfinite(a) and np.isfinite(c):vals[b]=a-c
    valid=np.isfinite(vals)
    return dict(n_groups=len(unique), valid_replicates=int(valid.sum()), total_replicates=B,
                fraction_valid=round(float(np.mean(valid)),4),
                ci_low=float(np.nanquantile(vals,.025)) if valid.any() else np.nan,
                median=float(np.nanmedian(vals)) if valid.any() else np.nan,
                ci_high=float(np.nanquantile(vals,.975)) if valid.any() else np.nan)

def group_summary(d,group):
    rows=[]
    for g,z in d.groupby(group,dropna=False):
        rows.append(dict(group=str(g),n_units=len(z),n_receptors=z.receptor_name.nunique(),
            n_Gi_o=int(z.captured_family.eq('Gi/o').sum()),
            n_Gq_11=int(z.captured_family.eq('Gq/11').sum()),
            n_Gs=int(z.captured_family.eq('Gs').sum()),
            outer_folds=int(z[FOLDCOL[d.validation.iloc[0]]].nunique())))
    return pd.DataFrame(rows).sort_values('n_units',ascending=False).reset_index(drop=True)

def fold_analysis(d):
    out=[]; fcol=FOLDCOL[d.validation.iloc[0]]
    for k,z in d.groupby(fcol):
        y=z.captured_family.to_numpy(); p=z[list(PROBS)].to_numpy()
        ac=class_aucs(y,p)
        out.append(dict(validation=d.validation.iloc[0],outer_fold=k,
                        n_units=len(z),n_receptors=z.receptor_name.nunique(),
                        macro_available_classes=float(np.nanmean(ac)) if np.isfinite(ac).any() else np.nan,
                        macro_three_classes=macro_auc(y,p),
                        **{f'auc_{c.replace("/", "_")}': x for c,x in zip(CLASSES,ac)},
                        **{f'n_{c.replace("/", "_")}':int((y==c).sum()) for c in CLASSES}))
    return pd.DataFrame(out)

def analyze_frozen(pth,out,B,seed):
    d=pd.read_csv(pth,sep='\t')
    if d.validation.nunique()!=4:raise ValueError('Expected four validation values')
    if d.duplicated(['validation','analysis_row_id']).any():raise ValueError('Duplicate unit per split')
    rng=np.random.default_rng(seed)
    cols=[]; clusters=[]; influences=[]; folds=[]; bootrows=[]
    for val in VALIDATIONS:
        z=d.loc[d.validation==val].copy().reset_index(drop=True)
        y=z.captured_family.to_numpy(); p=z[list(PROBS)].to_numpy()
        gcol=GROUPCOL[val]
        obs=macro_auc(y,p)
        groups=group_summary(z,gcol); groups.insert(0,'validation',val)
        clusters.append(groups)
        folds.append(fold_analysis(z))
        gb=boot(y,p,z[gcol].to_numpy(),B,rng)
        rb=boot(y,p,z.receptor_name.to_numpy(),B,rng)
        bootrows += [dict(validation=val,bootstrap='by_identity_cluster' if val!='receptor' else 'by_receptor', **gb),
                     dict(validation=val,bootstrap='by_receptor', **rb)] if val!='receptor' else [dict(validation=val,bootstrap='by_receptor',**rb)]
        # Quantify all leave-one-cluster-out effects, preserving frozen OOF scores.
        for _,r in groups.iterrows():
            mask=z[gcol].astype(str).to_numpy()!=r.group
            sub=macro_auc(y[mask],p[mask])
            influences.append(dict(validation=val,group=r.group,removed_units=int(r.n_units),removed_receptors=int(r.n_receptors),
                n_remaining=int(mask.sum()),auc_full=obs,auc_after_removal=sub,delta_after_minus_full=sub-obs if np.isfinite(sub) else np.nan))
        largest=groups.iloc[0]
        mask=z[gcol].astype(str).to_numpy()!=largest.group
        cols.append(dict(validation=val,estimator='S25_frozen_coord_strict',n_units=len(z),n_receptors=z.receptor_name.nunique(),
            n_clusters=len(groups),largest_cluster=largest.group,largest_cluster_units=int(largest.n_units),
            largest_cluster_share=float(largest.n_units/len(z)),n_outer_folds=z[FOLDCOL[val]].nunique(),
            pooled_macro_auc=obs,leave_largest_cluster_out_auc=macro_auc(y[mask],p[mask]),
            **{f'auc_{c.replace("/", "_")}':v for c,v in zip(CLASSES,class_aucs(y,p))}))
    pd.DataFrame(cols).to_csv(out/'frozen_summary.tsv',sep='\t',index=False)
    pd.concat(clusters).to_csv(out/'cluster_sizes.tsv',sep='\t',index=False)
    pd.DataFrame(influences).to_csv(out/'leave_one_cluster_out.tsv',sep='\t',index=False)
    pd.concat(folds).to_csv(out/'fold_class_balance.tsv',sep='\t',index=False)
    pd.DataFrame(bootrows).to_csv(out/'frozen_bootstrap.tsv',sep='\t',index=False)
    return pd.DataFrame(cols)

def analyze_paired(pth,out,B,seed):
    d=pd.read_csv(pth,sep='\t')
    required={'validation','model','analysis_row_id','receptor_name','captured_family',*PROBS}
    absent=required-set(d.columns)
    if absent:raise ValueError(f'Paired file missing columns: {sorted(absent)}')
    rng=np.random.default_rng(seed)
    reports=[]; bootstrap=[]; influences=[]
    for val in VALIDATIONS:
        s=d[d.validation==val].copy()
        base=s[s.model=='sequence_only'].copy().set_index('analysis_row_id')
        for model in ('geometry_strict','sequence_plus_geometry_strict'):
            cand=s[s.model==model].copy().set_index('analysis_row_id')
            if not base.index.is_unique or not cand.index.is_unique:raise ValueError('Duplicate held-out row in model')
            if set(base.index)!=set(cand.index):raise ValueError(f'Unmatched rows in {val}/{model}')
            cand=cand.reindex(base.index)
            if not (base.captured_family.to_numpy()==cand.captured_family.to_numpy()).all():raise ValueError('Different class labels!')
            if not (base.receptor_name.to_numpy()==cand.receptor_name.to_numpy()).all():raise ValueError('Different receptor labels!')
            if 'outer_fold' in base and not (base.outer_fold.to_numpy()==cand.outer_fold.to_numpy()).all():raise ValueError('Different folds!')
            y=base.captured_family.to_numpy(); pa=cand[list(PROBS)].to_numpy();pb=base[list(PROBS)].to_numpy()
            delta=macro_auc(y,pa)-macro_auc(y,pb)
            gcol=GROUPCOL[val]
            if gcol not in base.columns:raise ValueError(f'Missing {gcol} in paired table')
            group=base[gcol].to_numpy()
            bg=boot(y,pa,group,B,rng,pb)
            br=boot(y,pa,base.receptor_name.to_numpy(),B,rng,pb)
            reports.append(dict(validation=val,model=model,estimator='S24_clean_refit',n_units=len(y),n_groups=bg['n_groups'],
                        geom_auc=macro_auc(y,pa),sequence_auc=macro_auc(y,pb),paired_delta=delta))
            for label, res in [('by_identity_cluster' if val!='receptor' else 'by_receptor',bg),('by_receptor',br)]:
                bootstrap.append(dict(validation=val,model=model,bootstrap=label,**res))
            unique,counts=np.unique(group.astype(str),return_counts=True)
            for c,n in zip(unique,counts):
                mask=group.astype(str)!=c
                a=macro_auc(y[mask],pa[mask]);b=macro_auc(y[mask],pb[mask])
                influences.append(dict(validation=val,model=model,group=c,removed_units=n,
                  paired_delta_after_removal=a-b if np.isfinite(a) and np.isfinite(b) else np.nan,
                  difference_from_full=(a-b)-delta if np.isfinite(a) and np.isfinite(b) else np.nan))
    pd.DataFrame(reports).to_csv(out/'paired_clean_summary.tsv',sep='\t',index=False)
    pd.DataFrame(bootstrap).to_csv(out/'paired_clean_bootstrap.tsv',sep='\t',index=False)
    pd.DataFrame(influences).to_csv(out/'paired_clean_cluster_influence.tsv',sep='\t',index=False)


def draw(out, summary):
    try:
        import matplotlib;matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        x=np.arange(len(VALIDATIONS))
        plt.figure(figsize=(8,4.7))
        plt.plot(x,summary.pooled_macro_auc.to_numpy(),'o-',label='Pooled frozen AUC')
        plt.plot(x,summary.leave_largest_cluster_out_auc.to_numpy(),'s--',label='Largest cluster excluded')
        plt.axhline(.5,color='gray',ls=':',lw=1)
        plt.xticks(x,['Receptor','50% identity','40% identity','30% identity'])
        plt.ylabel('Captured-class macro ROC AUC')
        plt.ylim(0.35,0.9);plt.legend(loc='upper right');plt.tight_layout()
        plt.savefig(out/'frozen_cluster_influence.png',dpi=180);plt.close()
        cl=pd.read_csv(out/'cluster_sizes.tsv',sep='\t')
        fig,ax=plt.subplots(figsize=(8,4.7))
        for i,val in enumerate(VALIDATIONS):
            a=cl[cl.validation==val].n_units.to_numpy()
            ax.bar(i,len(a),color='#78909c',alpha=.8)
            ax.text(i,len(a)+2,f'Largest: {a.max()}/{a.sum()} ({a.max()/a.sum():.0%})',ha='center',fontsize=9)
        ax.set_xticks(x,['Receptor','50% identity','40% identity','30% identity'])
        ax.set_ylabel('Number of independent label-defined groups')
        fig.tight_layout();fig.savefig(out/'cluster_imbalance.png',dpi=180);plt.close(fig)
    except Exception as e:print('Skipping figures:',repr(e))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--frozen',required=True,help='Source Data 25 clean_model_predictions_by_unit.tsv')
    ap.add_argument('--paired-oof',help='Optional matching clean Source Data 24 OOF scores by model')
    ap.add_argument('--out',default='results')
    ap.add_argument('--boot',type=int,default=2000)
    ap.add_argument('--seed',type=int,default=20261104)
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    summary=analyze_frozen(args.frozen,out,args.boot,args.seed)
    draw(out,summary)
    if args.paired_oof:analyze_paired(args.paired_oof,out,args.boot,args.seed+7)
    else:(out/'PAIRED_S24_NOT_VERIFIED.txt').write_text(
        'S24 clean per-unit model predictions are absent. No cluster-bootstrap or leave-cluster-out of paired S24 geometry minus sequence differences was calculated.\n'
        'Use refit_with_oof.py to generate matched predictions from the complete original S11 archive + per-structure measurements, then rerun with --paired-oof.\n')
    print('\nFrozen S25 coordinates (NOT paired S24 model):\n',summary.to_string(index=False))
    print('\nResults saved in',out)

if __name__=='__main__':main()
