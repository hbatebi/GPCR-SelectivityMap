#!/usr/bin/env python3
"""Read-only numerical audit of the exported Source Data 24 out-of-fold predictions.

This does not refit models. It recomputes ROC AUC from held-out scores,
checks fold and data integrity, calculates matched paired cluster bootstrap
CIs using frequency weights instead of replicating units, and calculates
leave-one-cluster-out and fold-local deltas.
"""
import os
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score

OUT=Path(os.environ.get('SD28_DIR', Path(__file__).resolve().parent))
D=pd.read_csv(OUT/'clean_refit_oof_predictions.tsv',sep='\t')
CLASSES=['Gi/o','Gq/11','Gs']
SCORE_COLS=['p_Gi_o','p_Gq_11','p_Gs']
MODELS=['sequence_only','geometry_strict','sequence_plus_geometry_strict']
VAL_GROUP={'receptor':'receptor_name','seq50':'sequence_cluster_50','seq40':'sequence_cluster_40','seq30':'sequence_cluster_30'}

def prepare(val):
    block=D[D.validation==val]
    parts={m:block[block.model==m].set_index('analysis_row_id').sort_index() for m in MODELS}
    b=parts['sequence_only']
    if any(len(p)!=207 or not p.index.equals(b.index) for p in parts.values()):raise ValueError('Unpaired rows')
    if any(not p[['captured_family','outer_fold','receptor_name','sequence_cluster_50','sequence_cluster_40','sequence_cluster_30']].equals(b[['captured_family','outer_fold','receptor_name','sequence_cluster_50','sequence_cluster_40','sequence_cluster_30']]) for p in parts.values()):raise ValueError('Metadata mismatch')
    if (b.groupby(VAL_GROUP[val]).outer_fold.nunique()>1).any():raise ValueError('Group leakage')
    for m,p in parts.items():
        if not (p[SCORE_COLS].apply(np.isfinite).all().all() and np.allclose(p[SCORE_COLS].sum(axis=1),1,atol=1e-10)):raise ValueError('Invalid scores')
    return parts

def sklearn_auc(df):
    y=df.captured_family.to_numpy()
    if len(set(y))<3:return float('nan')
    return float(np.mean([roc_auc_score(y==c, df[s]) for c,s in zip(CLASSES,SCORE_COLS)]))

class PreparedAUC:
    def __init__(self,parts):
        self.n=len(parts['sequence_only'])
        self.positive=np.array([[v==c for v in parts['sequence_only'].captured_family.to_numpy()] for c in CLASSES])
        self.bins={}
        for model,df in parts.items():
            self.bins[model]=[]
            for col in SCORE_COLS:
                _,bin_idx=np.unique(df[col].to_numpy(),return_inverse=True)
                self.bins[model].append((bin_idx,bin_idx.max()+1))

    def auc(self,model,weight):
        av=[]
        for i in range(3):
            pb=self.positive[i]
            b,sz=self.bins[model][i]
            wp=np.bincount(b, weights=weight*pb, minlength=sz)
            wn=np.bincount(b, weights=weight*(~pb), minlength=sz)
            npos=wp.sum();nneg=wn.sum()
            if npos<=0 or nneg<=0:return float('nan')
            neg_below=np.cumsum(wn)-wn
            av.append(np.dot(wp,neg_below+wn*0.5)/(npos*nneg))
        return float(np.mean(av))

def main():
    rng=np.random.default_rng(20261104+2026)
    paired=[]; boot=[]; loco=[]; folds=[]
    for val,gcol in VAL_GROUP.items():
        parts=prepare(val)
        base=parts['sequence_only']
        y=base.captured_family.to_numpy()
        calc=PreparedAUC(parts)
        estimates={m:sklearn_auc(parts[m]) for m in MODELS}
        for mod in MODELS:
            x=calc.auc(mod,np.ones(len(base)))
            assert np.isclose(x,estimates[mod],atol=1e-12),(val,mod,x,estimates[mod])
        for mod in MODELS[1:]:
            paired.append(dict(validation=val,model=mod,n=207,sequence_auc=estimates['sequence_only'],model_auc=estimates[mod],auc_difference=estimates[mod]-estimates['sequence_only']))
        gg=base[gcol].to_numpy()
        for group in np.unique(gg):
            w=(gg!=group).astype(float)
            for mod in MODELS[1:]:
                de=calc.auc(mod,w)-calc.auc('sequence_only',w)
                loco.append(dict(validation=val,model=mod,group=group,excluded_n=int((gg==group).sum()),paired_delta=de))
        for fold in sorted(base.outer_fold.unique()):
            w=(base.outer_fold.to_numpy()==fold)
            if len(set(y[w]))<3:continue
            fvals={model:sklearn_auc(part.iloc[np.flatnonzero(w)]) for model,part in parts.items()}
            folds.append(dict(validation=val,outer_fold=int(fold),n=int(w.sum()),sequence_auc=fvals['sequence_only'],geometry_auc=fvals['geometry_strict'],geometry_minus_sequence=fvals['geometry_strict']-fvals['sequence_only'],combined_minus_sequence=fvals['sequence_plus_geometry_strict']-fvals['sequence_only']))
        for bootmode,col in [('sequence-cluster',gcol),('receptor','receptor_name')]:
            codes,uniques=pd.factorize(base[col].to_numpy(),sort=True)
            N=len(uniques);B=3000
            diffs={mod:[] for mod in MODELS[1:]}
            for _ in range(B):
                idx=rng.integers(0,N,size=N)
                gweight=np.bincount(idx,minlength=N)
                w=gweight[codes]
                baseline=calc.auc('sequence_only',w)
                if not np.isfinite(baseline):continue
                for mod in MODELS[1:]:
                    dt=calc.auc(mod,w)-baseline
                    if np.isfinite(dt):diffs[mod].append(dt)
            for mod,arr in diffs.items():
                arr=np.array(arr)
                boot.append(dict(validation=val,model=mod,sampling=bootmode,n_groups=N,valid=int(len(arr)),B=B,ci_low=float(np.quantile(arr,0.025)) if len(arr) else np.nan,median=float(np.median(arr)) if len(arr) else np.nan,ci_high=float(np.quantile(arr,0.975)) if len(arr) else np.nan))
        print(val, 'AUC', estimates, flush=True)
    for name,rows in [('independent_paired_auc.tsv',paired),('independent_paired_bootstrap.tsv',boot),('independent_paired_loco.tsv',loco),('independent_fold_aucs.tsv',folds)]:
        pd.DataFrame(rows).to_csv(OUT/name,sep='\t',index=False)
    print(pd.DataFrame(boot).to_string(index=False))

if __name__=='__main__':main()
