# Source Data 28: verification of the paired evolutionary analysis

Input: `clean_refit_oof_predictions.tsv`, the held-out class probabilities exported from the clean refit
(Source Data 24). The models were not retrained for this analysis.

## Integrity checks
- Four validation settings, three models and 207 held-out units per model (2,484 rows).
- 169 receptor entries; captured classes 102 Gi/o, 53 Gq/11 and 52 Gs.
- Rows align exactly across models by `analysis_row_id`, label, receptor and outer fold.
- Every class probability is finite and each unit's three probabilities sum to 1.
- Every receptor and every sequence-identity cluster is confined to a single outer fold.

## Recomputed results (macro ROC AUC from held-out scores)
| Split | Geometry | Sequence | Geometry minus sequence | 95% CI, whole-group bootstrap (3,000 draws) |
|---|---:|---:|---:|---:|
| Receptor-grouped | 0.776 | 0.803 | -0.027 | -0.074 to +0.019 (receptors) |
| 50% identity | 0.726 | 0.586 | +0.140 | +0.038 to +0.200 (48 clusters) |
| 40% identity | 0.678 | 0.581 | +0.097 | +0.042 to +0.176 (20 clusters) |
| 30% identity | 0.493 | 0.536 | -0.042 | -0.067 to +0.234 (5 clusters) |

Per-fold paired differences: 50% identity +0.020, +0.083, +0.219, +0.031, +0.145; 40% identity +0.057,
+0.141, +0.073, +0.049, +0.040 (fold sizes 135, 21, 18, 16 and 17 units). Removing any single cluster from the
fixed predictions leaves the difference between +0.118 and +0.154 at 50% identity and between +0.078 and +0.122
at 40% identity.

## Limits
- Intervals condition on the fitted predictions and exclude refitting and feature-extraction uncertainty.
- At 40% identity one cluster holds 135 of 207 units.
- The 30% split has five clusters (one with 196 units) and two usable folds; it is not informative and
  does not define an evolutionary threshold.
- These results concern the captured structural class, not functional coupling preference.
