"""Single-cell check: endpoint_geometry, receptor_grouped, with optional receptor restriction."""
import sys, numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
CPL, LABEL, PRED, RESTRICT = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
rng = np.random.default_rng(20261031); B = NPERM = 1000
FAM = ['Gi/o', 'Gq/11', 'Gs']; FI = {f: i for i, f in enumerate(FAM)}
P = pd.read_csv(CPL, sep='\t', index_col=0)[FAM].fillna(0.0); P = P[P.sum(axis=1) > 0]
if RESTRICT != 'none':
    keep = set(pd.read_csv(RESTRICT, sep='\t').receptor_name.unique())
    P = P[P.index.isin(keep)]
pred = pd.read_csv(PRED, sep='\t'); pred = pred[pred.receptor_name.isin(P.index)]
d = pred[(pred.experiment == 'endpoint_geometry') & (pred.validation == 'receptor_grouped_5fold')] \
        .drop_duplicates(['pdb_id', 'receptor_name', 'transducer_family'])
rec, fam, sc, grp = [], [], [], []
for g, (_, r) in enumerate(d.iterrows()):
    for f in FAM:
        if f == r.transducer_family: continue
        rec.append(r.receptor_name); fam.append(FI[f]); sc.append(r[f'probability_{f}']); grp.append(g)
rec, fam, score, grp = np.array(rec), np.array(fam), np.array(sc, float), np.array(grp)
recs = pd.unique(rec); pos = {r: i for i, r in enumerate(recs)}
rec_i = np.array([pos[r] for r in rec]); M = P.loc[recs].values; rates = M[rec_i, fam]
def auc_of(rt, s, fm):
    a = []
    for k in range(3):
        m = fm == k; y = (rt[m] > 0).astype(int)
        if 0 < y.sum() < len(y): a.append(roc_auc_score(y, s[m]))
    return np.mean(a) if a else np.nan
obs = auc_of(rates, score, fam)
ix = {i: np.where(rec_i == i)[0] for i in range(len(recs))}
bs = [auc_of(rates[r], score[r], fam[r]) for r in
      (np.concatenate([ix[i] for i in rng.choice(len(recs), len(recs))]) for _ in range(B))]
null = [auc_of(M[rng.permutation(len(recs))][rec_i, fam], score, fam) for _ in range(NPERM)]
print('%-28s n_rec=%-4d n_units=%-4d AUC=%.3f  95%% CI %.3f to %.3f  null=%.3f  p=%.4f'
      % (LABEL, len(recs), d.pdb_id.nunique(), obs,
         np.nanpercentile(bs, 2.5), np.nanpercentile(bs, 97.5), np.nanmean(null),
         (1 + np.nansum(np.array(null) >= obs)) / (1 + NPERM)))
