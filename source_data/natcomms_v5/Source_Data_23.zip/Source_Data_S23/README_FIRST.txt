Source Data S23
Cross-platform comparison of structure-based transducer prediction against
equilibrium coupling data.

Contents
  bouvier_family_max.tsv / inoue_family_max.tsv
      Family-level log(Emax/EC50), maximum across the subtypes of each family,
      for receptors shared with the structural census. Empty cell = no coupling
      reported by that source.
  bouvier_family_avg.tsv / inoue_family_avg.tsv
      As above, family average instead of maximum (sensitivity analysis).
  xplat_bouvier.tsv / xplat_inoue.tsv
      Non-captured-family ROC AUC for all three models under all four validation
      schemes, with receptor-clustered bootstrap intervals (2,000 resamples) and
      receptor-permutation nulls (2,000 permutations).
  control_restricted_receptors.txt
      Endpoint-geometry, receptor-grouped cell recomputed after restricting each
      equilibrium panel to the receptors the kinetic panel also covers, plus the
      family-average sensitivity run.
  ext_couplings.py, run_xplat.py, xplat_cell.py
      Scripts. Seed 20261031 throughout.

Provenance
  Equilibrium coupling values were read from Source data 5 of Hauser et al.,
  eLife 11:e74107 (2022), tabs B-LogEmaxOverpEC50 and I-LogEmaxOverpEC50, which
  report the Avet et al. (eLife 11:e74101, 2022) and Inoue et al. (Cell 177,
  1933-1947, 2019) datasets separately. Treating an empty cell as no reported
  coupling was checked against the Merged_couplings tab of the same file over
  1,200 subtype entries with no disagreement. Out-of-fold predictions were taken
  unchanged from Source Data S11; no model was refitted.
