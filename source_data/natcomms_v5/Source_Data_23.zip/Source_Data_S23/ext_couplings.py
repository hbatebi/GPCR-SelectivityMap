import sys, pandas as pd
from openpyxl import load_workbook
SD5, PRED, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
wb = load_workbook(SD5, read_only=True, data_only=True)
def grab(sheet, pfx, agg='MAX'):
    rows = list(wb[sheet].iter_rows(values_only=True)); hdr = rows[0]
    want = {f'{pfx}-Gs/olf-Log\nEmEC-{agg}': 'Gs', f'{pfx}-Gi/o-Log\nEmEC-{agg}': 'Gi/o',
            f'{pfx}-Gq/11-Log\nEmEC-{agg}': 'Gq/11'}
    idx = {want[str(h)]: i for i, h in enumerate(hdr) if h is not None and str(h) in want}
    assert len(idx) == 3, (sheet, agg, idx)
    out = {}
    for r in rows[1:]:
        if r[0] is None: continue
        out[str(r[0]).strip()] = {f: (r[j] if isinstance(r[j], (int, float)) else None) for f, j in idx.items()}
    D = pd.DataFrame(out).T
    D.index = [str(x).lower() + '_human' for x in D.index]
    return D[~D.index.duplicated()]
pred = pd.read_csv(PRED, sep='\t'); entries = set(pred.receptor_name.unique())
print('receptors in frozen predictions:', len(entries))
ovs = {}
for nm, pfx, sh in [('bouvier', 'B', 'B-LogEmaxOverpEC50'), ('inoue', 'I', 'I-LogEmaxOverpEC50')]:
    for agg in ['MAX', 'AVG']:
        D = grab(sh, pfx, agg); ov = sorted(entries & set(D.index))
        D.loc[ov].to_csv(f'{OUT}/{nm}_family_{agg.lower()}.tsv', sep='\t')
        if agg == 'MAX':
            ovs[nm] = ov
            print('%-8s rows=%-4d overlap=%-4d  non-blank per family=%s'
                  % (nm, len(D), len(ov), D.loc[ov].notna().sum().to_dict()))
wb.close()
a, b = set(ovs['bouvier']), set(ovs['inoue'])
print('both platforms and structures:', len(a & b), '| bouvier only:', len(a - b), '| inoue only:', len(b - a))
print('union:', len(a | b))
