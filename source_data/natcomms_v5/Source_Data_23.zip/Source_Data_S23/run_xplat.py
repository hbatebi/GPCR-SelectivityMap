"""Cross-platform replication of the non-captured-family test.
Identical estimator to run_noncaptured.py; the measured matrix P is replaced by
Bouvier (EMTA/ebBRET) or Inoue (TGFa shedding) family-level log(Emax/EC50).
Usage: python -I run_xplat.py <coupling tsv> <label> <S11 preds> <outdir>
"""
import sys, numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
CPL, LABEL, PRED, OUT = sys.argv[1:5]
SEED, B, NPERM = 20261031, 2000, 2000
rng = np.random.default_rng(SEED)
FAM = ['Gi/o', 'Gq/11', 'Gs']; FI = {f: i for i, f in enumerate(FAM)}

P = pd.read_csv(CPL, sep='\t', index_col=0)[FAM].fillna(0.0)
P = P[P.sum(1) > 0]                       # receptors with at least one detected coupling
pred = pd.read_csv(PRED, sep='\t')
pred = pred[pred.receptor_name.isin(P.index)]

def build(d):
    rec, fam, sc, grp = [], [], [], []
    for g, (_, r) in enumerate(d.iterrows()):
        for f in FAM:
            if f == r.transducer_family: continue
            rec.append(r.receptor_name); fam.append(FI[f]); sc.append(r[f'probability_{f}']); grp.append(g)
    return np.array(rec), np.array(fam), np.array(sc, float), np.array(grp)

def stats_arr(rates, score, fam, grp):
    aucs = []
    for k in range(3):
        m = fam == k; y = (rates[m] > 0).astype(int)
        if 0 < y.sum() < len(y): aucs.append(roc_auc_score(y, score[m]))
    order = np.argsort(grp, kind='stable')
    r2, s2, g2 = rates[order], score[order], grp[order]
    first = np.r_[True, g2[1:] != g2[:-1]]
    i0 = np.where(first)[0]; i0 = i0[(i0 + 1 < len(g2))]; i0 = i0[g2[i0] == g2[i0 + 1]]
    i1 = i0 + 1; diff = r2[i0] != r2[i1]
    acc = ((s2[i0] > s2[i1]) == (r2[i0] > r2[i1]))[diff]
    return (np.mean(aucs) if aucs else np.nan), (acc.mean() if acc.size else np.nan), int(acc.size)

out = []
vals = ['receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold',
        'sequence_cluster_40_grouped_5fold', 'sequence_cluster_30_grouped_5fold']
for exp in ['full_sequence', 'endpoint_geometry', 'global_identity_knn']:
    for val in vals:
        d = pred[(pred.experiment == exp) & (pred.validation == val)].drop_duplicates(
            ['pdb_id', 'receptor_name', 'transducer_family'])
        if len(d) < 10: continue
        rec, fam, score, grp = build(d)
        recs = pd.unique(rec); pos = {r: i for i, r in enumerate(recs)}
        rec_i = np.array([pos[r] for r in rec]); M = P.loc[recs].values
        rates = M[rec_i, fam]
        auc, acc, nacc = stats_arr(rates, score, fam, grp)
        ix = {i: np.where(rec_i == i)[0] for i in range(len(recs))}
        bs = []
        for _ in range(B):
            pick = rng.choice(len(recs), len(recs))
            rows = np.concatenate([ix[i] for i in pick])
            gg = grp[rows] + 1000000 * np.repeat(np.arange(len(pick)), [len(ix[i]) for i in pick])
            bs.append(stats_arr(rates[rows], score[rows], fam[rows], gg)[:2])
        bs = np.array(bs, float)
        null = []
        for _ in range(NPERM):
            perm = rng.permutation(len(recs))
            null.append(stats_arr(M[perm][rec_i, fam], score, fam, grp)[:2])
        null = np.array(null, float)
        out.append(dict(platform=LABEL, model=exp, validation=val, n_units=d.pdb_id.nunique(),
                        n_receptors=len(recs), n_pairs=len(rec), family_mean_auc=round(auc, 3),
                        auc_ci_low=round(np.nanpercentile(bs[:, 0], 2.5), 3),
                        auc_ci_high=round(np.nanpercentile(bs[:, 0], 97.5), 3),
                        auc_null_mean=round(np.nanmean(null[:, 0]), 3),
                        auc_p=round((1 + np.nansum(null[:, 0] >= auc)) / (1 + NPERM), 5),
                        pairwise_acc=round(acc, 3), n_pairwise=nacc,
                        acc_p=round((1 + np.nansum(null[:, 1] >= acc)) / (1 + NPERM), 5)))
df = pd.DataFrame(out); df.to_csv(f'{OUT}/xplat_{LABEL}.tsv', sep='\t', index=False)
print(df.to_string(index=False))
