Source Data S16 — within-receptor multiclass test under sequence-identity-cluster validation

Purpose
-------
The sequence-identity-cluster held-out-fold confound control applied to the
within-receptor multiclass test reported in Supplementary Table 31.

Provenance
----------
No model was refitted for this analysis. It reuses the frozen out-of-fold predictions already
supplied in Source Data S11
(results/microswitches/sequence_interface_audit_v1/predictions/out_of_fold_predictions.tsv),
which contain predictions for every representation under four validation schemes:
receptor-grouped 5-fold, and 50%, 40% and 30% sequence-identity-cluster-grouped 5-fold.

Design
------
Eligible receptors are the 34 receptors represented by at least two captured G protein classes
(72 receptor-transducer units; 28 Gi/o, 28 Gq/11, 16 Gs). The eligible set is identical under all
four validation schemes, so the schemes are directly comparable; only the fold structure, and
therefore the out-of-fold predictions, change.

For each unit the decision is restricted to the classes observed for that receptor. Two statistics
are computed: within-receptor accuracy, and the mean probability margin between the true class and
the best alternative. The null is 10,000 label permutations performed within each receptor,
preserving that receptor's observed class composition exactly.

Files
-----
within_receptor_identity_cluster.tsv   results for 5 representations x 4 validation schemes
within_receptor_cluster.py             the analysis script

Note on comparability
---------------------
These values come from the evolutionary-transfer audit (Source Data S11), whose endpoint-geometry
model reaches macro ROC AUC 0.776 under receptor-grouped validation. Its own receptor-grouped
reference is +0.051 (P = 0.009), and that is the correct baseline for the identity-cluster values
below; this is the value reported in Results 3.2 and Table S31. The separate archive-wide
static-first-pass run in Source Data S3 (macro ROC AUC 0.778) gives +0.065 (P = 0.008) and is
reported in Table S28. The two runs share the same 107 inputs and the same fold assignment but
differ in estimator configuration, so their values are not interchangeable and comparisons across
validation schemes must be made within a single run.
