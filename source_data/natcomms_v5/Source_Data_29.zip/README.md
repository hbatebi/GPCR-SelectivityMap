# GPCR ligand–function Master Analysis v5

**ONE PACKAGE. ONE COMMAND.** An end-to-end, source-traceable structural/pharmacological case-study suite for the author's Nature Communications manuscript v5.

## Run the complete analysis (Linux, internet access)

```bash
cd ~/Downloads
unzip GPCR_Ligand_Function_Master_v5.zip
cd GPCR_Ligand_Function_Master_v5
conda activate contactflare
bash RUN_ALL.sh
```

The runner installs (or verifies) Python packages, downloads exactly **three missing structures** (8FY8, 8FYT, 8FYE) automatically from RCSB, checks PDB chain and ligand-component identities, reruns the four-receptor panel and the complete five-ligand Warren et al. 2024 5-HT1A–Gi1 series, executes structural-alignment and contact-cutoff sensitivity, makes figures, writes a cautionary scientific report, and generates **one results ZIP**:

`GPCR_Ligand_Function_v5_COMPLETE_RESULTS.zip`

Upload that file for manuscript evaluation. No other package or supplementary script is needed. The **12 other mmCIF coordinate files are included**. Downloads will be reused on successive runs; the runner stops if a structure cannot be downloaded or validated. This working environment lacks outbound access to the RCSB coordinate server, so the three files cannot be bundled and the full five-structure run cannot be validated here.

To skip pip installation if your environment is already prepared:

```bash
SKIP_PIP_INSTALL=1 bash RUN_ALL.sh
```

## Immediate offline verification (does not require new PDB downloads)

```bash
SKIP_PIP_INSTALL=1 bash RUN_OFFLINE_TEST.sh
```

This correctly processes 10 four-receptor structures and **only two of five Warren structures**; do not treat the resulting `_OFFLINE_TEST_RESULTS.zip` as the scientific final result. The OFFLINE TEST scripts are identical to the COMPLETE run, except that they explicitly allow missing structures.

## Complete scope

**A. Four receptor systems (same receptor, same G-protein family)**
- 5-HT1A: serotonin versus aripiprazole (7E2Y, 7E2Z)
- D1: fenoldopam versus tavapadon (7X2C, 7X2D)
- α2A: adrenaline versus dexmedetomidine (9CBL, 9CBM)
- MC1R: α-MSH versus SHU9119 (7F4D, 7F4I)
- Controls: MC1R α-MSH vs afamelanotide, plus SHU9119; D1 mevidalen PAM-confounded comparison flagged and not merged with efficacy evidence.

**B. Within-publication five-ligand 5-HT1A–Gi1 series**
- 8FY8 5-MeO-DMT (DNG; downloads)
- 8FYT LSD (non-DNG; downloads)
- 8FYE 4-F,5-MeO-PyrT (non-DNG; downloads)
- 8FYL vilazodone (non-DNG; bundled)
- 8FYX buspirone (DNG; bundled)

This compares ten dependent PDB pairs but has **only five independent atomic models**. The study's same-assay Gi1 Emax (%) is available as verified numbers for 4-F,5-MeO-PyrT (102.8), vilazodone (97.4), and buspirone (93.4). Serotonin (100) and aripiprazole (77.1) also have measurements from the 2024 functional study but their structures were deposited in an earlier 2021 paper. LSD and 5-MeO-DMT are labelled qualitative until quantitative source values are checked.

**C. Calculations and negative controls**
- Receptor-side ligand and whole-Gα contact sets (all heavy atoms, 4.5 Å)
- C-terminal Gα α5 contact sets, α5-tip displacement and α5-axis angle after receptor-core alignment
- Alternative alignment windows
- Cα microswitch distances (TM3.50–TM6.34; TM5.50–TM6.44; TM3.50–TM7.53; TM6.48–TM7.53; TM3.40–TM5.50)
- Contact sensitivity thresholds **4.0 / 4.5 / 5.0 Å**, Dice, Jaccard and overlap coefficients
- Same-DNG-status versus mixed-Gα-construct strata, MC1R full-vs-full control, D1 PAM confounder
- Separate summary of verified functional data, explicit missing and contradictory evidence
- Figures, hashes, reproducible calculations, and a conservative candidate Results subsection for review

## Data integrity and interpretation

- Atom-level contacts must not be equated with kinetic activation or measured transducer-selective signalling.
- The 2024 Warren Emax series has limited dynamic range; do not claim a statistical correlation from ten nonindependent pairs.
- Different structural preparation, DNG constructs, experimental paper, ligand size, contact cutoff and resolution are potential confounders.
- The baseline v5 manuscript is **not edited**. `v5_inputs/Source_Data_1_from_v5.zip` and `input/generic_number_mapping_1360.csv` preserve the essential v5 analysis inputs. The full 35 MB submission is intentionally not duplicated.
- Numeric Emax is not invented. If original supplementary measurements are obtained later, update `input/5HT1A_functional_evidence.tsv`: fill `Emax_percent_of_serotonin` and change `quantitative_status` to `verified_number`; rerun the *same* `RUN_ALL.sh` without a new ZIP. Also record the direct source and uncertainties separately.
- `reports/CANDIDATE_RESULTS_SUBSECTION_REVIEW_REQUIRED.md` is an editorial draft, **not a proved mechanistic claim**.

## Troubleshooting

The program checks mmCIF chains and ligand component names before analysis. If your HPC compute node has no internet, fetch `8FY8.cif`, `8FYT.cif` and `8FYE.cif` on your login node into `structures/`, then run `SKIP_PIP_INSTALL=1 bash RUN_ALL.sh`. The runner skips existing nonempty CIF files. For any failure, upload `logs/` plus the full terminal traceback; you do not need a new package.

## Primary sources

See `reports/LITERATURE_AND_ANALYSIS_BOUNDARIES.md` for exact DOIs and interpretation limitations. This package was assembled on **2026-11-05** and is an internal reproducible research tool, not a new external preregistration.
