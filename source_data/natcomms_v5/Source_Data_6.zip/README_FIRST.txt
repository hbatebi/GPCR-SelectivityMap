Source Data S6

Coordinate-level receptor-only entity audit and independent functional-label provenance.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
