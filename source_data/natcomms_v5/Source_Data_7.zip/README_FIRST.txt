Source Data S7

Original coordinate-level bound/receptor-only reference analysis, including matched feature differences, out-of-fold predictions, audits, bootstraps and permutation outputs.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
