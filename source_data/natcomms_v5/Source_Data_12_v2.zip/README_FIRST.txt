Source Data S12

Software/reproduction metadata from the supplied analysis bundle; the canonical GPCR SelectivityMap v0.4.0 release is archived at DOI 10.5281/zenodo.22959127 and GitHub tag v0.4.0.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.

Canonical software release:
GPCR SelectivityMap v0.4.0
DOI: 10.5281/zenodo.22959127
GitHub: https://github.com/hbatebi/GPCR-SelectivityMap/tree/v0.4.0
