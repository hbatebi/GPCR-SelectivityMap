# GPCR ICL2 structurome and combinatorial microswitch pipeline

This repository contains three connected, reproducible workflows:

1. the original structural-bioinformatics census of intracellular loop 2 (ICL2)
   conformations across experimental class A GPCR structures; and
2. an extended study of canonical GPCR activation microswitches, combinatorial
   structural states, receptor-aware statistics, interpretable machine learning,
   robustness analyses, and publication-quality figures; and
3. a receptor-only analysis of whether intracellular conformational geometry
   contains G-protein-family information beyond the shared active-state scaffold.

The original ICL2 classification, data, scripts, and analyses remain available.
The new implementation is isolated under `src/gpcr_icl2/microswitches/` and uses
versioned YAML configuration under `config/`.

## v0.6.1 Stage 9 recovery

Version 0.6.1 fixes a pandas dtype-dependent `KeyError: icl2_partial` in
the same-receptor coupling statistics. Existing v9 measurements and Stage 1–8
outputs do not need to be repeated. After installing the patch, run:

```bash
./resume_from_stage9.sh
```

This reruns coupling specificity and then generates the final figures, manifest,
and technical report. See `docs/CHANGELOG_V0.6.1.md`.

## Fastest route: install and run everything

A Conda/Miniforge installation and internet access are required for the first
run. Unpack the archive and run:

```bash
./install_and_run.sh --quick
```

This creates or updates the locked `gpcr-microswitches` Conda environment, installs
the repository, runs the tests, and performs a small end-to-end smoke run that
retains the reference structures.

Run the complete 1,358-structure workflow with:

```bash
./install_and_run.sh
```

The full workflow first runs a four-reference scientific preflight and aborts
before the expensive census if mapping, alignment, or expected TM6 separation
fails. The preflight can also be run independently with `./run_preflight.sh`.

Install without starting the structural analysis:

```bash
./install_and_run.sh --install-only
```

See [`QUICKSTART.md`](QUICKSTART.md) for exact commands and operational notes.

## Main command-line interface

```bash
microswitches --help
microswitches run-all --help
```

The complete direct command is:

```bash
microswitches run-all \
  --metadata data/processed/dataset_experimental.csv \
  --structures data/structures \
  --config-dir config \
  --output results/microswitches \
  --figures figures/microswitches \
  --workers 4
```

A quick run uses a limited structure subset, shorter resampling, and grouped
five-fold validation:

```bash
microswitches run-all --quick --limit 30
```

The workflow checkpoints downloads and measurements. Re-running the same command
resumes from valid cached results.

Version 0.6.0 adds a receptor-only voxel analysis of the complete central
intracellular cavity and corrects the coupling analysis to use truly nested
models. The primary manuscript-level comparison is `SCVE − SE`: complete
intracellular geometry and cavity architecture versus the same shared-activation
and metadata baseline. A second comparison, `SCV − SC`, isolates the added value
of the physical cavity descriptors beyond conventional distances and angles.
The workflow retains receptor-grouped, leave-one-receptor-out, fine-family, and
coarse leave-one-ligand-class-out validation. Candidate Gs, Gi/o, Gq/11, and
arrestin anchor structures are audited, while primary anchor predictions are
training-fold-derived to prevent receptor leakage. Arrestin is analysed in a
separate secondary branch. See `docs/CHANGELOG_V0.6.0.md` and
`docs/WHOLE_INTRACELLULAR_CAVITY_V0.6.0.md`.

## End-to-end stages

```text
1. metadata enrichment and dataset flow
2. RCSB coordinate download
3. receptor-chain selection, GPCRdb mapping and structural measurement
4. microswitch classification and threshold sensitivity
5. receptor-aware individual statistics and representative selection
6. co-occurrence, combinatorial states and unsupervised structural classes
7. grouped interpretable machine learning with receptor-state evaluation
8. robustness and sensitivity analyses
9. Gs/Gi/o/Gq/11 coupling census, nested receptor-only geometry and whole-
   cavity models, training-fold-derived anchor analysis, same-receptor pairs,
   a separate arrestin branch, and coupling robustness
10. SVG/PDF/600-DPI PNG figures, source data, interpretation gates, manifest,
    and report
```

The canonical panel includes TM6 opening, the DRY/ionic-lock region, PIF, CWxP,
NPxxY, sodium-pocket state, intracellular TM7 movement, and the existing ICL2
classifier. Raw continuous measurements, residue identities, quality flags,
categorical calls, and exclusion reasons are retained.

## Key output locations

```text
results/microswitches/dataset_flow.csv
results/microswitches/metadata/
results/microswitches/measurements/
results/microswitches/classification/
results/microswitches/statistics/
results/microswitches/machine_learning/
results/microswitches/robustness/
results/microswitches/validation/
results/microswitches/coupling_specificity/
results/microswitches/output_manifest.csv
results/microswitches/provenance.json
results/microswitches/FINAL_TECHNICAL_REPORT.md
figures/microswitches/
```

Each figure group is exported as editable SVG, vector PDF, and 600-DPI PNG, with
corresponding source-data tables.

## Stage-by-stage commands

```bash
# Metadata enrichment
microswitches prepare-metadata \
  --metadata data/processed/dataset_experimental.csv \
  --config-dir config \
  --output results/microswitches/metadata/structure_metadata_enriched.csv

# Coordinates
microswitches download \
  --metadata results/microswitches/metadata/structure_metadata_enriched.csv \
  --structures data/structures \
  --output results/microswitches/metadata/structure_download_manifest.csv

# Geometries
microswitches measure \
  --metadata results/microswitches/metadata/structure_metadata_enriched.csv \
  --structures data/structures \
  --config-dir config \
  --output results/microswitches/measurements \
  --workers 4

# Categories
microswitches classify \
  --measurements results/microswitches/measurements/microswitch_measurements.csv \
  --config-dir config \
  --output results/microswitches/classification

# Statistics and combinations
microswitches analyse \
  --categories results/microswitches/classification/microswitch_categories.csv \
  --config-dir config \
  --output results/microswitches/statistics

# Receptor-grouped machine learning
microswitches train-models \
  --categories results/microswitches/classification/microswitch_categories.csv \
  --config-dir config \
  --output results/microswitches/machine_learning

# Robustness
microswitches robustness \
  --categories results/microswitches/classification/microswitch_categories.csv \
  --config-dir config \
  --output results/microswitches/robustness

# Manuscript-ready figures
microswitches make-figures \
  --results results/microswitches \
  --config-dir config \
  --output figures/microswitches

# Coupling-specificity analysis only (after categories exist)
microswitches coupling-specificity \
  --categories results/microswitches/classification/microswitch_categories.csv \
  --config-dir config \
  --output results/microswitches/coupling_specificity \
  --figures figures/microswitches/coupling_specificity
```

## Repository layout

```text
src/gpcr_icl2/                   original ICL2 package
src/gpcr_icl2/microswitches/     new microswitch/ML package
src/microswitches/               `python -m microswitches` forwarder
config/                           definitions, thresholds and analysis settings
scripts/                          original scripts and compatibility workflows
data/seed/                        original seed PDB/state lists
data/processed/                   original manuscript tables
figures/                          original manuscript figures plus new outputs
tests/                            original and new tests
docs/                             audit, methods notes and implementation report
examples/                         small executable examples
```

## Locked installation

The one-command installer uses `environment-lock.yml`. Manual installation is
also supported:

```bash
conda env create -f environment-lock.yml
conda activate gpcr-microswitches
python -m pip install --no-deps --no-build-isolation -e .
pytest -q
```

DSSP/mkdssp remains optional and is needed only for the original DSSP concordance
analysis.

## Original ICL2 workflow

Reproduce the original figures from processed tables:

```bash
python scripts/make_figures.py --indir data/processed --outdir figures
```

Rebuild the original experimental dataset:

```bash
python scripts/run_full_pipeline.py --outdir data/processed --batch 25
```

The revision analyses remain available, including
within-receptor, per-receptor, sequence, G-protein contact, and DRY-geometry
scripts. See `docs/methods_notes.md` and the original scripts for their specific
interfaces.

## Validation and limitations

The new unit tests cover geometry, mapping, alternate conformations, alignment,
threshold behavior, reference assignment, deterministic representative
selection, receptor-grouped split leakage, and training-fold-only imputation.
Known active and inactive reference expectations are stored in
`tests/fixtures/reference_expectations.csv` and are evaluated after structural
classification.

A complete live run requires access to GPCRdb and RCSB and can take many hours.
Failed downloads and unavailable measurements are retained with explicit reasons;
structures are not silently discarded. The generated analyses test structural associations and predictive information.
They do not by themselves establish causal mechanisms or kinetic activation
pathways. The coupling-specificity extension specifically asks whether static,
primarily nucleotide-free endpoint structures retain transferable receptor-side
information; a null result is scientifically interpretable rather than a pipeline
failure.

For implementation details, see:

- `docs/microswitch_phase1_audit.md`
- `docs/full_implementation_report.md`
- `docs/COUPLING_SPECIFICITY_V0.4.0.md`
- `docs/CHANGELOG_V0.6.0.md`
- `docs/WHOLE_INTRACELLULAR_CAVITY_V0.6.0.md`

## Citation

Please cite the associated manuscript when using the original ICL2 analysis. A
`CITATION.cff` file is included for repository citation metadata.

### CPU performance mode

`run_everything.sh` automatically detects and uses all logical CPU threads. `--powerhouse` explicitly requests the same mode, while `--workers N` sets a manual limit. BLAS/OpenMP threads are capped at one per joblib worker to avoid nested oversubscription. Structural measurements and grouped machine learning are CPU-parallel; the pipeline does not currently use GPU acceleration.

To shorten a full run, add `--fast` (for example,
`./run_everything.sh --fast` or `microswitches run-all --fast`). Fast mode keeps
the full dataset, feature definitions, grouping, and validation design, but uses
fewer bootstrap resamples and fewer random-forest trees. Confidence intervals are
therefore less precise and a borderline automated interpretation can change.
Use the full mode for manuscript conclusions. `--quick` remains a smoke-test path
and is not for interpretation.

## Publication-grade coupling controls (v0.7.0)

After Stage 9 has produced `coupling_analysis_representatives.csv`, run:

```bash
./run_publication_controls.sh --quick
./run_publication_controls.sh --bootstrap-iterations 500 --permutations 1000
```

The extension tests core-cavity incremental value, missingness, complete cases, receptor family and generic-position sequence baselines, sequence-cluster transfer, activation matching/residualization, receptor weighting, publication grouping, construct subsets and grouped permutation nulls. See `docs/PUBLICATION_CONTROLS_V0.7.0.md`.

Cavity estimator parameter sensitivity is a separate, more expensive branch:

```bash
./run_cavity_sensitivity.sh
```

## Prospective validation and learning curves (v0.7.1)

The package now includes the two additional coupling controls used to distinguish
an information-limited endpoint record from an underpowered analysis:

1. **Receptor-level learning curves** — receptors, never individual rows, are
   repeatedly subsampled. The full adjusted structural model is compared with
   sequence-only and missingness-only baselines using the same nested,
   receptor-grouped elastic-net pipeline as the publication controls.
2. **Temporal holdout** — coupling representatives are reconstructed separately
   from structures deposited before and after each cutoff. Models are tuned only
   on the historical population and evaluated on later structures. The strict
   default (`--test-mode new`) removes every test receptor observed historically.

Run both analyses with the repository defaults:

```bash
./run_prospective_validation.sh
```

A shorter smoke test is available:

```bash
./run_prospective_validation.sh \
  --quick \
  --sizes 20,40,80,169 \
  --repeats 3 \
  --cutoffs 2023,2024 \
  --bootstrap-iterations 20 \
  --permutations 10
```

Equivalent direct CLI invocation:

```bash
microswitches prospective-validation \
  --analysis-frame results/microswitches/publication_controls/publication_control_analysis_frame.csv \
  --categories results/microswitches/classification/microswitch_categories.csv \
  --sizes 20,40,80,120,169 \
  --repeats 100 \
  --cutoffs 2023,2024 \
  --models SCVcoreE,sequence_only,missingness_only \
  --test-mode new \
  --bootstrap-iterations 1000 \
  --permutations 1000
```

Main outputs:

```text
results/microswitches/prospective_validation/
├── learning_curve/
│   ├── learning_curve_repeats.csv
│   ├── learning_curve_summary.csv
│   ├── learning_curve_receptor_samples.csv
│   └── learning_curve_saturation_exploratory.csv
└── temporal_holdout/
    ├── temporal_holdout_performance.csv
    ├── temporal_holdout_predictions.csv
    ├── temporal_holdout_bootstraps.csv
    ├── temporal_holdout_permutation_null.csv
    └── temporal_holdout_audit.csv

figures/microswitches/prospective_validation/
├── learning_curve/learning_curve.{pdf,svg,png}
└── temporal_holdout/temporal_holdout_new.{pdf,svg,png}
```

The saturation table fits `AUC(n) = asymptote - scale/sqrt(n)` only as an
**exploratory extrapolation**. Values at two or three times the present receptor
count are not observed data and should be labelled as model-based projections,
with uncertainty, rather than as demonstrated future performance.
