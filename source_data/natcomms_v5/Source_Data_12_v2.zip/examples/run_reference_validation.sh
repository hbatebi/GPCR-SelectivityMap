#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

microswitches run-all \
  --metadata data/processed/dataset_experimental.csv \
  --structures data/structures \
  --config-dir config \
  --output results/reference_validation \
  --figures figures/reference_validation \
  --workers "${WORKERS:-2}" \
  --limit 4 \
  --quick
