
## v0.6.1 Stage 9 recovery

Version 0.6.1 fixes a pandas dtype-dependent `KeyError: icl2_partial` in
the same-receptor coupling statistics. Existing v9 measurements and Stage 1–8
outputs do not need to be repeated. After installing the patch, run:

```bash
./resume_from_stage9.sh
```

This reruns coupling specificity and then generates the final figures, manifest,
and technical report. See `docs/CHANGELOG_V0.6.1.md`.

# One-command quick start

This archive contains the original ICL2 structurome workflow and the new
combinatorial GPCR microswitch and receptor-grouped machine-learning pipeline.

## Requirements

- Linux or macOS shell
- Conda or Miniforge/Miniconda
- Internet access to `gpcrdb.org`, `rcsb.org`, `conda-forge`, and PyPI
- At least 20 GB of free disk space for a full coordinate rebuild

## 1. Unpack

```bash
unzip gpcr-microswitches-complete-installable.zip
cd gpcr-icl2-microswitches-complete
```


## Updating an existing v8 or earlier folder

Apply the v9 overlay from inside the project folder. It overwrites program files
but preserves downloaded coordinates and prior results:

```bash
cd ~/Downloads/gpcr-icl2-microswitches-complete
unzip -o ../gpcr-microswitches-v9-whole-cavity-overlay.zip
conda activate gpcr-microswitches
python -m pip install --no-deps --no-build-isolation -e .
pytest -q
./run_preflight.sh
```

Version 0.6.0 uses measurement schema 5. Existing measurement tables are backed
up and recalculated because the new whole-cavity descriptors require coordinates;
cached mmCIF files are reused.

## 2. Install and run a smoke test

```bash
./install_and_run.sh --quick
```

The quick run installs a locked Python 3.12 environment, runs the tests, retains
known active/inactive reference structures, processes a small subset, trains
shorter grouped models, and writes outputs to:

The installer uses `conda run` rather than shell activation, so it works safely
from another active Conda environment and in non-interactive Bash shells.

```text
results/microswitches/
figures/microswitches/
```

Change the smoke-test size or worker count without editing code:

```bash
LIMIT=50 WORKERS=8 ./install_and_run.sh --quick
```

## 3. Run the complete structurome

```bash
./install_and_run.sh
```

Before the expensive full measurement stage, the runner now performs a
reference-only scientific preflight using 2RH1, 3EML, 3SN6, and 5G53. It checks
chain mapping, alignment quality, qualitative microswitch calls, and expected
TM6 separation. The full run stops early if these gates fail.

Run only this gate first:

```bash
conda activate gpcr-microswitches
./run_preflight.sh
```

The full run resumes from downloaded coordinates and compatible completed
measurements, so it is safe to rerun after an interruption. Version 0.6.0 adds a
voxel whole-cavity calculation and therefore upgrades the measurement schema to
5. Older measurement tables are moved to an `incompatible_cache_<timestamp>/`
backup and recomputed; downloaded coordinate files are still reused.

The final stages compare Gs, Gi/o, and Gq/11 using nested shared-activation,
intracellular-geometry, whole-cavity, and metadata models. They also run
training-fold-derived transducer anchors, same-receptor comparisons, broad
ligand-class transfer tests, and a separate exploratory arrestin branch.

## Install only

```bash
./install_and_run.sh --install-only
conda activate gpcr-microswitches
microswitches --help
```

## Re-run without rebuilding the environment

```bash
conda activate gpcr-microswitches
./run_everything.sh --quick
./run_everything.sh
```

Use `--skip-preflight` only when deliberately bypassing the scientific gate.

## Important operational notes

The first complete run downloads and measures more than one thousand structures
and can take many hours. GPCRdb or RCSB rate limits and local CPU/storage speed
will affect runtime. Do not delete `data/structures/` or
`results/microswitches/measurements/` if you want resume behavior.

## Use the whole CPU

The runner now detects all logical CPU threads automatically. Run the full analysis with:

```bash
conda activate gpcr-microswitches
./run_everything.sh
```

To state this explicitly, use `./run_everything.sh --powerhouse`. To leave the laptop more responsive, choose a smaller value, for example `./run_everything.sh --workers 6`. Machine-learning jobs already use all available grouped-CV workers; low-level BLAS threads are capped at one per process to prevent oversubscription. The current implementation is CPU-based and does not use the GPU.

## Run only the coupling-specificity analysis

After the complete categories table exists:

```bash
conda activate gpcr-microswitches
./run_coupling_specificity.sh
```

This does not repeat structural measurement. It reuses
`results/microswitches/classification/microswitch_categories.csv`.

## Publication controls after Stage 9

```bash
python -m pip install --no-deps --no-build-isolation -e .
./run_publication_controls.sh --quick
```

For the final manuscript run:

```bash
./run_publication_controls.sh --bootstrap-iterations 500 --permutations 1000
```
