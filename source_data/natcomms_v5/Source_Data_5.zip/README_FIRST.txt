Source Data S5

Fixed-feature temporal manifests, predictions, bootstraps and permutation nulls.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
