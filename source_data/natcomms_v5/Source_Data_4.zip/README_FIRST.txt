Source Data S4

Matched sequence/structure predictions, paired bootstraps, coefficients and convergence/cross-validation audits.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
