"""Captured structural class versus kinetic G protein selectivity (Masuho et al. 2023, Table S1).
Implements masuho_analysis_plan.md (31 Oct 2026). Deviation: the Q2 null permutes whole kinetic
profiles between receptors (one profile per receptor), as in the existing functional-concordance
analysis, instead of the within-receptor label permutation named in the plan.
Usage: python -I run_kinetic.py <mmc2.xlsx> <structure_inventory.csv> <S11 predictions tsv> <S11 cluster tsv> <outdir>
"""
import sys, os, json
import numpy as np, pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score

XL, INV, PRED, CLU, OUT = sys.argv[1:6]
os.makedirs(OUT, exist_ok=True)
SEED = 20261031
B, NPERM = 2000, 2000

GENE2ENTRY = {'HTR1A':'5ht1a','HTR1B':'5ht1b','HTR1D':'5ht1d','HTR1E':'5ht1e','HTR1F':'5ht1f','HTR2A':'5ht2a','HTR2B':'5ht2b','HTR2C':'5ht2c',
'HTR4':'5ht4r','HTR5A':'5ht5a','HTR6':'5ht6r','HTR7':'5ht7r','CHRM1':'acm1','CHRM2':'acm2','CHRM3':'acm3','CHRM4':'acm4','CHRM5':'acm5',
'ADRA1A':'ada1a','ADRA1B':'ada1b','ADRA1D':'ada1d','ADRA2A':'ada2a','ADRA2B':'ada2b','ADRA2C':'ada2c','ADRB1':'adrb1','ADRB2':'adrb2','ADRB3':'adrb3',
'DRD1':'drd1','DRD2':'drd2','DRD3':'drd3','DRD4':'drd4','DRD5':'drd5','HRH1':'hrh1','HRH2':'hrh2','HRH3':'hrh3','MTNR1A':'mtr1a','MTNR1B':'mtr1b',
'ADORA1':'aa1r','ADORA2A':'aa2ar','ADORA2B':'aa2br','ADORA3':'aa3r','GALR1':'galr1','GALR2':'galr2','GALR3':'galr3','OPRM1':'oprm','OPRD1':'oprd',
'OPRK1':'oprk','OPRL1':'oprx','EDNRA':'ednra','EDNRB':'ednrb','GRPR':'grpr','BRS3':'brs3','APLNR':'apj','AVPR1A':'v1ar','AVPR1B':'v1br','AVPR2':'v2r',
'BDKRB2':'bkrb2','MC1R':'mshr','MC3R':'mc3r','MC4R':'mc4r','MC5R':'mc5r','NPY1R':'npy1r','NPY2R':'npy2r','NPY4R':'npy4r','NPY5R':'npy5r',
'TACR1':'nk1r','TACR2':'nk2r','TACR3':'nk3r','NTSR1':'ntr1','HCRTR1':'ox1r','HCRTR2':'ox2r','OXTR':'oxyr','CCKAR':'cckar','CCKBR':'gasr',
'NPFFR1':'npff1','SSTR1':'ssr1','SSTR2':'ssr2','SSTR3':'ssr3','SSTR4':'ssr4','SSTR5':'ssr5','KISS1R':'kissr','CXCR4':'cxcr4','PTGER1':'pe2r1',
'PTGER2':'pe2r2','PTGER3':'pe2r3','PTGER4':'pe2r4','PTGDR':'pd2r','PTGDR2':'pd2r2','TBXA2R':'ta2r','CNR1':'cnr1','GPBAR1':'gpbar','SUCNR1':'sucr1',
'OXGR1':'oxgr1','GPR52':'gpr52'}
FAM = ['Gi/o', 'Gq/11', 'Gs']

# ---------- kinetics ----------
raw = pd.read_excel(XL, sheet_name='Raw Data', header=None, skiprows=3)
raw = raw.iloc[:, :23]
raw.columns = ['name', 'gene', 'cls'] + [f'amp_{g}_{s}' for g in ['io', 'q', '15', 's', '1213'] for s in ['m', 'e']] + \
              [f'rate_{g}_{s}' for g in ['io', 'q', '15', 's', '1213'] for s in ['m', 'e']]
raw = raw[raw.gene.isin(GENE2ENTRY.keys())].copy()
dup = raw[raw.gene.duplicated(keep=False)][['name', 'gene']]
raw = raw.drop_duplicates('gene', keep='first')          # duplicated clones: first listed row
raw['receptor_name'] = raw.gene.map(GENE2ENTRY) + '_human'
for c in [c for c in raw.columns if c.startswith(('rate_', 'amp_'))]:
    raw[c] = pd.to_numeric(raw[c], errors='coerce').fillna(0.0)
def profile(df, g15=False):
    q = np.maximum(df.rate_q_m, df.rate_15_m) if g15 else df.rate_q_m
    return pd.DataFrame({'Gi/o': df.rate_io_m.values, 'Gq/11': q.values, 'Gs': df.rate_s_m.values}, index=df.receptor_name.values)

hm = pd.read_excel(XL, sheet_name='Heatmap', header=None, skiprows=2)
hm = hm.iloc[:, [1, 13, 14]]; hm.columns = ['gene', 'author_primary', 'author_rank']
hm = hm[hm.gene.isin(GENE2ENTRY.keys())].drop_duplicates('gene')

# ---------- units ----------
inv = pd.read_csv(INV)[['pdb_id', 'receptor_name', 'transducer_family']]
units = inv[inv.receptor_name.isin(raw.receptor_name)].copy()
rng = np.random.default_rng(SEED)

def boot_ci(values_by_rec, stat, n=B):
    recs = list(values_by_rec.keys()); out = []
    for _ in range(n):
        pick = rng.choice(len(recs), len(recs))
        out.append(stat([values_by_rec[recs[i]] for i in pick]))
    return np.percentile(out, [2.5, 97.5])

# ---------- Q1 ----------
q1rows, q1units = [], []
for label, g15 in [('primary (Gq/11 = Gaq)', False), ('sensitivity (Gq/11 = max(Gaq, Ga15))', True)]:
    P = profile(raw, g15)
    u = units.copy()
    u['preferred'] = [P.loc[r].idxmax() if P.loc[r].max() > 0 else 'none' for r in u.receptor_name]
    u['captured_rate'] = [P.loc[r, f] for r, f in zip(u.receptor_name, u.transducer_family)]
    u['concordant'] = (u.transducer_family == u.preferred).astype(int)
    u['captured_inactive'] = (u.captured_rate == 0).astype(int)
    u['n_activated'] = [int((P.loc[r] > 0).sum()) for r in u.receptor_name]
    byrec = {r: g for r, g in u.groupby('receptor_name')}
    def frac(col): return lambda gs: np.concatenate([g[col].values for g in gs]).mean()
    conc = u.concordant.mean(); ci = boot_ci(byrec, frac('concordant'))
    inact = u.captured_inactive.mean(); ci2 = boot_ci(byrec, frac('captured_inactive'))
    rec = u.groupby('receptor_name').apply(lambda g: int((g.transducer_family == g.preferred.iloc[0]).any()))
    q1rows.append(dict(analysis=label, n_units=len(u), n_receptors=u.receptor_name.nunique(),
                       unit_concordance=conc, unit_ci_low=ci[0], unit_ci_high=ci[1],
                       captured_inactive=inact, inactive_ci_low=ci2[0], inactive_ci_high=ci2[1],
                       receptor_preferred_among_captured=rec.mean(), n_receptor_no_activation=int((u.groupby('receptor_name').preferred.first() == 'none').sum())))
    if not g15:
        q1units = u.copy()
        bycls = u.groupby('transducer_family').agg(n=('concordant', 'size'), concordance=('concordant', 'mean'), inactive=('captured_inactive', 'mean'))
q1 = pd.DataFrame(q1rows); q1.to_csv(f'{OUT}/Q1_concordance.tsv', sep='\t', index=False)
bycls.to_csv(f'{OUT}/Q1_by_captured_class.tsv', sep='\t')
q1units = q1units.merge(raw[['receptor_name', 'gene']], on='receptor_name').merge(hm, on='gene', how='left')
q1units.to_csv(f'{OUT}/Q1_units.tsv', sep='\t', index=False)
cross = q1units.drop_duplicates('receptor_name')
cross_ok = (cross.author_primary.isin(FAM + ['Gq'])).sum()

# ---------- Q2 ----------
pred = pd.read_csv(PRED, sep='\t')
P = profile(raw, False)
vals = ['receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold', 'sequence_cluster_40_grouped_5fold', 'sequence_cluster_30_grouped_5fold']
from scipy.stats import rankdata
def _rowcorr(a, b):
    a = a - a.mean(1, keepdims=True); b = b - b.mean(1, keepdims=True)
    den = np.sqrt((a * a).sum(1) * (b * b).sum(1))
    return np.where(den > 0, (a * b).sum(1) / np.where(den > 0, den, 1), np.nan)
def q2_stats(d, prof):
    rates = prof.loc[d.receptor_name].values
    probs = d[[f'probability_{f}' for f in FAM]].values
    keep = np.ptp(rates, axis=1) > 0
    rho = _rowcorr(rankdata(probs[keep], axis=1), rankdata(rates[keep], axis=1))
    aucs = []
    for k in range(3):
        y = (rates[:, k] > 0).astype(int)
        if 0 < y.sum() < len(y): aucs.append(roc_auc_score(y, probs[:, k]))
    return np.nanmean(rho), np.mean(aucs)
q2rows = []
for exp in ['full_sequence', 'endpoint_geometry', 'global_identity_knn']:
    for val in vals:
        d = pred[(pred.experiment == exp) & (pred.validation == val)].merge(units, on=['pdb_id', 'receptor_name', 'transducer_family'])
        rho, auc = q2_stats(d, P)
        recs = d.receptor_name.unique(); ix = {r: np.where(d.receptor_name.values == r)[0] for r in recs}
        bs = []
        for _ in range(B):
            pick = rng.choice(recs, len(recs))
            bs.append(q2_stats(d.iloc[np.concatenate([ix[r] for r in pick])], P))
        bs = np.array(bs)
        null = []
        for _ in range(NPERM):
            perm = P.loc[recs].copy(); perm.index = rng.permutation(recs)
            null.append(q2_stats(d, perm))
        null = np.array(null)
        q2rows.append(dict(model=exp, validation=val, n_units=len(d), n_receptors=len(recs),
                           mean_spearman=rho, rho_ci_low=np.percentile(bs[:, 0], 2.5), rho_ci_high=np.percentile(bs[:, 0], 97.5),
                           rho_null_mean=null[:, 0].mean(), rho_p_one_sided=(1 + (null[:, 0] >= rho).sum()) / (1 + NPERM),
                           family_mean_auc=auc, auc_ci_low=np.percentile(bs[:, 1], 2.5), auc_ci_high=np.percentile(bs[:, 1], 97.5),
                           auc_null_mean=null[:, 1].mean(), auc_p_one_sided=(1 + (null[:, 1] >= auc).sum()) / (1 + NPERM)))
q2 = pd.DataFrame(q2rows); q2.to_csv(f'{OUT}/Q2_graded_concordance.tsv', sep='\t', index=False)

# ---------- Q3 ----------
clu = pd.read_csv(CLU, sep='\t').set_index('receptor_name')
recs = [r for r in units.receptor_name.unique() if r in clu.index and P.loc[r].max() > 0]
V = P.loc[recs].values; V = V / np.linalg.norm(V, axis=1, keepdims=True)
S = V @ V.T; iu = np.triu_indices(len(recs), 1); sim = S[iu]
q3rows = []
for thr in ['sequence_cluster_50', 'sequence_cluster_40', 'sequence_cluster_30']:
    lab = np.asarray(clu.loc[recs, thr].astype(str).tolist(), dtype=object)
    same = (lab[:, None] == lab[None, :])[iu]
    obs = sim[same].mean() - sim[~same].mean()
    null = []
    for _ in range(NPERM):
        pl = rng.permutation(lab); sm = (pl[:, None] == pl[None, :])[iu]
        null.append(sim[sm].mean() - sim[~sm].mean())
    null = np.array(null)
    q3rows.append(dict(threshold=thr, n_receptors=len(recs), n_same_pairs=int(same.sum()), n_diff_pairs=int((~same).sum()),
                       mean_sim_same=sim[same].mean(), mean_sim_diff=sim[~same].mean(), difference=obs,
                       null_mean=null.mean(), p_one_sided=(1 + (null >= obs).sum()) / (1 + NPERM)))
q3 = pd.DataFrame(q3rows); q3.to_csv(f'{OUT}/Q3_profile_locality.tsv', sep='\t', index=False)

# ---------- descriptive: multi-class receptors ----------
mc = q1units.groupby('receptor_name').filter(lambda g: g.transducer_family.nunique() > 1)
desc = mc.groupby('receptor_name').agg(gene=('gene', 'first'), captured=('transducer_family', lambda s: '; '.join(sorted(set(s)))),
                                       preferred=('preferred', 'first'), author_rank=('author_rank', 'first'))
desc = desc.join(P.loc[desc.index].round(3).add_prefix('rate_'))
desc.to_csv(f'{OUT}/descriptive_multiclass_receptors.tsv', sep='\t')

json.dump(dict(seed=SEED, bootstraps=B, permutations=NPERM, duplicated_genes=dup.to_dict('records'),
               author_primary_in_three_families=int(cross_ok), receptors=int(units.receptor_name.nunique())),
          open(f'{OUT}/run_info.json', 'w'), indent=1, default=str)
pd.set_option('display.width', 250)
print(q1.round(3).to_string()); print(bycls.round(3)); print(q2.round(3).to_string()); print(q3.round(3).to_string()); print(desc.to_string())
print('duplicates:', dup.to_dict('records'))
