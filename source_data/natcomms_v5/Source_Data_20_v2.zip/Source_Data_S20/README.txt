Source Data S20 | Comparison with measured G protein activation kinetics

The analysis plan (masuho_analysis_plan.md) was fixed and archived on 31 October 2026, before any
kinetic value was inspected. One deviation is recorded: the null for the graded-concordance test
permutes whole kinetic profiles between receptors, because each receptor has a single profile and
the within-receptor permutation named in the plan is therefore not defined. The analysis of the
families other than the captured one (run_noncaptured.py) was specified after the three planned
questions and is reported in the manuscript as post hoc.

INPUTS (not redistributed here)
  Masuho et al., Cell Reports 42 (2023) 113173, Table S1 (supplementary file mmc2.xlsx), sheet
  "Raw Data": activation rates for GaoA, Gaq, Ga15, Gas and Ga13.
  Source Data S11: frozen out-of-fold predictions and sequence-identity cluster assignments.
  structure_inventory.csv: the 207 receptor-transducer units.

SCRIPTS
  run_kinetic.py        Q1 concordance, Q2 graded concordance, Q3 profile locality, descriptive table
  run_noncaptured.py    Q2b non-captured couplings and the pairwise accuracy
  fig_kinetic.py        draws main manuscript Figure 2 from the output tables

OUTPUTS
  Q1_concordance.tsv, Q1_by_captured_class.tsv, Q1_units.tsv
  Q2_graded_concordance.tsv
  Q2b_noncaptured_kinetic.tsv
  Q2c_readout_control.tsv            Hauser binary map vs kinetics on the identical 94 units
  Q3_profile_locality.tsv
  descriptive_multiclass_receptors.tsv
  gene_to_receptor_mapping.tsv       HGNC symbol to UniProt entry name, with archive membership
  run_info.json, run_info_q2b.json   seed, resampling counts, duplicated source rows

NOTES
  Random seed 20261031; 2,000 bootstrap resamples and 2,000 permutations throughout.
  HTR7 appears twice in the source table (5-HT7A and 5-HT7B); the first listed row is used.
  No model was refitted at any point; all predictions are the archived out-of-fold values.
