# Analysis plan: captured structural class versus kinetic G protein selectivity

Fixed on 31 October 2026, before any kinetic value from Masuho et al. (2023, Cell Reports 42, 113173, Table S1) was opened. Anything not listed here will be reported as exploratory.

## Data
- Structural units: the 207 receptor–transducer units of the manuscript. Analysis set: human class A receptors also profiled by Masuho et al., matched by gene symbol to UniProt entry name. The overlap count, made from the receptor list in the Key Resources table, is 94 units from 77 receptors (43 Gi/o, 26 Gs, 25 Gq/11), with 14 receptors resolved with more than one captured class. Non-human orthologues are excluded, as in the Hauser et al. (2022) analysis.
- Kinetics: G protein activation rates (or the reported rank order) from Table S1. Family mapping: Gi/o = GαoA; Gs = Gαs; Gq/11 = Gαq. Gα15 enters only a sensitivity analysis (Gq/11 = the faster of Gαq and Gα15). Gα13 is excluded because no captured G12/13 class is modelled.
- Kinetically preferred family: the family with the fastest activation among the three, following the authors' rank order where the table reports one.

## Primary questions
1. Concordance of the captured class with the kinetically preferred family, as the fraction of units and of receptors, with receptor-clustered bootstrap 95% CIs. The fraction of captured classes that show no detectable activation in the kinetic assay is reported alongside.
2. Graded concordance of the frozen out-of-fold class probabilities (full sequence, endpoint geometry, global sequence-identity nearest neighbours; Source Data S11) with the kinetic profile across the three families, as the mean within-unit Spearman correlation and the family-mean ROC AUC for activated versus non-activated families. Validation schemes: receptor-grouped, and 50%, 40% and 30% sequence-identity clusters. Inference uses receptor-clustered bootstrap and within-receptor label permutation.
3. Evolutionary locality of kinetic selectivity: similarity of the three-family kinetic profiles (cosine of normalised rates) for receptor pairs in the same versus different sequence-identity clusters at 50%, 40% and 30% (cluster assignments from the publication controls), with a receptor-level permutation null.

## Descriptive only
- The 14 receptors resolved with more than one captured class: the kinetic rank order of their captured families.

## Reporting
All three primary results are reported whatever their direction. No model is refitted, and no analysis is added after the kinetic values are opened unless it is labelled exploratory.
