"""Figure 2: captured structural class and measured G protein activation kinetics.
Style matched to Figure 5 of the manuscript. Usage: python -I fig_kinetic.py <resultsdir> <outdir>"""
import sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

RES, OUT = sys.argv[1], sys.argv[2]
plt.rcParams.update({
    "font.family": "Liberation Sans", "font.size": 8.5, "axes.labelsize": 9, "axes.titlesize": 9.5,
    "xtick.labelsize": 8.5, "ytick.labelsize": 8.5, "legend.fontsize": 8.2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.9,
    "axes.edgecolor": "#212529", "xtick.color": "#212529", "ytick.color": "#212529",
    "axes.labelcolor": "#212529", "text.color": "#212529",
})
CLS = {"Gs": "#E8871E", "Gi/o": "#1B998B", "Gq/11": "#6F44A8"}
GRID, MUTED = "#DFE3E8", "#495057"
rng = np.random.default_rng(7)

u = pd.read_csv(f"{RES}/Q1_units.tsv", sep="\t")
q2b = pd.read_csv(f"{RES}/Q2b_noncaptured_kinetic.tsv", sep="\t")
q2c = pd.read_csv(f"{RES}/Q2c_readout_control.tsv", sep="\t")

fig = plt.figure(figsize=(7.0, 2.95))
gs = fig.add_gridspec(1, 3, width_ratios=[0.95, 1.3, 0.95], left=0.118, right=0.985,
                      bottom=0.215, top=0.80, wspace=0.42)

def panel(ax, letter):
    ax.text(-0.30, 1.26, letter, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top")

# ---------- A: captured class versus kinetically preferred family
ax = fig.add_subplot(gs[0, 0]); panel(ax, "A")
order = ["Gi/o", "Gq/11", "Gs"]
cen, lo, hi, ns = [], [], [], []
for c in order:
    v = u[u.transducer_family == c].copy()
    recs = v.receptor_name.unique()
    ix = {r: v.index[v.receptor_name == r] for r in recs}
    bs = [v.loc[np.concatenate([ix[r] for r in rng.choice(recs, len(recs))]), "concordant"].mean()
          for _ in range(2000)]
    cen.append(v.concordant.mean()); lo.append(np.percentile(bs, 2.5)); hi.append(np.percentile(bs, 97.5))
    ns.append(len(v))
x = np.arange(3)
ax.bar(x, cen, width=0.58, color=[CLS[c] for c in order], edgecolor="white", lw=0.6, zorder=2)
ax.errorbar(x, cen, yerr=[np.array(cen) - lo, np.array(hi) - np.array(cen)], fmt="none",
            ecolor="#212529", elinewidth=1.0, capsize=2.5, zorder=3)
ax.axhline(1 / 3, color=MUTED, ls=(0, (3, 3)), lw=0.9)
ax.text(2.45, 0.345, "chance", va="bottom", ha="right", fontsize=7.8, color=MUTED)
for i, (c, n) in enumerate(zip(cen, ns)):
    ax.text(i, 0.05, f"n = {n}", ha="center", va="bottom", fontsize=7.6, color="white", fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels(order)
ax.set_xlabel("Captured G protein class"); ax.set_ylabel("Captured class is\nthe fastest family")
ax.set_ylim(0, 1.02); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_title("Captured vs fastest family", pad=8)
ax.yaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)

# ---------- B: non-captured couplings across evolutionary separation
ax = fig.add_subplot(gs[0, 1]); panel(ax, "B")
vals = ["receptor_grouped_5fold", "sequence_cluster_50_grouped_5fold",
        "sequence_cluster_40_grouped_5fold", "sequence_cluster_30_grouped_5fold"]
labs = ["Receptor-\ngrouped", "50%", "40%", "30%"]
models = [("full_sequence", "Full sequence", "#6F44A8", "-"),
          ("endpoint_geometry", "Endpoint geometry", "#1B998B", "-"),
          ("global_identity_knn", "Global identity kNN", "#8D99AE", "--")]
xs = np.arange(4)
for key, lab, col, ls in models:
    s = q2b[q2b.model == key].set_index("validation").loc[vals]
    ax.errorbar(xs, s.family_mean_auc,
                yerr=[s.family_mean_auc - s.auc_ci_low, s.auc_ci_high - s.family_mean_auc],
                fmt="none", ecolor=col, elinewidth=1.0, capsize=0, alpha=0.9)
    ax.plot(xs, s.family_mean_auc, color=col, ls=ls, lw=1.5, marker="o", ms=4.2,
            mec="white", mew=0.5, label=lab)
ax.axhline(0.5, color=MUTED, ls=(0, (3, 3)), lw=0.9)
ax.text(-0.38, 0.505, "chance", va="bottom", ha="left", fontsize=7.8, color=MUTED)
ax.set_xticks(xs); ax.set_xticklabels(labs)
ax.set_xlabel("Sequence-identity separation between folds")
ax.set_ylabel("Mean family-specific ROC AUC\n(non-captured families)")
ax.set_xlim(-0.45, 3.45); ax.set_ylim(0.28, 0.92)
ax.set_title("Non-captured kinetic couplings", pad=8)
ax.yaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)
ax.legend(frameon=False, loc="lower left", handlelength=1.6, borderpad=0.1, labelspacing=0.25)

# ---------- C: functional readout control on the same units
ax = fig.add_subplot(gs[0, 2]); panel(ax, "C")
sub = q2c[q2c.functional_readout != "Hauser binary map (all mapped)"]
mods = [("endpoint_geometry", "Endpoint\ngeometry"), ("full_sequence", "Full\nsequence")]
w = 0.33
for j, (read, col, hatch) in enumerate([("Hauser binary map (kinetic subset)", "#ADB5BD", None),
                                        ("Masuho kinetics (same units)", "#1B998B", None)]):
    v = [sub[(sub.functional_readout == read) & (sub.model == m)].family_mean_auc.iloc[0] for m, _ in mods]
    ax.bar(np.arange(2) + (j - 0.5) * w, v, width=w, color=col, edgecolor="white", lw=0.6,
           label="Binary coupling map" if j == 0 else "Activation kinetics", zorder=2)
    for i, val in enumerate(v):
        ax.text(i + (j - 0.5) * w, val + 0.012, f"{val:.2f}", ha="center", fontsize=7.4, color=MUTED)
ax.axhline(0.5, color=MUTED, ls=(0, (3, 3)), lw=0.9)
ax.set_xticks(np.arange(2)); ax.set_xticklabels([l for _, l in mods])
ax.set_ylabel("Mean family-specific ROC AUC")
ax.set_ylim(0.4, 0.82); ax.set_yticks([0.4, 0.5, 0.6, 0.7, 0.8])
ax.set_title("Same units, two readouts", pad=8)
ax.yaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)
ax.legend(frameon=False, loc="upper left", handlelength=1.1, borderpad=0.1, labelspacing=0.25, fontsize=7.6)

fig.savefig(f"{OUT}/Figure_6.tif", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
fig.savefig(f"{OUT}/Figure_6_preview.png", dpi=170)
print("written")
