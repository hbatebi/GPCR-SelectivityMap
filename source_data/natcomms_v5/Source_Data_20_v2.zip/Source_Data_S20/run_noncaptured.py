"""Q2b: do the frozen model scores predict kinetic activation of the families OTHER than the
captured one? Same design as the existing Hauser-map analysis (manuscript Figure 5D), with
measured activation kinetics (Masuho et al. 2023, Table S1) in place of the binary coupling map.
Added after Q1-Q3 because Q2 as specified cannot separate captured-class recovery from genuine
information about other families; reported as a post hoc analysis of the pre-specified dataset.
Usage: python -I run_noncaptured.py <mmc2.xlsx> <inventory.csv> <S11 preds> <outdir>
"""
import sys, os, json
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score

XL, INV, PRED, OUT = sys.argv[1:5]
os.makedirs(OUT, exist_ok=True)
SEED, B, NPERM = 20261031, 2000, 2000
rng = np.random.default_rng(SEED)

GENE2ENTRY = {'HTR1A':'5ht1a','HTR1B':'5ht1b','HTR1D':'5ht1d','HTR1E':'5ht1e','HTR1F':'5ht1f','HTR2A':'5ht2a','HTR2B':'5ht2b','HTR2C':'5ht2c',
'HTR4':'5ht4r','HTR5A':'5ht5a','HTR6':'5ht6r','HTR7':'5ht7r','CHRM1':'acm1','CHRM2':'acm2','CHRM3':'acm3','CHRM4':'acm4','CHRM5':'acm5',
'ADRA1A':'ada1a','ADRA1B':'ada1b','ADRA1D':'ada1d','ADRA2A':'ada2a','ADRA2B':'ada2b','ADRA2C':'ada2c','ADRB1':'adrb1','ADRB2':'adrb2','ADRB3':'adrb3',
'DRD1':'drd1','DRD2':'drd2','DRD3':'drd3','DRD4':'drd4','DRD5':'drd5','HRH1':'hrh1','HRH2':'hrh2','HRH3':'hrh3','MTNR1A':'mtr1a','MTNR1B':'mtr1b',
'ADORA1':'aa1r','ADORA2A':'aa2ar','ADORA2B':'aa2br','ADORA3':'aa3r','GALR1':'galr1','GALR2':'galr2','GALR3':'galr3','OPRM1':'oprm','OPRD1':'oprd',
'OPRK1':'oprk','OPRL1':'oprx','EDNRA':'ednra','EDNRB':'ednrb','GRPR':'grpr','BRS3':'brs3','APLNR':'apj','AVPR1A':'v1ar','AVPR1B':'v1br','AVPR2':'v2r',
'BDKRB2':'bkrb2','MC1R':'mshr','MC3R':'mc3r','MC4R':'mc4r','MC5R':'mc5r','NPY1R':'npy1r','NPY2R':'npy2r','NPY4R':'npy4r','NPY5R':'npy5r',
'TACR1':'nk1r','TACR2':'nk2r','TACR3':'nk3r','NTSR1':'ntr1','HCRTR1':'ox1r','HCRTR2':'ox2r','OXTR':'oxyr','CCKAR':'cckar','CCKBR':'gasr',
'NPFFR1':'npff1','SSTR1':'ssr1','SSTR2':'ssr2','SSTR3':'ssr3','SSTR4':'ssr4','SSTR5':'ssr5','KISS1R':'kissr','CXCR4':'cxcr4','PTGER1':'pe2r1',
'PTGER2':'pe2r2','PTGER3':'pe2r3','PTGER4':'pe2r4','PTGDR':'pd2r','PTGDR2':'pd2r2','TBXA2R':'ta2r','CNR1':'cnr1','GPBAR1':'gpbar','SUCNR1':'sucr1',
'OXGR1':'oxgr1','GPR52':'gpr52'}
FAM = ['Gi/o', 'Gq/11', 'Gs']

raw = pd.read_excel(XL, sheet_name='Raw Data', header=None, skiprows=3).iloc[:, :23]
raw.columns = ['name', 'gene', 'cls'] + [f'amp_{g}_{s}' for g in ['io','q','15','s','1213'] for s in ['m','e']] + \
              [f'rate_{g}_{s}' for g in ['io','q','15','s','1213'] for s in ['m','e']]
raw = raw[raw.gene.isin(GENE2ENTRY)].drop_duplicates('gene', keep='first').copy()
raw['receptor_name'] = raw.gene.map(GENE2ENTRY) + '_human'
for c in [c for c in raw.columns if c.startswith('rate_')]:
    raw[c] = pd.to_numeric(raw[c], errors='coerce').fillna(0.0)
P = pd.DataFrame({'Gi/o': raw.rate_io_m.values, 'Gq/11': raw.rate_q_m.values, 'Gs': raw.rate_s_m.values},
                 index=raw.receptor_name.values)

inv = pd.read_csv(INV)[['pdb_id', 'receptor_name', 'transducer_family']]
units = inv[inv.receptor_name.isin(P.index)].copy()
pred = pd.read_csv(PRED, sep='\t')

FI = {f: i for i, f in enumerate(FAM)}

def build(d):
    """Fixed long-form layout: two non-captured families per unit."""
    rec, fam, sc, grp = [], [], [], []
    for g, (_, r) in enumerate(d.iterrows()):
        for f in FAM:
            if f == r.transducer_family:
                continue
            rec.append(r.receptor_name); fam.append(FI[f]); sc.append(r[f'probability_{f}']); grp.append(g)
    return np.array(rec), np.array(fam), np.array(sc, float), np.array(grp)

def stats_arr(rates, score, fam, grp, rows=None):
    if rows is not None:
        rates, score, fam, grp = rates[rows], score[rows], fam[rows], grp[rows]
    aucs = []
    for k in range(3):
        m = fam == k
        y = (rates[m] > 0).astype(int)
        if 0 < y.sum() < len(y):
            aucs.append(roc_auc_score(y, score[m]))
    # pairwise within unit: higher score on the faster of the two non-captured families
    order = np.argsort(grp, kind='stable')
    r2, s2, g2 = rates[order], score[order], grp[order]
    first = np.r_[True, g2[1:] != g2[:-1]]
    i0 = np.where(first)[0]
    i0 = i0[(i0 + 1 < len(g2))]
    i0 = i0[g2[i0] == g2[i0 + 1]]
    i1 = i0 + 1
    diff = r2[i0] != r2[i1]
    acc = ((s2[i0] > s2[i1]) == (r2[i0] > r2[i1]))[diff]
    return (np.mean(aucs) if aucs else np.nan), (acc.mean() if acc.size else np.nan), int(acc.size)

out = []
vals = ['receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold',
        'sequence_cluster_40_grouped_5fold', 'sequence_cluster_30_grouped_5fold']
for exp in ['full_sequence', 'endpoint_geometry', 'global_identity_knn']:
    for val in vals:
        d = pred[(pred.experiment == exp) & (pred.validation == val)].merge(
            units, on=['pdb_id', 'receptor_name', 'transducer_family'])
        rec, fam, score, grp = build(d)
        recs = pd.unique(rec)
        pos = {r: i for i, r in enumerate(recs)}
        rec_i = np.array([pos[r] for r in rec])
        M = P.loc[recs].values                      # receptors x families, kinetic rates
        rates = M[rec_i, fam]
        auc, acc, nacc = stats_arr(rates, score, fam, grp)
        ix = {i: np.where(rec_i == i)[0] for i in range(len(recs))}
        bs = []
        for _ in range(B):
            pick = rng.choice(len(recs), len(recs))
            rows = np.concatenate([ix[i] for i in pick])
            # renumber groups so repeated receptors keep distinct units
            gg = grp[rows] + 1000000 * np.repeat(np.arange(len(pick)), [len(ix[i]) for i in pick])
            bs.append(stats_arr(rates[rows], score[rows], fam[rows], gg)[:2])
        bs = np.array(bs, float)
        null = []
        for _ in range(NPERM):
            perm = rng.permutation(len(recs))
            null.append(stats_arr(M[perm][rec_i, fam], score, fam, grp)[:2])
        null = np.array(null, float)
        out.append(dict(model=exp, validation=val, n_units=d.pdb_id.nunique(), n_receptors=len(recs),
                        n_pairs=len(rec), family_mean_auc=auc,
                        auc_ci_low=np.nanpercentile(bs[:, 0], 2.5), auc_ci_high=np.nanpercentile(bs[:, 0], 97.5),
                        auc_null_mean=np.nanmean(null[:, 0]),
                        auc_p_one_sided=(1 + np.nansum(null[:, 0] >= auc)) / (1 + NPERM),
                        pairwise_acc=acc, n_pairwise=nacc,
                        acc_ci_low=np.nanpercentile(bs[:, 1], 2.5), acc_ci_high=np.nanpercentile(bs[:, 1], 97.5),
                        acc_p_one_sided=(1 + np.nansum(null[:, 1] >= acc)) / (1 + NPERM)))
        print(out[-1], flush=True)

df = pd.DataFrame(out)
df.to_csv(f'{OUT}/Q2b_noncaptured_kinetic.tsv', sep='\t', index=False)
json.dump(dict(seed=SEED, bootstraps=B, permutations=NPERM), open(f'{OUT}/run_info_q2b.json', 'w'), indent=1)
pd.set_option('display.width', 250)
print(df.round(3).to_string())
