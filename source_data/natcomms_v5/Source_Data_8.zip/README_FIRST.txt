Source Data S8

Repeated learning-curve checkpoints, sampling plan, summaries and terminal-gain estimates.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
