Source Data S24
Comparison of structural and sequence representations, and the nesting diagnostic.

refit_auc.tsv, refit_paired_differences.tsv, refit.log
    Sequence-only, strict-coordinate-geometry and combined models refitted from the
    per-structure measurement table, which contains neither the activation-consensus
    score nor its completeness count, so all three are free of functional annotation by
    construction. Archived outer folds, nested L2 logistic regression, inner CV grouped
    on the same identity clusters as the outer split. Paired differences use a
    receptor-clustered bootstrap over 2,000 resamples on identical held-out observations.

archive_wide_auc_table_S18.tsv
    Archived, reimplemented, coordinate-only, strict-coordinate-only and
    acquisition-only macro ROC AUC at each validation level (Source Data S18).

archived_paired_model_differences_S11.tsv
    Archived paired model differences with receptor-clustered intervals (Source Data S11).

diag.py, diag2.py, diag3.py
    The nesting diagnostic. diag.py checks that the aligned positions, the encoding
    source, the fold assignments and the held-out observations are identical between the
    archived sequence model and the refit, and quantifies missing residue cells. diag2.py
    excludes missing-residue handling as a cause. diag3.py identifies the cause: the
    archive selects the regularisation strength under inner cross-validation grouped on
    receptor even when the outer split is identity-clustered. Reverting only that
    reproduces the archived sequence values, 0.639 against 0.638 at the 50% threshold and
    0.609 against 0.612 at 40%. Both nestings are reported in the manuscript.

Seed 20261031 throughout.
