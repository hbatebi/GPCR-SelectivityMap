"""Clean refit of the incremental-information test.
Models are built only from the archived per-structure measurement table, which does not
contain activation_consensus_score or activation_consensus_feature_count, so every model
here is free of the two functional descriptors by construction.
Specification follows Source Data S18 script 02 exactly: nested L2 logistic regression,
median imputation and standardisation of numerics, most-frequent imputation and one-hot
encoding of categoricals, C swept over 11 log-spaced values by grouped inner CV on
negative log loss, everything fitted inside training folds only, archived outer folds.
Usage: python -I refit_combined.py <measurements csv> <S11 dir> <outdir>
"""
import sys, os, re, warnings
import numpy as np, pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore')
MEAS, S11, OUT = sys.argv[1:4]
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(20261031); B = 2000
CLASSES = ['Gi/o', 'Gq/11', 'Gs']

m = pd.read_csv(MEAS, low_memory=False)
p = pd.read_csv(f'{S11}/predictions/out_of_fold_predictions.tsv', sep='\t')
p = p[p.experiment == 'endpoint_geometry']
units = p[p.validation == 'receptor_grouped_5fold'][
    ['analysis_row_id', 'pdb_id', 'chain_id', 'receptor_name', 'transducer_family']].reset_index(drop=True)
folds = p.pivot_table(index='analysis_row_id', columns='validation', values='outer_fold', aggfunc='first')
df = units.merge(m, on=['pdb_id', 'receptor_name'], how='left', suffixes=('', '_m'))
cl = pd.read_csv(f'{S11}/audit/sequence_cluster_assignments.tsv', sep='\t')
df = df.merge(cl, on='receptor_name', how='left')
df['icl2_model_category'] = np.where(df.icl2_recomputed_category == 'folded', 'active_like', 'inactive_like')
df = df.set_index('analysis_row_id')

coef = pd.read_csv(f'{S11}/coefficients/model_coefficients.tsv', sep='\t')
tf = coef[coef.experiment == 'endpoint_geometry'].transformed_feature.dropna().unique()
NUM = [t.split('__', 1)[1] for t in tf if t.startswith('numeric__')]
NUM = [n for n in dict.fromkeys(NUM) if n != 'activation_consensus_score' and n in df.columns]
ACQ_NUM = ['resolution', 'year_of_deposition']
COUNT_NUM = ['icl2_n_modeled', 'specificity_geometry_feature_count',
             'intracellular_cavity_feature_count', 'activation_consensus_feature_count']
GEOM_STRICT = [n for n in NUM if n not in ACQ_NUM and n not in COUNT_NUM]
SEQ = sorted([c for c in df.columns if re.match(r'gpcrdb_\d+x\d+_expected_aa$', c)])
for c in SEQ + ['icl2_model_category']: df[c] = df[c].astype(str)
print('numerics available %d | strict geometry numerics %d | sequence positions %d'
      % (len(NUM), len(GEOM_STRICT), len(SEQ)), flush=True)

MODELS = {'sequence_only': ([], SEQ),
          'geometry_strict': (GEOM_STRICT, ['icl2_model_category']),
          'sequence_plus_geometry_strict': (GEOM_STRICT, SEQ + ['icl2_model_category'])}
VALS = {'receptor': ('receptor_grouped_5fold', 'receptor_name'),
        'seq50': ('sequence_cluster_50_grouped_5fold', 'sequence_cluster_50'),
        'seq40': ('sequence_cluster_40_grouped_5fold', 'sequence_cluster_40'),
        'seq30': ('sequence_cluster_30_grouped_5fold', 'sequence_cluster_30')}

def pipe(num, cat):
    tr = []
    if num: tr.append(('n', Pipeline([('i', SimpleImputer(strategy='median')), ('s', StandardScaler())]), num))
    if cat: tr.append(('c', Pipeline([('i', SimpleImputer(strategy='most_frequent')),
                                      ('o', OneHotEncoder(handle_unknown='ignore'))]), cat))
    return Pipeline([('pre', ColumnTransformer(tr)),
                     ('lr', LogisticRegression(penalty='l2', solver='lbfgs', max_iter=5000))])

def run(num, cat, val):
    vname, gcol = VALS[val]; f = folds[vname].reindex(df.index)
    y = df.transducer_family.values
    P = pd.DataFrame(np.nan, index=df.index, columns=CLASSES)
    for k in sorted(f.dropna().unique()):
        te = (f == k).values; tr = ~te
        if len(set(y[te])) < 3 or len(set(y[tr])) < 3: continue
        X = df[num + cat]; grp = df[gcol].values[tr]
        if len(set(grp)) < 2: grp = df['receptor_name'].values[tr]
        g = GridSearchCV(pipe(num, cat), {'lr__C': np.logspace(-3, 2, 11)},
                         cv=GroupKFold(min(5, len(set(grp)))), scoring='neg_log_loss', n_jobs=-1)
        g.fit(X[tr], y[tr], groups=grp)
        P.loc[te] = g.predict_proba(X[te])
    return P

def macro(P, idx=None):
    ok = P.notna().all(1)
    y = df.transducer_family[ok]; Q = P[ok]
    if idx is not None: y = y.iloc[idx]; Q = Q.iloc[idx]
    a = []
    for c in CLASSES:
        yy = (y == c).astype(int)
        if 0 < yy.sum() < len(yy): a.append(roc_auc_score(yy, Q[c]))
    return np.mean(a) if a else np.nan

preds, rows = {}, []
for val in VALS:
    for name, (num, cat) in MODELS.items():
        P = run(num, cat, val); preds[(val, name)] = P
        rows.append(dict(validation=val, model=name, n=int(P.notna().all(1).sum()), macro_roc_auc=round(macro(P), 3)))
        print(rows[-1], flush=True)
res = pd.DataFrame(rows); res.to_csv(f'{OUT}/refit_auc.tsv', sep='\t', index=False)

# paired receptor-clustered bootstrap of differences
diffs = []
for val in VALS:
    base = preds[(val, 'sequence_only')]
    ok = base.notna().all(1)
    recs = df.receptor_name[ok].values
    uq = pd.unique(recs); ix = {r: np.where(recs == r)[0] for r in uq}
    for cand in ['sequence_plus_geometry_strict', 'geometry_strict']:
        C = preds[(val, cand)]
        if not (C.notna().all(1) == ok).all(): continue
        obs = macro(C) - macro(base)
        bs = []
        for _ in range(B):
            sel = np.concatenate([ix[r] for r in rng.choice(uq, len(uq))])
            bs.append(macro(C, sel) - macro(base, sel))
        bs = np.array(bs, float)
        diffs.append(dict(validation=val, comparison=f'{cand}_minus_sequence_only',
                          auc_difference=round(obs, 3),
                          ci_low=round(np.nanpercentile(bs, 2.5), 3),
                          ci_high=round(np.nanpercentile(bs, 97.5), 3)))
        print(diffs[-1], flush=True)
pd.DataFrame(diffs).to_csv(f'{OUT}/refit_paired_differences.tsv', sep='\t', index=False)
print('\ndone')
