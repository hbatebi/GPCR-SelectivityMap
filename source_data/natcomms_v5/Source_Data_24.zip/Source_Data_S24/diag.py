import sys, re, numpy as np, pandas as pd
S11, MEAS = sys.argv[1], sys.argv[2]
p = pd.read_csv(f'{S11}/predictions/out_of_fold_predictions.tsv', sep='\t')
c = pd.read_csv(f'{S11}/coefficients/model_coefficients.tsv', sep='\t')

# CHECK 1: positions and encoding
fs = c[c.experiment == 'full_sequence'].transformed_feature.dropna().unique()
pos_arch = sorted({re.sub(r'^categorical__', '', x).rsplit('_', 1)[0] for x in fs})
m = pd.read_csv(MEAS, low_memory=False)
pos_meas = sorted([x for x in m.columns if re.match(r'gpcrdb_\d+x\d+_expected_aa$', x)])
print('CHECK 1 positions: archived=%d measurements=%d identical=%s'
      % (len(pos_arch), len(pos_meas), set(pos_arch) == set(pos_meas)))
print('         archived one-hot features=%d (mean %.1f per position)' % (len(fs), len(fs) / len(pos_arch)))

# CHECK 2: folds identical across experiments?
f = p.pivot_table(index='analysis_row_id', columns=['experiment', 'validation'], values='outer_fold', aggfunc='first')
for val in ['receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold']:
    a = f[('endpoint_geometry', val)]; b = f[('full_sequence', val)]
    both = a.notna() & b.notna()
    print('CHECK 2 folds %-34s overlap_rows=%d identical=%s n_differ=%d'
          % (val, both.sum(), bool((a[both] == b[both]).all()), int((a[both] != b[both]).sum())))

# CHECK 2b: identical held-out observations?
for val in ['receptor_grouped_5fold', 'sequence_cluster_50_grouped_5fold']:
    ag = set(p[(p.experiment == 'endpoint_geometry') & (p.validation == val)].analysis_row_id)
    bg = set(p[(p.experiment == 'full_sequence') & (p.validation == val)].analysis_row_id)
    print('CHECK 2b rows %-34s geom=%d seq=%d identical=%s' % (val, len(ag), len(bg), ag == bg))

# CHECK 3: missingness in the sequence columns
units = p[(p.experiment == 'endpoint_geometry') & (p.validation == 'receptor_grouped_5fold')][
    ['analysis_row_id', 'pdb_id', 'receptor_name']]
df = units.merge(m, on=['pdb_id', 'receptor_name'], how='left')
na = df[pos_meas].isna().sum()
print('CHECK 3 missing cells across 64 sequence columns: total=%d, columns with any NaN=%d, max per column=%d'
      % (int(na.sum()), int((na > 0).sum()), int(na.max())))
blank = (df[pos_meas].astype(str).isin(['nan', '', '-', 'None'])).sum().sum()
print('         cells that astype(str) would turn into a nan-like category: %d' % int(blank))
