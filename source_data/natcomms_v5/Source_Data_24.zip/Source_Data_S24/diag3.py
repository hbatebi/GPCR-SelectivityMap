import sys, re, warnings, numpy as np, pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore')
S11, MEAS = sys.argv[1], sys.argv[2]
CLASSES = ['Gi/o', 'Gq/11', 'Gs']
p = pd.read_csv(f'{S11}/predictions/out_of_fold_predictions.tsv', sep='\t')
pg = p[p.experiment == 'endpoint_geometry']
units = pg[pg.validation == 'receptor_grouped_5fold'][['analysis_row_id','pdb_id','receptor_name','transducer_family']].reset_index(drop=True)
folds = pg.pivot_table(index='analysis_row_id', columns='validation', values='outer_fold', aggfunc='first')
m = pd.read_csv(MEAS, low_memory=False)
SEQ = sorted([x for x in m.columns if re.match(r'gpcrdb_\d+x\d+_expected_aa$', x)])
df = units.merge(m, on=['pdb_id','receptor_name'], how='left')
cl = pd.read_csv(f'{S11}/audit/sequence_cluster_assignments.tsv', sep='\t')
df = df.merge(cl, on='receptor_name', how='left').set_index('analysis_row_id')
def fit(val_name, inner_group):
    X = df[SEQ]
    pipe = Pipeline([('pre', ColumnTransformer([('c', Pipeline(
        [('i', SimpleImputer(strategy='most_frequent')), ('o', OneHotEncoder(handle_unknown='ignore'))]), SEQ)])),
        ('lr', LogisticRegression(penalty='l2', solver='lbfgs', max_iter=5000))])
    f = folds[val_name].reindex(df.index); y = df.transducer_family.values
    P = pd.DataFrame(np.nan, index=df.index, columns=CLASSES); chosen=[]
    for k in sorted(f.dropna().unique()):
        te = (f == k).values; tr = ~te
        if len(set(y[te])) < 3 or len(set(y[tr])) < 3: continue
        grp = df[inner_group].values[tr]
        if len(set(grp)) < 2: grp = df['receptor_name'].values[tr]
        g = GridSearchCV(pipe, {'lr__C': np.logspace(-3, 2, 11)},
                         cv=GroupKFold(min(5, len(set(grp)))), scoring='neg_log_loss', n_jobs=-1)
        g.fit(X[tr], y[tr], groups=grp); P.loc[te] = g.predict_proba(X[te])
        chosen.append(round(g.best_params_['lr__C'], 4))
    ok = P.notna().all(1); yy = df.transducer_family[ok]; Q = P[ok]
    a = [roc_auc_score((yy == c).astype(int), Q[c]) for c in CLASSES if 0 < (yy == c).sum() < len(yy)]
    return np.mean(a), chosen
for vn, arch in [('sequence_cluster_50_grouped_5fold', 0.638), ('sequence_cluster_40_grouped_5fold', 0.612)]:
    for ig in [vn.replace('_grouped_5fold',''), 'receptor_name']:
        auc, C = fit(vn, ig)
        print('%-34s inner_group=%-24s AUC %.3f  (archived %.3f)  C=%s' % (vn.replace('_grouped_5fold',''), ig, auc, arch, C))
