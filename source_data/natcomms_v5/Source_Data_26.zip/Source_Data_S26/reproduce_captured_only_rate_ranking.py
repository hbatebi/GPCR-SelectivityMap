"""Post-hoc captured-class-only ordinal baseline against three-family rate ranking."""
from pathlib import Path
import pandas as pd,numpy as np
from scipy.stats import rankdata
B=Path(__file__).resolve().parent
U=pd.read_csv(B/'clean_model_predictions_by_unit.tsv',sep='\t')
Q=pd.read_csv(B/'clean_functional_validation_non_captured_pairs.tsv',sep='\t')
S=pd.read_csv(B/'S20_Q1_units.tsv',sep='\t')
F=['Gi/o','Gq/11','Gs']; cols=['p_Gi_o','p_Gq_11','p_Gs'];fold=['receptor','seq50','seq40','seq30']
rng=np.random.default_rng(165436)
def rho(a,b):
 a=rankdata(a);b=rankdata(b);aa=a-a.mean();bb=b-b.mean();n=np.linalg.norm(aa)*np.linalg.norm(bb)
 return float(aa@bb/n) if n else np.nan
R=[]
for v in fold:
 df=U[U.validation==v];q=Q[Q.validation==v]
 df=df[df.analysis_row_id.isin(q.analysis_row_id)].copy()
 ld=q.pivot(index='analysis_row_id',columns='test_family',values='measured_rate_s_minus_1')
 data=[]
 for r in df.itertuples():
  rec=dict(ld.loc[r.analysis_row_id].dropna())
  ss=S[(S.pdb_id==r.pdb_id)&(S.receptor_name==r.receptor_name)&(S.transducer_family==r.captured_family)]
  if len(ss)!=1:raise ValueError('ambiguous capture')
  rec[r.captured_family]=float(ss.iloc[0].captured_rate)
  y=np.array([rec[f] for f in F]);m=np.array([r.p_Gi_o,r.p_Gq_11,r.p_Gs]);c=np.array([int(f==r.captured_family) for f in F])
  data.append((r.receptor_name,rho(m,y),rho(c,y)))
 t=pd.DataFrame(data,columns=['receptor_name','model_rho','captured_only_rho'])
 names=t.receptor_name.unique();recs={x:t[t.receptor_name==x] for x in names}
 boot=[]
 for i in range(2000):
  pick=rng.choice(names,len(names),replace=True)
  vals=np.concatenate([(recs[r].model_rho-recs[r].captured_only_rho).to_numpy() for r in pick]);boot.append(vals.mean())
 R.append(dict(validation=v,n_units=len(t),n_receptors=t.receptor_name.nunique(),model_rho=t.model_rho.mean(),captured_only_rho=t.captured_only_rho.mean(),model_minus_baseline=(t.model_rho-t.captured_only_rho).mean(),delta_ci_lower=np.quantile(boot,.025),delta_ci_upper=np.quantile(boot,.975)))
 print(R[-1],flush=True)
pd.DataFrame(R).to_csv(B/'captured_only_rho_baseline.tsv',sep='\t',index=False,float_format='%.8f')
