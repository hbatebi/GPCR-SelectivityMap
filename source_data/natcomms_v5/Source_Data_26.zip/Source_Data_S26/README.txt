Source Data 26 | Additional biological controls for the November 2026 submission

This is a post hoc sensitivity analysis, not a new experimental dataset and not
prospective validation. No model is fitted to the functional readouts.

Inputs:
  clean_model_predictions_by_unit.tsv (snapshot from S25; strict coordinate-only)
  clean_functional_validation_non_captured_pairs.tsv (snapshot from S25)
  S20_Q1_units.tsv (captured-family measured rate per matched unit)
  bouvier_family_max.tsv (derived from published Avet ebBRET results, via S23)
  inoue_family_max.tsv (derived from published Inoue shedding results, via S23)

Scripts:
  reproduce_conditional_and_cross_platform.py
  reproduce_noncaptured_pair_ordering.py
  reproduce_captured_only_rate_ranking.py

Run in this directory with Python/pandas/numpy/scipy/scikit-learn:
  OPENBLAS_NUM_THREADS=1 python reproduce_conditional_and_cross_platform.py
  OPENBLAS_NUM_THREADS=1 python reproduce_noncaptured_pair_ordering.py
  OPENBLAS_NUM_THREADS=1 python reproduce_captured_only_rate_ranking.py

Key observations:
  (1) Masuho noncaptured-family AUC for clean scores = 0.705 (94 structural
      units, 77 receptors), versus mean conditional score-shuffle null = 0.534
      (P = 0.0005). The null shuffles complete predicted three-family
      probability vectors *within captured class and validation fold*,
      preserving the captured partner and split-specific score distribution.
  (2) Conditional null means for 50% and 40% identity: 0.546 and 0.516,
      observed AUCs 0.686 and 0.657 (P = 0.0075 and 0.0050).
      30% is not significant.
  (3) Among 46 units representing 34 receptors with unequal measured rates
      for the two noncaptured families, the clean score orders them correctly
      in 36 (78.3%; 95% receptor bootstrap 66.0-89.1%). Conditional P = 0.0375
      at receptor-grouped; this is an exploratory followup and may not
      reproduce under stricter phylogenetic controls.
  (4) Three-family rate rank rho (0.533) does NOT outperform a trivial
      captured-first rank baseline (0.696), showing that three-family
      correlation alone should not be considered new incremental rate evidence.
  (5) Clean-model association with separately published Avet ebBRET and Inoue
      shedding data is inconclusive: receptor-grouped AUC 0.500 (53 units,
      44 receptors) and 0.542 (83 units, 67 receptors). 'Blank' in those derived
      matrices denotes no *reported* coupling, not a controlled measured zero.

Stats are from 2,000 independent label/profile-preserving permutations or
receptor-clustered bootstrap draws as indicated, seed 20261104 (except the
captured-only rho baseline, seed 165436). The observed Masuho AUC and
receptor-clustered 95% interval are separately reported in Source Data 25.
These additional controls assess conditional information under a specified null,
not a causal mechanism, direct equilibrium binding, a new multi-receptor kinetic
validation cohort or numerical prediction of rate constants.

Original experimental sources:
Masuho et al., Cell Reports 42, 113173 (2023).
Avet et al., eLife 11, e74101 (2022).
Inoue et al., Cell 177, 1933-1947.e25 (2019).
Collated functional-response tables: Hauser et al., eLife 11, e74107 (2022).

CORRECTION (4 November 2026): external-platform receptor bootstrap indexing was corrected. See CORRECTION_README.md. The intervals in captured_class_conditional_and_external_readout_controls.tsv supersede those in earlier distributions.
