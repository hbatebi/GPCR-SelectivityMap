"""Source Data 26: Conditional captured-class/fold control and clean-model assay comparisons.
Post hoc analyses. No new experiments or model fits. Missing assays are 'unreported', not confirmed negatives.
"""
import numpy as np,pandas as pd,zipfile,io
from pathlib import Path
from scipy.stats import rankdata
B=Path(__file__).resolve().parent;OUT=B
F=('Gi/o','Gq/11','Gs');COL=('p_Gi_o','p_Gq_11','p_Gs')
FOLDS={'receptor':'receptor_grouped_5fold','seq50':'sequence_cluster_50_grouped_5fold','seq40':'sequence_cluster_40_grouped_5fold','seq30':'sequence_cluster_30_grouped_5fold'}
U=pd.read_csv(B/'clean_model_predictions_by_unit.tsv',sep='\t')
S=pd.read_csv(B/'clean_functional_validation_non_captured_pairs.tsv',sep='\t')
z=None
E={}
for nm in ('bouvier','inoue'):
 df=pd.read_csv(B/f'{nm}_family_max.tsv',sep='\t')
 E[nm]=df.rename(columns={df.columns[0]:'receptor_name'}).set_index('receptor_name')[list(F)]
rng=np.random.default_rng(20261104)
def auc(y,s):
 n1=int(y.sum());n0=len(y)-n1
 if not(n1 and n0): return np.nan
 return (rankdata(s)[y].sum()-n1*(n1+1)/2)/(n1*n0)
def macro(y,s,fam):
 a=[auc(y[fam==j],s[fam==j]) for j in range(3)]
 return float(np.nanmean(a)) if np.isfinite(a).any() else np.nan
def longs(d,active=None):
 cap=np.array([F.index(c) for c in d.captured_family]);idx=np.repeat(np.arange(len(d)),2)
 fm=np.array([np.flatnonzero(np.arange(3)!=c) for c in cap]).ravel()
 sc=d[list(COL)].to_numpy()[idx,fm]
 rec=d.receptor_name.to_numpy()[idx]
 y=None
 if active is not None: y=active[idx,fm]
 return idx,fm,sc,rec,y
out=[];pairs=[]
for v,fc in FOLDS.items():
 d=U[U.validation==v].copy().reset_index(drop=True)
 q=S[S.validation==v]
 d=d[d.analysis_row_id.isin(q.analysis_row_id.unique())].reset_index(drop=True)
 assert len(d)==94 and d.receptor_name.nunique()==77
 grid=q.pivot(index='analysis_row_id',columns='test_family',values='detectable_activation')
 labels=np.zeros((len(d),3),dtype=bool)
 for i,row in d.iterrows():
  for j,fam in enumerate(F):
   if fam!=row.captured_family:
    labels[i,j]=bool(grid.loc[row.analysis_row_id,fam])
 idx,fm,score,rec,y=longs(d,labels)
 obs=macro(y,score,fm)
 # Permute full score vectors only within matched captured class x frozen validation fold.
 scores=d[list(COL)].to_numpy(float); cap=d.captured_family.to_numpy()
 groups=list(d.groupby(['captured_family',fc],sort=False).indices.values())
 nil=np.empty(2000)
 for b in range(2000):
  shuffled=scores.copy()
  for gi in groups:
   if len(gi)>1:shuffled[gi]=scores[rng.permutation(gi)]
  nil[b]=macro(y,shuffled[idx,fm],fm)
 out.append(dict(test='Masuho conditional geometry beyond captured family + fold',platform='Masuho rates > 0',validation=v,n_units=len(d),n_receptors=d.receptor_name.nunique(),macro_auc=obs,conditional_null_mean=float(nil.mean()),null_lower=float(np.quantile(nil,.025)),null_upper=float(np.quantile(nil,.975)),conditional_permutation_p=float((1+(nil>=obs).sum())/2001)))
 print('conditional',v,round(obs,4),round(nil.mean(),4),round((1+(nil>=obs).sum())/2001,5),flush=True)
 for platform,exp in E.items():
  e=exp.loc[exp.index.intersection(d.receptor_name.unique())]
  available=e.notna().any(axis=1)
  e=e[available]
  sub=d[d.receptor_name.isin(e.index)].copy().reset_index(drop=True)
  if len(sub)<5: continue
  observed=e.loc[sub.receptor_name,F].notna().to_numpy(bool)
  ix,ff,ss,rr,lab=longs(sub,observed)
  mac=macro(lab,ss,ff)
  unq=sub.receptor_name.unique()
  rec_units={r:np.flatnonzero(sub.receptor_name.to_numpy()==r) for r in unq}
  boot=np.empty(2000)
  for b in range(2000):
   pick=rng.choice(unq,size=len(unq),replace=True)
   units=np.concatenate([rec_units[r] for r in pick]);li=(2*units[:,None]+np.array([0,1])).ravel()
   boot[b]=macro(lab[li],ss[li],ff[li])
  # exact comparison conditional on matching receptor set / reported support
  out.append(dict(test='Published assay clean-model sensitivity',platform=platform,validation=v,n_units=len(sub),n_receptors=sub.receptor_name.nunique(),macro_auc=mac,ci_lower=float(np.nanquantile(boot,.025)),ci_upper=float(np.nanquantile(boot,.975)),qualification='Blank=not reported, not independently demonstrated absence of activation'))
  print('assay',platform,v,'n',len(sub),round(mac,4),np.round(np.nanquantile(boot,[.025,.975]),3),flush=True)
  pairs.append(pd.DataFrame(dict(platform=platform,validation=v,analysis_row_id=sub.analysis_row_id.to_numpy()[ix],receptor_name=rr, test_family=np.array(F)[ff],score=ss,reported=lab.astype(int))))
O=pd.DataFrame(out);O.to_csv(OUT/'captured_class_conditional_and_external_readout_controls.tsv',sep='\t',index=False,float_format='%.8f')
pd.concat(pairs,ignore_index=True).to_csv(OUT/'clean_external_readout_pairs.tsv',sep='\t',index=False,float_format='%.8f')
print('DONE',flush=True)
