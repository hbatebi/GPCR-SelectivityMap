"""S26: Uncaptured-family within-unit ranking vs captured-class/fold conditional null.
No new training. 2,000 shuffles of full predicted probability vectors within captured-class x held-out fold.
Bootstrap is receptor-clustered. Tied experimental noncaptured rates excluded from pairwise accuracy.
"""
import pandas as pd, numpy as np
from scipy.stats import rankdata
from pathlib import Path
B=Path(__file__).resolve().parent; U=pd.read_csv(B/'clean_model_predictions_by_unit.tsv',sep='\t'); S=pd.read_csv(B/'clean_functional_validation_non_captured_pairs.tsv',sep='\t')
F=['Gi/o','Gq/11','Gs']; cols=['p_Gi_o','p_Gq_11','p_Gs']; folds={'receptor':'receptor_grouped_5fold','seq50':'sequence_cluster_50_grouped_5fold','seq40':'sequence_cluster_40_grouped_5fold','seq30':'sequence_cluster_30_grouped_5fold'}
rng=np.random.default_rng(20261104)
res=[]
for val,fc in folds.items():
 d=U[U.validation==val];q=S[S.validation==val]
 d=d[d.analysis_row_id.isin(q.analysis_row_id)].copy().reset_index(drop=True)
 pivot=q.pivot(index='analysis_row_id',columns='test_family',values='measured_rate_s_minus_1')
 n=len(d);m=np.array([[k for k in range(3) if F[k]!=r.captured_family] for _,r in d.iterrows()],int)
 yy=np.array([[pivot.loc[r.analysis_row_id,F[j]] for j in m[i]] for i,r in d.iterrows()])
 eq=yy[:,0]!=yy[:,1];truth=yy[:,0]>yy[:,1]
 scores=d[cols].to_numpy(float)
 def score_acc(sc):
  rr=sc[np.arange(n)[:,None],m];return np.mean((rr[:,0]>rr[:,1])[eq]==truth[eq])
 observed=score_acc(scores)
 groups=list(d.groupby(['captured_family',fc],sort=False).indices.values())
 null=[]
 for b in range(2000):
  a=scores.copy()
  for ix in groups:
   if len(ix)>1:a[ix]=scores[rng.permutation(ix)]
  null.append(score_acc(a))
 null=np.array(null)
 ids=d.receptor_name.unique();blocks={r:np.flatnonzero(d.receptor_name.to_numpy()==r) for r in ids};ci=[]
 for b in range(2000):
  ix=np.concatenate([blocks[r] for r in rng.choice(ids,size=len(ids),replace=True)]);
  ss=scores[ix];mm=m[ix];bb=(yy[ix,0]!=yy[ix,1]);tt=yy[ix,0]>yy[ix,1]
  pred=ss[np.arange(len(ix))[:,None],mm]
  ci.append(np.mean(((pred[:,0]>pred[:,1])==tt)[bb]) if bb.any() else np.nan)
 res.append(dict(validation=val,n_units=n,n_receptors=d.receptor_name.nunique(),non_tied_units=int(eq.sum()),non_tied_receptors=d.receptor_name[eq].nunique(),accuracy=observed,cluster_ci_low=np.nanquantile(ci,.025),cluster_ci_high=np.nanquantile(ci,.975),null_mean=null.mean(),null_95_low=np.quantile(null,.025),null_95_high=np.quantile(null,.975),captured_fold_conditional_p=(1+(null>=observed).sum())/2001))
 print(val,res[-1],flush=True)
pd.DataFrame(res).to_csv(B/'noncaptured_rate_ordering_conditional_test.tsv',sep='\t',index=False,float_format='%.8f')
