# Corrected Source Data 26 (4 November 2026)

The external-platform receptor bootstrap in `reproduce_conditional_and_cross_platform.py` previously indexed long-format rows with `np.repeat(units,2)`, incorrectly duplicating rows and failing to sample the paired family values. This version indexes `(2*u, 2*u+1)` and recomputes `captured_class_conditional_and_external_readout_controls.tsv`.

Under receptor-grouped validation, the corrected 95% CIs are ebBRET 0.329–0.661 (AUC 0.500) and shedding 0.432–0.651 (AUC 0.542). The 30% ebBRET CI now crosses chance (0.248–0.649). Other source files and the Masuho conditional permutation results are unchanged.

The original intervals in Supplementary Table 39 are superseded. The revised main manuscript and SI use the corrected intervals.

The external comparisons use a *report presence* proxy where original tables are incomplete, not a direct measured-zero negative label. They do not independently replicate the kinetic endpoint.
