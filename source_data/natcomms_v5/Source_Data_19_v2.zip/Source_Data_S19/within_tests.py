import pandas as pd, numpy as np
from scipy import stats
x=pd.read_pickle('units_meas.pkl')
key={'tm6_aligned_displacement':'TM6 outward displacement','tm6_r350_634_distance':'R3.50–6.34 distance','tm6_axis_tm3_angle':'TM6–TM3 axis angle',
'tm6_tm7_cavity_distance':'TM6–TM7 cavity width','tm5_tm6_cavity_distance':'TM5–TM6 cavity width','tm5_axis_tm3_angle':'TM5–TM3 axis angle','icl2_axis_tm5_angle':'ICL2–TM5 axis angle'}
rows=[]
for f,lab in key.items():
    for a,b in [('Gs','Gi/o'),('Gs','Gq/11'),('Gi/o','Gq/11')]:
        w=x[x.transducer_family.isin([a,b])].pivot_table(index='receptor_name',columns='transducer_family',values=f).dropna()
        d=(w[a]-w[b]).values
        p=stats.wilcoxon(d).pvalue if len(d)>=5 else np.nan
        rows.append(dict(feature=lab,pair=f'{a} vs {b}',n=len(d),median_diff=np.median(d),p=p))
r=pd.DataFrame(rows); ok=r.p.notna()
r.loc[ok,'q']=stats.false_discovery_control(r.loc[ok,'p'].values)
print(r.round(3).to_string()); r.to_csv('within_receptor_wilcoxon.tsv',sep='\t',index=False)
