import pandas as pd, numpy as np
from scipy import stats
rng=np.random.default_rng(20261026)
x=pd.read_pickle('units_meas.pkl')
feats={'tm6_aligned_displacement':'TM6 outward displacement (Å)','tm6_r350_634_distance':'R3.50–6.34 distance (Å)',
 'tm6_axis_tm3_angle':'TM6–TM3 axis angle (°)','tm6_tm7_cavity_distance':'TM6–TM7 cavity width (Å)',
 'tm5_tm6_cavity_distance':'TM5–TM6 cavity width (Å)','tm5_axis_tm3_angle':'TM5–TM3 axis angle (°)','tm5_cytoplasmic_extension':'TM5 cytoplasmic extension (Å)',
 'icl2_helix_fraction':'ICL2 helical fraction','icl2_axis_tm5_angle':'ICL2–TM5 axis angle (°)','icl2_axis_tm3_angle':'ICL2–TM3 axis angle (°)',
 'tm3_tm7_distance':'TM3–TM7 distance (Å)','tm7_h8_angle':'TM7–H8 angle (°)',
 'intracellular_cavity_core_volume':'Cavity volume (Å³)','intracellular_cavity_core_mouth_area':'Cavity mouth area (Å²)','intracellular_cavity_core_maximum_width':'Cavity maximum width (Å)'}
pairs=[('Gs','Gi/o'),('Gs','Gq/11'),('Gi/o','Gq/11')]
def hedges(a,b):
    a=a[~np.isnan(a)]; b=b[~np.isnan(b)]
    na,nb=len(a),len(b); sp=np.sqrt(((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1))/(na+nb-2))
    J=1-3/(4*(na+nb)-9); return J*(a.mean()-b.mean())/sp, sp
rows=[]
recs=x.receptor_name.unique()
idx={r:np.where(x.receptor_name.values==r)[0] for r in recs}
B=2000
boot_idx=[np.concatenate([idx[r] for r in rng.choice(recs,len(recs),replace=True)]) for _ in range(B)]
for f,lab in feats.items():
    v=x[f].astype(float).values; c=x.transducer_family.values
    for a,b in pairs:
        g,sp=hedges(v[c==a],v[c==b])
        bs=[]
        for bi in boot_idx:
            vv=v[bi]; cc=c[bi]
            try: bs.append(hedges(vv[cc==a],vv[cc==b])[0])
            except Exception: pass
        lo,hi=np.nanpercentile(bs,[2.5,97.5])
        aa=v[(c==a)&~np.isnan(v)]; bb=v[(c==b)&~np.isnan(v)]
        p=stats.mannwhitneyu(aa,bb).pvalue
        # within-receptor paired
        w=x[x.transducer_family.isin([a,b])][['receptor_name','transducer_family',f]].dropna()
        pv=w.pivot_table(index='receptor_name',columns='transducer_family',values=f)
        pv=pv.dropna()
        d=(pv[a]-pv[b]).values if len(pv) else np.array([])
        if len(d)>=5:
            sd=d/sp; mw=sd.mean(); bw=[rng.choice(sd,len(sd)).mean() for _ in range(B)]; wl,wh=np.percentile(bw,[2.5,97.5])
            pw=stats.wilcoxon(d).pvalue if np.any(d!=0) else 1.0
        else: mw=wl=wh=pw=np.nan
        rows.append(dict(feature=f,label=lab,pair=f'{a} vs {b}',n_a=len(aa),n_b=len(bb),median_a=np.median(aa),median_b=np.median(bb),
            hedges_g=g,g_ci_low=lo,g_ci_high=hi,mwu_p=p,n_within_receptors=len(d),within_median_diff=np.median(d) if len(d) else np.nan,
            within_std_mean=mw,within_ci_low=wl,within_ci_high=wh,wilcoxon_p=pw))
r=pd.DataFrame(rows)
from scipy.stats import false_discovery_control as fdc
r['mwu_q']=fdc(r.mwu_p.values)
ok=r.wilcoxon_p.notna(); r.loc[ok,'wilcoxon_q']=fdc(r.loc[ok,'wilcoxon_p'].values)
pd.set_option('display.width',250)
print(r[['label','pair','n_a','n_b','median_a','median_b','hedges_g','g_ci_low','g_ci_high','mwu_q','n_within_receptors','within_median_diff','within_std_mean','within_ci_low','within_ci_high','wilcoxon_q']].round(3).to_string())
r.to_csv('structural_class_effects.tsv',sep='\t',index=False)
