Source Data S19 | Structural correlates of the captured class and functional concordance

Contents
  prep.py                        joins per-unit metadata and folds (Source Data S18) to per-structure
                                 measurements (Source Data S1); writes units_meas.pkl
  structural_effects.py          Hedges' g with receptor-clustered bootstrap intervals for each class pair
                                 -> structural_class_effects.tsv
  within_tests.py                within-receptor Wilcoxon signed-rank tests with Benjamini-Hochberg correction
                                 (21 feature-by-pair tests) -> within_receptor_wilcoxon.tsv
  fe2.py                         standardised Gs-minus-Gi/o differences across all units, within 30%, 40% and
                                 50% sequence-identity clusters and within receptors -> class_contrast_by_level.tsv
  func.py                        retrospective functional concordance of out-of-fold class scores (Source Data S11)
                                 with the Hauser et al. (2022) common coupling map (Source Data S14)
                                 -> functional_concordance.tsv
  fig_structural_functional.py   draws main manuscript Figure 5 from the tables above

Running
  Extract Source Data S1, S11, S14 and S18 into one directory and set the SD variable at the top of
  prep.py and func.py to that directory. Run, in order: prep.py, structural_effects.py, within_tests.py,
  fe2.py, func.py, fig_structural_functional.py. Python 3 with numpy, pandas, scipy, scikit-learn and
  matplotlib. No model is refitted; all analyses use archived measurements and frozen predictions.
