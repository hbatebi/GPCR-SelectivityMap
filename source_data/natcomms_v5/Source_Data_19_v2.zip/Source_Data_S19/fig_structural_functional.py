"""New Figure 5: structural correlates of the captured class and functional concordance.
Reads analysis outputs in this directory; writes Figure_5.tif (600 dpi) and a PNG preview."""
import sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
plt.rcParams.update({
    "font.family": "Liberation Sans", "font.size": 8.5, "axes.labelsize": 9, "axes.titlesize": 9.5,
    "xtick.labelsize": 8.5, "ytick.labelsize": 8.5, "legend.fontsize": 8.5,
    "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.9,
    "axes.edgecolor": "#212529", "xtick.color": "#212529", "ytick.color": "#212529",
    "axes.labelcolor": "#212529", "text.color": "#212529",
})
CLS = {"Gs": "#E8871E", "Gi/o": "#1B998B", "Gq/11": "#6F44A8"}
GRID = "#DFE3E8"; MUTED = "#495057"

x = pd.read_pickle("units_meas.pkl")
lev = pd.read_csv("class_contrast_by_level.tsv", sep="\t")
fc = pd.read_csv("functional_concordance.tsv", sep="\t")

fig = plt.figure(figsize=(7.0, 7.3))
def letter(s, fx, fy):
    fig.text(fx, fy, s, fontsize=12.5, fontweight="bold", va="top", ha="left")

# ---------- A: archive-wide TM6 outward displacement by captured class
ax = fig.add_axes([0.095, 0.625, 0.33, 0.305]); letter("A", 0.005, 0.985)
ax.set_title("Across the archive (207 units)", loc="left", pad=9)
rng = np.random.default_rng(3)
order = ["Gs", "Gi/o", "Gq/11"]
for i, c in enumerate(order):
    v = x.loc[x.transducer_family == c, "tm6_aligned_displacement"].dropna().values
    ax.boxplot(v, positions=[i], widths=0.52, showfliers=False, patch_artist=True,
               medianprops=dict(color="#212529", lw=1.6), whiskerprops=dict(color=MUTED, lw=0.9),
               capprops=dict(color=MUTED, lw=0.9), boxprops=dict(facecolor="white", edgecolor=MUTED, lw=0.9))
    ax.scatter(i + rng.uniform(-0.17, 0.17, len(v)), v, s=11, color=CLS[c], alpha=0.75, lw=0.35,
               edgecolor="white", zorder=3)
ax.set_xticks(range(3))
ax.set_xticklabels([f"{c}\n(n = {(x.transducer_family == c).sum()})" for c in order])
ax.set_ylabel("TM6 outward displacement (Å)")
ax.set_xlim(-0.6, 2.6); ax.set_ylim(2, 16)
ax.yaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)

# ---------- B: same receptor, different captured class
ax = fig.add_axes([0.565, 0.625, 0.42, 0.305]); letter("B", 0.475, 0.985)
ax.set_title("Same receptor, two captured classes", loc="left", pad=9)
def pairs(a, b):
    w = x[x.transducer_family.isin([a, b])].pivot_table(index="receptor_name", columns="transducer_family",
                                                        values="tm6_aligned_displacement").dropna()
    return w[[a, b]]
groups = [("Gs", "Gi/o", 0.0), ("Gs", "Gq/11", 1.75), ("Gi/o", "Gq/11", 3.5)]
for a, b, off in groups:
    w = pairs(a, b)
    for _, r in w.iterrows():
        ax.plot([off, off + 1], [r[a], r[b]], color="#ADB5BD", lw=0.8, zorder=1)
    ax.scatter(np.full(len(w), off), w[a], s=14, color=CLS[a], zorder=3, lw=0.35, edgecolor="white")
    ax.scatter(np.full(len(w), off + 1), w[b], s=14, color=CLS[b], zorder=3, lw=0.35, edgecolor="white")
    d = (w[a] - w[b]).median()
    ax.text(off + 0.5, 15.6, f"{len(w)} receptors\nmedian Δ {d:+.2f} Å".replace("-", "\u2212"), ha="center", va="top",
            fontsize=7.8, color=MUTED)
ax.set_xticks([0, 1, 1.75, 2.75, 3.5, 4.5])
ax.set_xticklabels(["Gs", "Gi/o", "Gs", "Gq/11", "Gi/o", "Gq/11"])
ax.set_xlim(-0.45, 4.95); ax.set_ylim(2, 16)
ax.set_ylabel("TM6 outward displacement (Å)")
ax.yaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)

# ---------- C: standardised Gs minus Gi/o contrast by comparison level
ax = fig.add_axes([0.255, 0.155, 0.27, 0.33]); letter("C", 0.005, 0.545)
fig.text(0.045, 0.508, "Gs minus Gi/o, by comparison level", fontsize=9.5, ha="left", va="bottom")
feats = ["TM6 outward displacement", "R3.50–6.34 distance", "TM6–TM3 axis angle", "TM6–TM7 cavity width",
         "TM5–TM6 cavity width", "TM5–TM3 axis angle", "ICL2–TM5 axis angle"]
levels = [("none", "All units"), ("40% cluster", "Within 40% clusters"), ("50% cluster", "Within 50% clusters"),
          ("receptor", "Within receptors")]
shades = ["#A8DCD4", "#5DB9AC", "#1B998B", "#0B4F47"]
sub = lev[lev.pair == "Gs vs Gi/o"]
for fi, f in enumerate(feats):
    for li, (lv, _) in enumerate(levels):
        r = sub[(sub.feature == f) & (sub.level == lv)].iloc[0]
        y = fi + (li - 1.5) * 0.19
        ax.plot([r.std_ci_low, r.std_ci_high], [y, y], color=shades[li], lw=1.3, solid_capstyle="round")
        ax.scatter([r.std_diff], [y], s=15, color=shades[li], zorder=3, lw=0.4, edgecolor="white")
ax.axvline(0, color="#212529", lw=0.8)
ax.set_yticks(range(len(feats))); ax.set_yticklabels(feats); ax.invert_yaxis()
ax.set_xlabel("Standardised difference (pooled SD)")
ax.set_xlim(-1.75, 1.45)
ax.xaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)
handles = [Line2D([0], [0], color=s, lw=1.3, marker="o", ms=4, label=l) for s, (_, l) in zip(shades, levels)]
fig.legend(handles=handles, loc="lower left", bbox_to_anchor=(0.01, 0.0), ncol=2, frameon=False,
           handlelength=1.4, columnspacing=1.2, fontsize=8.2)

# ---------- D: functional concordance
ax = fig.add_axes([0.665, 0.155, 0.32, 0.33]); letter("D", 0.575, 0.545)
fig.text(0.665, 0.508, "Non-captured functional couplings", fontsize=9.5, ha="left", va="bottom")
vals = ["receptor_grouped_5fold", "sequence_cluster_50_grouped_5fold", "sequence_cluster_40_grouped_5fold",
        "sequence_cluster_30_grouped_5fold"]
vlab = ["Receptor-\ngrouped", "50%", "40%", "30%"]
models = [("full_sequence", "Full sequence", "#6F44A8", "-"), ("endpoint_geometry", "Endpoint geometry", "#1B998B", "-"),
          ("global_identity_knn", "Global identity kNN", "#8D99AE", "--")]
for k, (m, lab, col, ls) in enumerate(models):
    s = fc[fc.model == m].set_index("validation").loc[vals]
    xs = np.arange(len(vals)) + (k - 1) * 0.13
    ax.errorbar(xs, s.macro_auc, yerr=[s.macro_auc - s.ci_low, s.ci_high - s.macro_auc], fmt="none",
                ecolor=col, elinewidth=1.0, capsize=0, alpha=0.9)
    ax.plot(xs, s.macro_auc, color=col, ls=ls, lw=1.5, marker="o", ms=4.2, mec="white", mew=0.5, label=lab)
ax.axhline(0.5, color=MUTED, ls=(0, (3, 3)), lw=0.9)
ax.text(-0.35, 0.503, "chance", va="bottom", ha="left", fontsize=8, color=MUTED)
ax.set_xticks(range(len(vals))); ax.set_xticklabels(vlab)
ax.set_xlim(-0.4, 3.4)
ax.set_xlabel("Sequence-identity separation between folds")
ax.set_ylabel("Mean family-specific ROC AUC")
ax.yaxis.grid(True, color=GRID, lw=0.7); ax.set_axisbelow(True)
ax.legend(loc="upper right", frameon=False, handlelength=2.0, fontsize=8.2)
ax.set_ylim(0.38, 0.84)

fig.savefig(f"{OUT}/Figure_5.tif", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
fig.savefig(f"{OUT}/Figure_5_preview.png", dpi=150)
print("ok")
