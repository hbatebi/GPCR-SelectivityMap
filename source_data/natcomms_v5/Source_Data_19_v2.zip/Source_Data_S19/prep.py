import pandas as pd, numpy as np, sys
import os
SD=os.path.join(os.environ.get('SOURCE_DATA_DIR', '.'), '')
u=pd.read_csv(SD+'Source_Data_S18/Source_Data_S18/predictions/unit_metadata_and_folds.tsv',sep='\t')
m=pd.read_csv(SD+'Source_Data_S1/results/microswitches/measurements/microswitch_measurements.csv',low_memory=False)
print('dup pdb in S1:', m.pdb_id.duplicated().sum())
x=u.merge(m.drop(columns=['receptor_name','resolution','experimental_method','ligand_type','fusion_protein','icl2_partial','year_of_deposition','publication_reference'],errors='ignore'),on='pdb_id',how='left',suffixes=('','_m'))
print(x.shape, x.transducer_type.value_counts(dropna=False).to_dict())
print((x.chain_id!=x.preferred_chain).sum(),'chain mismatches')
print(x.transducer_family.value_counts().to_dict(), x.receptor_name.nunique())
feats=['tm6_r350_634_distance','tm6_aligned_displacement','tm6_tm7_cavity_distance','tm6_axis_tm3_angle',
 'tm5_cytoplasmic_extension','tm5_tm6_cavity_distance','tm5_r350_561_distance','tm5_axis_tm3_angle',
 'icl2_helix_fraction','icl2_axis_tm5_angle','icl2_centroid_to_r350','icl2_axis_tm3_angle',
 'tm3_tm7_distance','y753_displacement','tm7_h8_angle',
 'intracellular_cavity_core_volume','intracellular_cavity_core_mouth_area','intracellular_cavity_core_maximum_width','intracellular_cavity_core_bottleneck_radius','intracellular_cavity_core_depth']
for f in feats:
    s=x.groupby('transducer_family')[f].agg(['count','median'])
    print(f, s.to_dict())
x.to_pickle('units_meas.pkl')
