import pandas as pd, numpy as np
rng=np.random.default_rng(7)
x=pd.read_pickle('units_meas.pkl').reset_index(drop=True)
key={'tm6_aligned_displacement':'TM6 outward displacement','tm6_r350_634_distance':'R3.50–6.34 distance','tm6_axis_tm3_angle':'TM6–TM3 axis angle',
'tm6_tm7_cavity_distance':'TM6–TM7 cavity width','tm5_tm6_cavity_distance':'TM5–TM6 cavity width','tm5_axis_tm3_angle':'TM5–TM3 axis angle','icl2_axis_tm5_angle':'ICL2–TM5 axis angle'}
levels=[('none',None),('30% cluster','sequence_cluster_30'),('40% cluster','sequence_cluster_40'),('50% cluster','sequence_cluster_50'),('receptor','receptor_name')]
codes={g:pd.factorize(x[g])[0] for _,g in levels if g}
def contrast(y,t,g):
    if g is None: return y[t==1].mean()-y[t==0].mean(), None
    G=g.max()+1
    n=np.bincount(g,minlength=G); n1=np.bincount(g,weights=t,minlength=G)
    both=(n1>0)&(n1<n)
    ok=both[g]
    if ok.sum()<4: return np.nan,0
    y,t,g=y[ok],t[ok],g[ok]
    ny=np.bincount(g,minlength=G); 
    my=np.bincount(g,weights=y,minlength=G)/np.maximum(ny,1); mt=np.bincount(g,weights=t,minlength=G)/np.maximum(ny,1)
    yd=y-my[g]; td=t-mt[g]
    return (yd*td).sum()/(td*td).sum(), int(both.sum())
recs=pd.factorize(x.receptor_name)[0]; R=recs.max()+1
members=[np.where(recs==r)[0] for r in range(R)]
B=2000; boots=[]
for _ in range(B):
    pick=rng.integers(0,R,R)
    ix=np.concatenate([members[r] for r in pick])
    # duplicated receptors become distinct pseudo-receptors for FE purposes
    pseudo=np.concatenate([np.full(len(members[r]),k) for k,r in enumerate(pick)])
    boots.append((ix,pseudo))
rows=[]
cls=x.transducer_family.values
for f,lab in key.items():
    v=x[f].astype(float).values
    for a,b in [('Gs','Gi/o'),('Gs','Gq/11'),('Gi/o','Gq/11')]:
        m=np.isin(cls,[a,b])&~np.isnan(v); sd=v[m].std(ddof=1)
        for ln,grp in levels:
            def est(ix,pseudo=None):
                mm=m[ix]; y=v[ix][mm]; t=(cls[ix][mm]==a).astype(float)
                if grp is None: return contrast(y,t,None)
                if grp=='receptor_name' and pseudo is not None: g=pd.factorize(pseudo[mm])[0]
                else: g=pd.factorize(codes[grp][ix][mm])[0]
                return contrast(y,t,g)
            e,ng=est(np.arange(len(x)))
            bs=np.array([est(ix,ps)[0] for ix,ps in boots])
            lo,hi=np.nanpercentile(bs,[2.5,97.5])
            rows.append(dict(feature=lab,pair=f'{a} vs {b}',level=ln,n_groups_with_both=ng,diff=e,ci_low=lo,ci_high=hi,std_diff=e/sd,std_ci_low=lo/sd,std_ci_high=hi/sd,pooled_sd=sd))
r=pd.DataFrame(rows); pd.set_option('display.width',220)
print(r.round(3).to_string()); r.to_csv('class_contrast_by_level.tsv',sep='\t',index=False)
