import pandas as pd, numpy as np
from sklearn.metrics import roc_auc_score
rng=np.random.default_rng(11)
import os
SD=os.path.join(os.environ.get('SOURCE_DATA_DIR', '.'), '')
o=pd.read_csv(SD+'Source_Data_S11/results/microswitches/sequence_interface_audit_v1/predictions/out_of_fold_predictions.tsv',sep='\t')
h=pd.read_csv(SD+'Source_Data_S14/Source_Data_S14/provenance_compact/A05_Hauser2022_bound_units.tsv',sep='\t')
h=h[h.direct_human_accession_match==True]
print('mapped units',len(h), h.receptor_name.nunique())
fam={'Gs':'supported_Gs','Gi/o':'supported_Gi_o','Gq/11':'supported_Gq_11'}
def long(df):
    rows=[]
    for _,r in df.iterrows():
        for f,col in fam.items():
            if f==r.transducer_family: continue
            rows.append(dict(receptor=r.receptor_name,pdb=r.pdb_id,family=f,score=r['probability_'+f],label=int(r[col])))
    return pd.DataFrame(rows)
def macro_auc(L):
    a=[]
    for f,g in L.groupby('family'):
        if g.label.nunique()==2: a.append(roc_auc_score(g.label,g.score))
    return np.mean(a), a
out=[]
for exp in ['endpoint_geometry','full_sequence','global_identity_knn','sequence_plus_geometry']:
  for val in ['receptor_grouped_5fold','sequence_cluster_50_grouped_5fold','sequence_cluster_40_grouped_5fold','sequence_cluster_30_grouped_5fold']:
    p=o[(o.experiment==exp)&(o.validation==val)]
    d=p.merge(h[['pdb_id','receptor_name','supported_Gs','supported_Gi_o','supported_Gq_11']],on=['pdb_id','receptor_name'])
    L=long(d)
    m,per=macro_auc(L)
    recs=L.receptor.unique(); ix={r:np.where(L.receptor.values==r)[0] for r in recs}
    bs=[macro_auc(L.iloc[np.concatenate([ix[r] for r in rng.choice(recs,len(recs))])])[0] for _ in range(1000)]
    # receptor-level permutation of functional labels within family
    lab=L.groupby(['receptor','family']).label.first().unstack()
    null=[]
    for _ in range(2000):
        perm=lab.copy()
        for f in perm.columns:
            col=perm[f].dropna(); perm.loc[col.index,f]=rng.permutation(col.values)
        LL=L.copy(); LL['label']=[perm.at[r,f] for r,f in zip(LL.receptor,LL.family)]
        null.append(macro_auc(LL)[0])
    pval=(1+np.sum(np.array(null)>=m))/(1+len(null))
    out.append(dict(model=exp,validation=val,n_units=d.pdb_id.nunique(),n_receptors=d.receptor_name.nunique(),n_pairs=len(L),
       auc_Gs=per[0] if len(per)>0 else np.nan, macro_auc=m,ci_low=np.percentile(bs,2.5),ci_high=np.percentile(bs,97.5),null_mean=np.mean(null),p_one_sided=pval,
       per_family=dict(zip(sorted(L.family.unique()),np.round(per,3)))))
    print(out[-1],flush=True)
pd.DataFrame(out).to_csv('functional_concordance.tsv',sep='\t',index=False)
