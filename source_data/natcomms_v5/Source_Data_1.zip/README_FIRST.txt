Source Data S1

Per-structure metadata, generic numbering, structural measurements and measurement-quality records.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
