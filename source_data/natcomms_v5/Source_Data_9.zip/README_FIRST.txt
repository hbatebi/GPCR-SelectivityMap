Source Data S9

Static receptor feature tables and dictionary covering contacts, surface/electrostatics and mechanical descriptors.

Provenance:
Files were recovered from the author-supplied original computational revision bundle without changing their numerical contents.
